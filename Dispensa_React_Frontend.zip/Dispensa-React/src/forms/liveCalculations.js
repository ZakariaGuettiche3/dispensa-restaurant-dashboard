import { currentFormData } from './fieldValues.js';
import { viewState } from '../state/viewState.js';
import { cents, micros, scaled, unitFor } from '../templates/catalogControls.js';
import { getElement } from '../utils/dom.js';
import { recipeSummary } from '../features/catalog/products.js';
import { label, translateText } from '../i18n/translate.js';
import { selectedSale } from '../features/cashier/register.js';
import { paySummary } from '../features/cashier/payment.js';
import { record } from '../state/selectors.js';
import { Dispensa } from '../domain/index.js';
import { total } from '../templates/layout.js';
import { formatQuantity, unitPrice } from '../utils/format.js';
function syncRecipe(f) {
  const d = currentFormData(f);
  viewState.formula = viewState.formula.map((r, i) => ({
    ing: d['ing' + i] || r.ing,
    qty: scaled(d['qty' + i] || 0),
  }));
  viewState.editPrice = cents(d.price || 0);
}
function updateFormPreview(f) {
  if (!f) return;
  const op = f.dataset.form,
    d = currentFormData(f);
  if (op === 'productSave') {
    syncRecipe(f);
    const n = getElement('recipeCost');
    if (n) n.innerHTML = recipeSummary();
    f.querySelectorAll('[data-line]').forEach((row, i) => {
      row.querySelector('.unit').textContent = translateText(label(unitFor(viewState.formula[i].ing)));
    });
  }
  if (op === 'pay') {
    const b = selectedSale();
    if (b)
      getElement('paymentPreview').innerHTML = paySummary(
        b,
        cents(d.cash || 0),
        cents(d.card || 0),
        cents(d.tendered || 0),
      );
  }
  if (op === 'receive') {
    const o = record('orders', d.order),
      x = o && record('ingredients', o.ing),
      q = scaled(d.qty),
      p = micros(d.price);
    if (x && Number.isSafeInteger(q) && q > 0 && Number.isSafeInteger(p) && p >= 0) {
      const avg = Dispensa.divRound(BigInt(x.qty) * BigInt(x.avg) + BigInt(q) * BigInt(p), x.qty + q);
      getElement('receivePreview').innerHTML = total(
        'Average after receipt|Media dopo la ricezione',
        unitPrice(avg),
      );
    }
  }
  if (op === 'count') {
    const x = record('ingredients', d.ing);
    if (x)
      getElement('stockHint').textContent =
        translateText('Difference|Differenza') + ' ' + formatQuantity(scaled(d.actual) - x.qty, x.unit);
  }
}
export { updateFormPreview, syncRecipe };
