import { translateText } from '../i18n/translate.js';
import { getElement } from '../utils/dom.js';
import { task } from '../app/actionQueue.js';
import { viewState } from '../state/viewState.js';
import { refreshWorkspace } from '../app/refreshWorkspace.js';
import { submitForm } from './submitForm.js';
import { session } from '../state/session.js';
import { preparePhoto } from '../services/imageUpload.js';
import { updatePhotoPreview } from '../features/catalog/productPhoto.js';
import { fitRange } from '../features/reports/periodFilter.js';
import { routeTo } from '../navigation/router.js';
import { accessFields } from '../features/staff/staffViews.js';
import { currentFormData } from './fieldValues.js';
import { records } from '../state/selectors.js';
import { importPreview } from '../features/inventory/importIngredients.js';
import { readRows } from '../services/importRows.js';
import { updateFormPreview } from './liveCalculations.js';
import { hexOK, readable } from '../utils/colorContrast.js';
export function handleFormSubmit(event) {
  const f = event.target.closest('form[data-form]');
  if (f) {
    event.preventDefault();
    task(() => submitForm(f));
  }
}
export function handleFieldChange(event) {
  const t = event.target,
    f = t.closest('form');
  t.setCustomValidity?.('');
  if (t.type === 'file') {
    const caption = t.closest('label')?.querySelector('[data-filename]');
    if (caption)
      caption.textContent = t.files[0]?.name || translateText('No file selected|Nessun file selezionato');
  }
  task(async () => {
    if (t.hasAttribute('data-menu-photo')) {
      if (session.model.preview || !['owner', 'manager'].includes(session.model.actor.role))
        throw Error('preview');
      if (!t.files?.length) return;
      viewState.photoDraft = await preparePhoto(t.files[0]);
      updatePhotoPreview();
      return;
    }
    if (t.dataset.period) {
      fitRange(t.dataset.period, t.value);
      return;
    }
    if (t.hasAttribute('data-stock') || t.hasAttribute('data-order')) {
      routeTo(viewState.page, t.value);
      return;
    }
    if (t.hasAttribute('data-staff-role')) {
      getElement('accessFields').innerHTML = accessFields(t.value, []);
      return;
    }
    if (t.hasAttribute('data-quote')) {
      const d = currentFormData(f),
        q = records('quotes').find((z) => z.supplier === d.supplier && z.ing === d.ing);
      f.elements.price.value = q ? q.price / 1e6 : '';
    }
    if (t.hasAttribute('data-import')) {
      viewState.importRows = null;
      getElement('importReview').innerHTML = importPreview();
      viewState.importRows = await readRows(t.files[0]);
      getElement('importReview').innerHTML = importPreview();
    }
    updateFormPreview(f);
  });
}
export function handleFieldInput(event) {
  const t = event.target;
  t.setCustomValidity?.('');
  if (t.hasAttribute('data-color')) {
    const f = t.closest('form'),
      d = currentFormData(f),
      el = getElement('colorSample'),
      v = [d.color0, d.color1, d.color2];
    if (v.every(hexOK) && el) {
      el.style.background = v[2];
      el.style.color = readable(v[1], v[2]);
      el.style.borderLeft = '16px solid ' + v[0];
    }
    return;
  }
  if (t.hasAttribute('data-filter')) {
    viewState.query = t.value;
    viewState.pageNo = 0;
    refreshWorkspace();
    const n = document.querySelector('[data-filter]');
    n?.focus();
    n?.setSelectionRange(viewState.query.length, viewState.query.length);
    return;
  }
  const f = t.closest('form');
  if (f) updateFormPreview(f);
}
