import { translateText } from '../i18n/translate.js';
import { errors } from '../i18n/messages.js';
export function handleInvalidField(event) {
  const el = event.target;
  if (!el.setCustomValidity) return;
  const k = el.validity.valueMissing
    ? 'required'
    : el.type === 'email'
      ? 'email'
      : el.type === 'date'
        ? 'date'
        : el.type === 'number'
          ? 'number'
          : 'invalid';
  el.setCustomValidity(translateText(errors[k]));
}
