import { updateFormPreview } from './liveCalculations.js';
function captureInputs() {
  const form = document.querySelector('main form');
  if (!form) return null;
  return {
    op: form.dataset.form,
    values: Array.from(form.elements)
      .filter((e) => e.name && e.type !== 'file' && e.type !== 'password')
      .map((e) => [e.name, e.type === 'checkbox' ? e.checked : e.value]),
  };
}
function restoreInputs(saved, skip = () => false) {
  if (!saved) return;
  const f = document.querySelector('main form');
  if (!f || f.dataset.form !== saved.op) return;
  for (const [key, v] of saved.values) {
    if (skip(key)) continue;
    const el = f.elements.namedItem(key);
    if (!el) continue;
    if (el.type === 'checkbox') el.checked = v;
    else el.value = v;
  }
  updateFormPreview(f);
}
function currentFormData(f) {
  return Object.fromEntries([...new FormData(f)].filter(([, v]) => typeof v === 'string'));
}
export { captureInputs, currentFormData, restoreInputs };
