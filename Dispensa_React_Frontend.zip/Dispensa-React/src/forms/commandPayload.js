import { currentFormData } from './fieldValues.js';
import { viewState } from '../state/viewState.js';
import { cents, micros, scaled } from '../templates/catalogControls.js';
import { syncRecipe } from './liveCalculations.js';
import { fileValue } from '../services/attachments.js';
import { Dispensa } from '../domain/index.js';
import { selectedSale } from '../features/cashier/register.js';
async function buildCommandPayload(op, f) {
  const d = currentFormData(f),
    editing = [
      'ingredientSave',
      'productSave',
      'supplierSave',
      'orderSave',
      'expenseSave',
      'ruleSave',
      'staffSave',
    ];
  if (editing.includes(op) && viewState.id) d.id = viewState.id;
  if (op === 'ingredientSave') {
    d.min = scaled(d.min);
    d.tolerance = scaled(d.tolerance);
  }
  if (op === 'productSave') {
    syncRecipe(f);
    return {
      id: viewState.id || undefined,
      name: d.name,
      code: d.code,
      category: d.category,
      price: viewState.editPrice,
      recipe: viewState.formula,
    };
  }
  if (op === 'quoteSave') d.price = micros(d.price);
  if (op === 'orderSave') {
    d.price = micros(d.price);
    d.qty = scaled(d.qty);
    d.submit = d.submit === '1';
  }
  if (op === 'receive' || op === 'opening') {
    d.price = micros(d.price);
    d.qty = scaled(d.qty);
  }
  if (op === 'count') {
    d.actual = scaled(d.actual);
    d.expected = scaled(d.expected);
  }
  if (op === 'waste') d.qty = scaled(d.qty);
  if (op === 'expenseSave') {
    d.amount = cents(d.amount);
    d.removeFile = !!d.removeFile;
    const file = await fileValue(f.elements.attachment.files[0]);
    if (file) d.file = file;
  }
  if (op === 'ruleSave') d.amount = cents(d.amount);
  if (op === 'staffSave') {
    const keys = Object.keys(Dispensa.groups).filter(
      (k) =>
        Dispensa.groups[k].includes(d.role) && !['settings', 'cashier', 'staff', 'organization'].includes(k),
    );
    d.access = d.role === 'owner' ? [] : keys.filter((k) => !d['allow_' + k]);
    for (const k of keys) delete d['allow_' + k];
    if (!d.password) delete d.password;
  }
  if (op === 'decision') {
    d.id = viewState.id;
    d.approve = d.approve === '1';
  }
  if (op === 'pay')
    return {
      id: selectedSale().id,
      cash: cents(d.cash || 0),
      card: cents(d.card || 0),
      tendered: cents(d.tendered || 0),
    };
  if (op === 'requestCorrection') {
    d.sale = selectedSale().id;
    d.qty = Number(d.qty);
    d.amount = cents(d.amount);
  }
  if (op === 'applyCorrection') d.id = viewState.execution;
  if (op === 'importItems')
    return {
      rows: viewState.importRows || [],
    };
  return d;
}
export { buildCommandPayload };
