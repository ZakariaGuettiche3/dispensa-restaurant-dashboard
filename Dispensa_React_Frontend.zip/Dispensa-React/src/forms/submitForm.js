import { saveRestaurant } from '../services/browserStorage.js';
import { currentFormData } from './fieldValues.js';
import { hexOK } from '../utils/colorContrast.js';
import { chooseStyle } from '../services/visualPreferences.js';
import { refreshWorkspace } from '../app/refreshWorkspace.js';
import { notifyUser } from '../services/notifications.js';
import { Dispensa } from '../domain/index.js';
import { session } from '../state/session.js';
import { executeCommand } from '../services/restaurantSession.js';
import { viewState } from '../state/viewState.js';
import { buildCommandPayload } from './commandPayload.js';
import { persistPhoto } from '../features/catalog/productPhoto.js';
import { replaceHash, routeTo } from '../navigation/router.js';
import { home } from '../state/selectors.js';
const afterSave = {
  ingredientSave: 'ingredient',
  productSave: 'product',
  supplierSave: 'supplier',
  orderSave: 'order',
  receive: 'purchases',
  quoteSave: 'quotes',
  opening: 'stock',
  count: 'stock',
  waste: 'stock',
  expenseSave: 'expense',
  ruleSave: 'rules',
  staffSave: 'staff',
  decision: 'approvals',
  pay: 'receipt',
  requestCorrection: 'receipt',
  applyCorrection: 'receipt',
  importItems: 'ingredients',
  organization: 'organization',
  ingredientDelete: 'ingredients',
  productDelete: 'products',
  staffDelete: 'staff',
  expenseDelete: 'expenses',
};
async function submitForm(f) {
  const op = f.dataset.form;
  if (op === 'customColors') {
    const d = currentFormData(f),
      colors = [d.color0, d.color1, d.color2];
    if (!colors.every(hexOK)) throw Error('invalid');
    chooseStyle('customTheme', colors);
    refreshWorkspace();
    notifyUser('paletteSaved');
    return;
  }
  if (op === 'recover') {
    const { email } = currentFormData(f);
    const next = Dispensa.copy(session.restaurant);
    Dispensa.requestRecovery(next, email, session.today + 'T12:00:00');
    saveRestaurant(next);
    session.restaurant = next;
    viewState.recovery = false;
    refreshWorkspace();
    notifyUser('recovered');
    return;
  }
  if (session.model?.preview) throw Error('preview');
  const body = await buildCommandPayload(op, f),
    id = await executeCommand(op, body);
  if (!session.model) return;
  if (op === 'productSave' && viewState.photoDraft !== undefined) {
    try {
      persistPhoto(id, viewState.photoDraft);
    } catch (e) {
      viewState.id = id;
      replaceHash();
      throw e;
    }
  }
  const next = afterSave[op] || home();
  const target =
    op === 'requestCorrection'
      ? body.sale
      : op === 'applyCorrection'
        ? id
        : ['ingredient', 'product', 'supplier', 'order', 'expense', 'receipt', 'rules'].includes(next)
          ? id
          : '';
  routeTo(next, target);
  notifyUser(op);
}
export { afterSave, submitForm };
