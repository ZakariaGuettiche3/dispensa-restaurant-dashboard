import { groups } from './config.js';
import { check } from './validation.js';
const allowed = (a, g) =>
  !!a && a.status === 'active' && !!groups[g]?.includes(a.role) && !(a.access || []).includes(g);
function can(a, g) {
  check(allowed(a, g), 'forbidden');
}
export { allowed, can };
