const OWNER = 'owner',
  MANAGER = 'manager',
  STOCK = 'stock',
  CASHIER = 'cashier';
const roles = [OWNER, MANAGER, CASHIER, STOCK];
const work = [OWNER, MANAGER, STOCK],
  management = [OWNER, MANAGER];
const groups = {
  overview: management,
  sales: management,
  reports: management,
  expenses: management,
  approvals: [OWNER],
  staff: [OWNER],
  organization: [OWNER],
  audit: [OWNER, MANAGER],
  cashier: [CASHIER],
  ingredients: work,
  products: work,
  purchases: work,
  stock: work,
  settings: roles,
};
const buckets = [
  'config',
  'staff',
  'suppliers',
  'ingredients',
  'products',
  'recipe',
  'quotes',
  'orders',
  'receipts',
  'sales',
  'saleLines',
  'use',
  'payments',
  'moves',
  'expenses',
  'files',
  'rules',
  'requests',
  'adjust',
  'events',
];
const categories = [
  'electricity',
  'water',
  'rent',
  'telecom',
  'maintenance',
  'equipment',
  'wages',
  'services',
  'other',
];
const themes = ['olive', 'coast', 'wine'];
const modes = ['light', 'dark', 'system'];
const units = ['kg', 'l', 'pc', 'bt'];
const empty = () => Object.fromEntries(buckets.map((k) => [k, []]));
export { OWNER, STOCK, buckets, categories, empty, groups, management, modes, roles, themes, units };
