import { buckets, categories, empty, groups, modes, roles, themes, units } from './config.js';
import { base } from './restaurant.js';
import { copy, divRound, valueCents } from './validation.js';
import { apply, handlers } from './dispatch.js';
import { project } from './projectRole.js';
import { attachment } from './attachments.js';
import { allowed } from './permissions.js';
import { perPortion } from './stock.js';
import { get } from './records.js';
import { requestRecovery } from './audit.js';
export const Dispensa = {
  roles,
  groups,
  categories,
  themes,
  modes,
  units,
  empty,
  base,
  copy,
  apply,
  project,
  attachment,
  allowed,
  perPortion,
  valueCents,
  divRound,
  handlers,
  get,
  buckets,
  requestRecovery,
};
