import { active, append, get } from '../records.js';
import { check, enumVal, int, word } from '../validation.js';
import { management, units } from '../config.js';
import { compatible } from '../stock.js';
const ingredientSaveCommand = [
  'ingredients',
  (restaurant, actor, payload) => {
    const old = payload.id ? get(restaurant, 'ingredients', payload.id) : null;
    const code = word(payload.code, 32).toUpperCase(),
      unit = enumVal(payload.unit, units);
    compatible(restaurant, actor, old?.id, 'ingredients', code);
    if (old && old.unit !== unit)
      check(
        old.qty === 0 &&
          !restaurant.moves.some((z) => z.ing === old.id) &&
          !restaurant.recipe.some((z) => z.ing === old.id),
        'referenced',
      );
    const data = {
      code,
      name: word(payload.name),
      unit,
      min: int(payload.min),
      tolerance: int(payload.tolerance ?? 500),
    };
    if (old) {
      Object.assign(old, data);
      return old.id;
    }
    return append(restaurant, 'ingredients', 'I', {
      ...data,
      qty: 0,
      avg: 0,
      lastCount: null,
      countDate: '',
      active: 1,
    }).id;
  },
];
const ingredientDeleteCommand = [
  'ingredients',
  (restaurant, actor, payload) => {
    const x = active(restaurant, 'ingredients', payload.id);
    check(
      x.qty === 0 &&
        !restaurant.recipe.some((r) => r.ing === x.id && get(restaurant, 'products', r.product).active) &&
        !restaurant.orders.some(
          (o) => o.ing === x.id && ['draft', 'pending', 'approved', 'partial'].includes(o.status),
        ),
      'referenced',
    );
    x.active = 0;
    return x.id;
  },
];
const productSaveCommand = [
  'products',
  (restaurant, actor, payload) => {
    check(management.includes(actor.role), 'forbidden');
    const old = payload.id ? get(restaurant, 'products', payload.id) : null;
    const code = word(payload.code, 32).toUpperCase();
    compatible(restaurant, actor, old?.id, 'products', code);
    const rules = payload.recipe;
    check(Array.isArray(rules) && rules.length > 0 && rules.length <= 80, 'recipe');
    const ids = new Set();
    for (const r of rules) {
      active(restaurant, 'ingredients', r.ing);
      check(!ids.has(r.ing), 'duplicate');
      ids.add(r.ing);
      int(r.qty, 1, 10000000);
    }
    const row = {
      code,
      name: word(payload.name),
      category: enumVal(payload.category, ['food', 'drinks', 'dessert', 'other']),
      price: int(payload.price),
      active: 1,
      version: (old?.version || 0) + 1,
    };
    const p = old ? Object.assign(old, row) : append(restaurant, 'products', 'P', row);
    restaurant.recipe = restaurant.recipe.filter((r) => r.product !== p.id);
    for (const r of rules)
      restaurant.recipe.push({
        id: p.id + '_' + r.ing,
        product: p.id,
        ing: r.ing,
        qty: r.qty,
      });
    return p.id;
  },
];
const productDeleteCommand = [
  'products',
  (restaurant, actor, payload) => {
    check(management.includes(actor.role), 'forbidden');
    const x = active(restaurant, 'products', payload.id);
    x.active = 0;
    return x.id;
  },
];
const importItemsCommand = [
  'ingredients',
  (restaurant, actor, payload) => {
    check(Array.isArray(payload.rows) && payload.rows.length && payload.rows.length <= 500, 'import');
    for (const z of payload.rows) {
      check(!z.id, 'import');
      ingredientSaveCommand[1](restaurant, actor, z);
    }
    return String(payload.rows.length);
  },
];
export {
  importItemsCommand,
  ingredientDeleteCommand,
  ingredientSaveCommand,
  productDeleteCommand,
  productSaveCommand,
};
