import { active } from '../records.js';
import { check, date, int, word } from '../validation.js';
import { changeStock } from '../stock.js';
import { req } from '../audit.js';
const openingCommand = [
  'stock',
  (restaurant, actor, payload, day) => {
    const x = active(restaurant, 'ingredients', payload.ing);
    const qty = int(payload.qty, 1),
      price = int(payload.price, 0, 1000000000);
    check(!restaurant.moves.some((m) => m.ing === x.id), 'opening_exists');
    x.avg = price;
    changeStock(
      restaurant,
      x,
      qty,
      'opening',
      x.id,
      actor.id,
      date(payload.date || day),
      word(payload.note, 600),
      price,
    );
    return x.id;
  },
];
const countCommand = [
  'stock',
  (restaurant, actor, payload, day) => {
    const x = active(restaurant, 'ingredients', payload.ing);
    check(
      !restaurant.requests.some((r) => r.kind === 'count' && r.ref === x.id && r.status === 'pending'),
      'pending_count',
    );
    const actual = int(payload.actual),
      expected = int(payload.expected);
    check(expected === x.qty, 'stale');
    const diff = actual - expected;
    if (diff) word(payload.note, 600);
    x.lastCount = actual;
    x.countDate = day;
    if (Math.abs(diff) > x.tolerance)
      return req(
        restaurant,
        actor,
        'count',
        x.id,
        payload.note,
        diff,
        {
          expected,
          actual,
        },
        day,
      ).id;
    if (diff) changeStock(restaurant, x, diff, 'count', x.id, actor.id, day, payload.note);
    return x.id;
  },
];
const wasteCommand = [
  'stock',
  (restaurant, actor, payload, day) => {
    const x = active(restaurant, 'ingredients', payload.ing),
      qty = int(payload.qty, 1);
    check(qty <= x.qty, 'short_stock');
    changeStock(restaurant, x, -qty, 'waste', x.id, actor.id, day, word(payload.note, 600));
    return x.id;
  },
];
export { countCommand, openingCommand, wasteCommand };
