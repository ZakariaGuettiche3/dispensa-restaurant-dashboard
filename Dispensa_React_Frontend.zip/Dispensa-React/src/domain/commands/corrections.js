import { append, get } from '../records.js';
import { check, divRound, enumVal, word } from '../validation.js';
import { changeStock, receiptAverage } from '../stock.js';
import { recognize } from '../sales.js';
const decisionCommand = [
  'approvals',
  (restaurant, actor, payload, day) => {
    const r = get(restaurant, 'requests', payload.id);
    check(r.status === 'pending', 'state');
    check(typeof payload.approve === 'boolean');
    r.decision = word(payload.note || '', 600, !payload.approve);
    r.approvedBy = actor.id;
    r.status = payload.approve ? 'approved' : 'rejected';
    if (!payload.approve) {
      if (r.kind === 'purchase') get(restaurant, 'orders', r.ref).status = 'rejected';
      return r.id;
    }
    if (r.kind === 'purchase') get(restaurant, 'orders', r.ref).status = 'approved';
    else if (r.kind === 'price') get(restaurant, 'orders', r.ref).price = r.details.price;
    else if (r.kind === 'count') {
      const x = get(restaurant, 'ingredients', r.ref);
      check(x.qty + r.impact >= 0, 'short_stock');
      changeStock(restaurant, x, r.impact, 'count', r.id, actor.id, day, r.reason);
    } else {
      r.details.outcome = enumVal(payload.outcome || 'consumed', ['consumed', 'returned', 'wasted']);
    }
    return r.id;
  },
];
const applyCorrectionCommand = [
  'cashier',
  (restaurant, actor, payload, day) => {
    const r = get(restaurant, 'requests', payload.id);
    check(r.status === 'approved' && ['discount', 'cancel', 'refund'].includes(r.kind), 'approval');
    const sale = get(restaurant, 'sales', r.ref),
      l = get(restaurant, 'saleLines', r.details.line);
    const amt = r.impact,
      qty = r.details.qty,
      disp = r.details.outcome || 'consumed';
    let costChange = 0,
      loss = 0;
    if (r.kind === 'refund') {
      word(payload.ref, 120);
      const past = restaurant.adjust
        .filter((z) => z.sale === sale.id && z.kind === 'refund')
        .reduce((n, z) => n + z.amount, 0);
      check(amt <= sale.paid - past, 'payment');
    } else {
      check(amt <= sale.total - sale.paid, 'payment');
      sale.total -= amt;
      sale.net -= amt;
      sale.discount += amt;
    }
    if (r.kind !== 'discount') {
      check(qty <= l.qty - l.qtyReversed, 'quantity');
      const pr =
        divRound(BigInt(l.cost) * BigInt(l.qtyReversed + qty), l.qty) -
        divRound(BigInt(l.cost) * BigInt(l.qtyReversed), l.qty);
      l.qtyReversed += qty;
      if (disp !== 'consumed') {
        costChange = pr;
        if (disp === 'wasted') loss = pr;
        else
          for (const c of restaurant.use.filter((c) => c.line === l.id)) {
            const x = get(restaurant, 'ingredients', c.ing),
              q = divRound(BigInt(c.qty) * BigInt(qty), l.qty);
            if (q) {
              x.avg = receiptAverage(x, q, c.avg);
              changeStock(restaurant, x, q, 'return', r.id, actor.id, day, r.reason, c.avg);
            }
          }
      }
    }
    append(restaurant, 'adjust', 'X', {
      sale: sale.id,
      line: l.id,
      qty,
      kind: r.kind,
      outcome: disp,
      amount: amt,
      costChange,
      loss,
      date: day,
      actor: actor.id,
      ref: r.id,
    });
    r.details.payoutRef = payload.ref || '';
    r.status = 'applied';
    recognize(sale, day);
    return sale.id;
  },
];
export { applyCorrectionCommand, decisionCommand };
