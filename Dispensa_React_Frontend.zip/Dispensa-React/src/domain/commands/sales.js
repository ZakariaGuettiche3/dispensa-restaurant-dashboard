import { confirm, recognize, saveDraft } from '../sales.js';
import { append, get } from '../records.js';
import { check, enumVal, int } from '../validation.js';
import { req } from '../audit.js';
const draftCommand = [
  'cashier',
  (restaurant, actor, payload, day, at) => saveDraft(restaurant, actor, payload, day, at).id,
];
const confirmCommand = [
  'cashier',
  (restaurant, actor, payload, day, at) => {
    const sale = payload.lines
      ? saveDraft(restaurant, actor, payload, day, at)
      : get(restaurant, 'sales', payload.id);
    return confirm(restaurant, actor, sale, day).id;
  },
];
const payCommand = [
  'cashier',
  (restaurant, actor, payload, day) => {
    const sale = get(restaurant, 'sales', payload.id);
    check(sale.status === 'confirmed', 'state');
    const cash = int(payload.cash),
      card = int(payload.card);
    check(cash + card > 0 && cash + card <= sale.total - sale.paid, 'payment');
    if (payload.tendered != null) check(int(payload.tendered) >= cash, 'payment');
    append(restaurant, 'payments', 'T', {
      sale: sale.id,
      cash,
      card,
      date: day,
      actor: actor.id,
      ref: '',
    });
    sale.paid += cash + card;
    recognize(sale, day);
    return sale.id;
  },
];
const requestCorrectionCommand = [
  'cashier',
  (restaurant, actor, payload, day) => {
    const sale = get(restaurant, 'sales', payload.sale),
      line = get(restaurant, 'saleLines', payload.line);
    check(line.sale === sale.id && sale.status === 'confirmed', 'state');
    const kind = enumVal(payload.kind, ['discount', 'refund', 'cancel']);
    const pending = restaurant.requests.filter(
      (r) => r.details?.line === line.id && ['pending', 'approved'].includes(r.status),
    );
    const qty = int(payload.qty, 1, line.qty - line.qtyReversed);
    const amount = int(payload.amount, 1, line.unit * qty);
    const paidRefunds = restaurant.adjust
      .filter((v) => v.sale === sale.id && v.kind === 'refund')
      .reduce((n, v) => n + v.amount, 0);
    const used = restaurant.adjust.filter((z) => z.line === line.id).reduce((n, z) => n + z.amount, 0);
    check(amount <= line.unit * line.qty - used - pending.reduce((n, z) => n + z.impact, 0), 'payment');
    const reserved = restaurant.requests
      .filter(
        (r) =>
          r.ref === sale.id &&
          (kind === 'refund' ? r.kind === 'refund' : ['discount', 'cancel'].includes(r.kind)) &&
          ['pending', 'approved'].includes(r.status),
      )
      .reduce((n, r) => n + r.impact, 0);
    const max = kind === 'refund' ? sale.paid - paidRefunds : sale.total - sale.paid;
    check(amount <= max - reserved, 'payment');
    if (kind !== 'discount')
      check(
        qty + pending.filter((r) => r.kind !== 'discount').reduce((n, r) => n + r.details.qty, 0) <=
          line.qty - line.qtyReversed,
        'quantity',
      );
    return req(
      restaurant,
      actor,
      kind,
      sale.id,
      payload.reason,
      amount,
      {
        line: line.id,
        qty,
      },
      day,
    ).id;
  },
];
export { confirmCommand, draftCommand, payCommand, requestCorrectionCommand };
