import { check, date, int, valueCents, word } from '../validation.js';
import { active, append, get } from '../records.js';
import { quote } from '../purchasing.js';
import { req } from '../audit.js';
import { changeStock, receiptAverage } from '../stock.js';
const supplierSaveCommand = [
  'purchases',
  (restaurant, actor, payload) => {
    const data = {
      name: word(payload.name),
      contact: word(payload.contact || '', 120, false),
      email: word(payload.email || '', 180, false),
      phone: word(payload.phone || '', 70, false),
      active: 1,
    };
    return (
      payload.id
        ? Object.assign(get(restaurant, 'suppliers', payload.id), data)
        : append(restaurant, 'suppliers', 'F', data)
    ).id;
  },
];
const quoteSaveCommand = [
  'purchases',
  (restaurant, actor, payload, day) => {
    active(restaurant, 'suppliers', payload.supplier);
    active(restaurant, 'ingredients', payload.ing);
    return quote(restaurant, payload.supplier, payload.ing, int(payload.price, 1, 1000000000), day).id;
  },
];
const orderSaveCommand = [
  'purchases',
  (restaurant, actor, payload, day) => {
    active(restaurant, 'suppliers', payload.supplier);
    active(restaurant, 'ingredients', payload.ing);
    const row = {
      supplier: payload.supplier,
      ing: payload.ing,
      qty: int(payload.qty, 1),
      price: int(payload.price, 1, 1000000000),
      received: 0,
      status: payload.submit ? 'pending' : 'draft',
      date: day,
      expected: date(payload.expected),
      actor: actor.id,
      note: word(payload.note || '', 600, false),
    };
    const old = payload.id ? get(restaurant, 'orders', payload.id) : null;
    if (old) check(old.status === 'draft', 'state');
    const o = old ? Object.assign(old, row) : append(restaurant, 'orders', 'PO', row);
    if (payload.submit)
      req(restaurant, actor, 'purchase', o.id, row.note || '@restock', valueCents(o.qty, o.price), {}, day);
    return o.id;
  },
];
const receiveCommand = [
  'purchases',
  (restaurant, actor, payload, day) => {
    const o = get(restaurant, 'orders', payload.order);
    check(['approved', 'partial'].includes(o.status), 'approval');
    const qty = int(payload.qty, 1, o.qty - o.received),
      price = int(payload.price, 1, 1000000000),
      ref = word(payload.ref, 90);
    check(
      !restaurant.receipts.some((r) => r.supplier === o.supplier && r.ing === o.ing && r.ref === ref),
      'duplicate',
    );
    if (price !== o.price) {
      const existing = restaurant.requests.find(
        (r) => r.kind === 'price' && r.ref === o.id && r.status === 'pending' && r.details.price === price,
      );
      return (
        existing?.id ||
        req(
          restaurant,
          actor,
          'price',
          o.id,
          payload.reason || '@priceChange',
          price,
          {
            price,
          },
          day,
        ).id
      );
    }
    const x = active(restaurant, 'ingredients', o.ing);
    x.avg = receiptAverage(x, qty, price);
    const r = append(restaurant, 'receipts', 'D', {
      order: o.id,
      supplier: o.supplier,
      ing: x.id,
      qty,
      price,
      ref,
      date: day,
      actor: actor.id,
    });
    changeStock(restaurant, x, qty, 'delivery', r.id, actor.id, day, '', price);
    quote(restaurant, o.supplier, x.id, price, day);
    o.received += qty;
    o.status = o.received === o.qty ? 'received' : 'partial';
    return r.id;
  },
];
export { orderSaveCommand, quoteSaveCommand, receiveCommand, supplierSaveCommand };
