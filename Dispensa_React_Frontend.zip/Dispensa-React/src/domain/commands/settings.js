import { enumVal, word } from '../validation.js';
import { modes, themes } from '../config.js';
const preferencesCommand = [
  'settings',
  (restaurant, actor, payload) => {
    actor.lang = enumVal(payload.lang, ['en', 'it']);
    actor.theme = enumVal(payload.theme, themes);
    actor.mode = enumVal(payload.mode, modes);
    return actor.id;
  },
];
const organizationCommand = [
  'organization',
  (restaurant, actor, payload) => {
    const c = restaurant.config[0];
    c.name = word(payload.name);
    c.city = word(payload.city, 150, false);
    c.defaultLang = enumVal(payload.defaultLang, ['en', 'it']);
    return c.id;
  },
];
export { organizationCommand, preferencesCommand };
