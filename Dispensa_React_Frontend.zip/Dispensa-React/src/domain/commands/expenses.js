import { append, get } from '../records.js';
import { check, date, enumVal, int, word } from '../validation.js';
import { categories } from '../config.js';
import { asset } from '../attachments.js';
const expenseSaveCommand = [
  'expenses',
  (restaurant, actor, payload, day) => {
    let existing = payload.id ? get(restaurant, 'expenses', payload.id) : null;
    if (existing) check(!existing.archived, 'state');
    const status = enumVal(payload.status, ['paid', 'unpaid', 'draft']);
    const data = {
      category: enumVal(payload.category, categories),
      amount: int(payload.amount, 1),
      date: date(payload.date),
      due: payload.due ? date(payload.due) : '',
      paidDate: status === 'paid' ? date(payload.paidDate || day) : '',
      status,
      text: word(payload.text, 600),
      supplier: word(payload.supplier || '', 180, false),
      archived: 0,
    };
    const item = existing
      ? Object.assign(existing, data)
      : append(restaurant, 'expenses', 'E', {
          ...data,
          rule: null,
          occurrence: null,
        });
    if (payload.file || payload.removeFile) {
      restaurant.files = restaurant.files.filter((f) => f.expense !== item.id);
      if (payload.file) {
        const attach = asset(payload.file);
        append(restaurant, 'files', 'FLE', {
          expense: item.id,
          ...attach,
        });
      }
    }
    return item.id;
  },
];
const expenseDeleteCommand = [
  'expenses',
  (restaurant, actor, payload) => {
    const x = get(restaurant, 'expenses', payload.id);
    check(!x.archived, 'state');
    x.archived = 1;
    return x.id;
  },
];
const ruleSaveCommand = [
  'expenses',
  (restaurant, actor, payload) => {
    const data = {
      text: word(payload.text, 400),
      category: enumVal(payload.category, categories),
      amount: int(payload.amount, 1),
      next: date(payload.next),
      mode: enumVal(payload.mode, ['automatic', 'review']),
      frequency: enumVal(payload.frequency, ['monthly', 'weekly', 'yearly']),
      active: 1,
    };
    return (
      payload.id
        ? Object.assign(get(restaurant, 'rules', payload.id), data)
        : append(restaurant, 'rules', 'R', data)
    ).id;
  },
];
const runRuleCommand = [
  'expenses',
  (restaurant, actor, payload, day) => {
    const r = get(restaurant, 'rules', payload.id);
    check(r.active && r.next <= day, 'not_due');
    const key = r.id + '/' + r.next;
    check(!restaurant.expenses.some((e) => e.occurrence === key), 'duplicate');
    const dt = new Date(r.next + 'T12:00:00Z'),
      when = r.next;
    if (r.frequency === 'weekly') dt.setUTCDate(dt.getUTCDate() + 7);
    else {
      const dd = dt.getUTCDate();
      dt.setUTCDate(1);
      dt.setUTCMonth(dt.getUTCMonth() + (r.frequency === 'monthly' ? 1 : 12));
      const last = new Date(Date.UTC(dt.getUTCFullYear(), dt.getUTCMonth() + 1, 0)).getUTCDate();
      dt.setUTCDate(Math.min(dd, last));
    }
    r.next = dt.toISOString().slice(0, 10);
    return append(restaurant, 'expenses', 'E', {
      text: r.text,
      category: r.category,
      amount: r.amount,
      date: when,
      due: when,
      paidDate: '',
      status: r.mode === 'review' ? 'draft' : 'unpaid',
      supplier: '',
      archived: 0,
      rule: r.id,
      occurrence: key,
    }).id;
  },
];
export { expenseDeleteCommand, expenseSaveCommand, ruleSaveCommand, runRuleCommand };
