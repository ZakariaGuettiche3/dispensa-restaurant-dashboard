import { append, get } from '../records.js';
import { staffData } from '../staff.js';
import { check } from '../validation.js';
import { OWNER } from '../config.js';
const staffSaveCommand = [
  'staff',
  (restaurant, actor, payload, day) => {
    const old = payload.id ? get(restaurant, 'staff', payload.id) : null;
    const row = staffData(restaurant, payload, old, day);
    if (old) {
      Object.assign(old, row);
      return old.id;
    }
    return append(restaurant, 'staff', 'U', row).id;
  },
];
const staffDeleteCommand = [
  'staff',
  (restaurant, actor, payload) => {
    const u = get(restaurant, 'staff', payload.id);
    check(u.id !== actor.id, 'last_owner');
    if (u.role === OWNER && u.status === 'active')
      check(
        restaurant.staff.some((z) => z.id !== u.id && z.role === OWNER && z.status === 'active'),
        'last_owner',
      );
    u.status = 'deleted';
    u.version++;
    return u.id;
  },
];
export { staffDeleteCommand, staffSaveCommand };
