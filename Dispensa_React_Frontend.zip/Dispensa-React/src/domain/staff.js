import { check, date, enumVal, word } from './validation.js';
import { OWNER, groups, roles } from './config.js';
function staffData(s, b, existing, day) {
  const role = enumVal(b.role, roles),
    email = word(b.email, 220).toLowerCase();
  check(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email), 'email');
  check(!s.staff.some((u) => u.id !== existing?.id && u.email === email), 'duplicate');
  const status = enumVal(b.status, ['active', 'inactive', 'ended']);
  const start = date(b.start),
    end = b.end ? date(b.end) : '';
  check(!end || end >= start, 'date');
  check(status !== 'ended' || !!end, 'date');
  const access = Array.isArray(b.access) ? [...new Set(b.access)] : [];
  check(
    access.every(
      (k) => groups[k]?.includes(role) && !['settings', 'cashier', 'staff', 'organization'].includes(k),
    ),
    'forbidden',
  );
  if (existing?.role === OWNER && existing.status === 'active' && (role !== OWNER || status !== 'active'))
    check(
      s.staff.some((u) => u.id !== existing.id && u.role === OWNER && u.status === 'active'),
      'last_owner',
    );
  return {
    name: word(b.name),
    role,
    email,
    address: word(b.address || '', 340, false),
    phone: word(b.phone || '', 55, false),
    position: word(b.position || '', 120, false),
    start,
    end,
    status,
    access: role === OWNER ? [] : access,
    lang: existing?.lang || s.config[0]?.defaultLang || 'en',
    theme: existing?.theme || 'olive',
    mode: existing?.mode || 'light',
    version: (existing?.version || 0) + 1,
  };
}
export { staffData };
