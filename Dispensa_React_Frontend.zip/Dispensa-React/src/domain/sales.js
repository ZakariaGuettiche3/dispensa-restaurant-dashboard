import { check, divRound, int } from './validation.js';
import { active, append, get } from './records.js';
import { changeStock } from './stock.js';
function saveDraft(s, a, b, day, at) {
  const lines = b.lines;
  check(Array.isArray(lines) && lines.length && lines.length <= 100, 'recipe');
  let sale = b.id ? get(s, 'sales', b.id) : null;
  if (sale) check(sale.status === 'draft', 'state');
  if (sale) s.saleLines = s.saleLines.filter((l) => l.sale !== sale.id);
  else
    sale = append(s, 'sales', 'B', {
      date: day,
      at,
      actor: a.id,
      status: 'draft',
      settled: '',
      total: 0,
      net: 0,
      cost: 0,
      paid: 0,
      discount: 0,
    });
  sale.total = 0;
  const seen = new Set();
  for (const line of lines) {
    const p = active(s, 'products', line.product);
    check(!seen.has(p.id), 'duplicate');
    seen.add(p.id);
    const q = int(line.qty, 1, 1000);
    sale.total += p.price * q;
    int(sale.total, 0, 1000000000);
    append(s, 'saleLines', 'L', {
      sale: sale.id,
      product: p.id,
      name: p.name,
      qty: q,
      unit: p.price,
      cost: 0,
      qtyReversed: 0,
    });
  }
  return sale;
}
function recognize(sale, d) {
  if (sale.status === 'confirmed' && sale.paid >= sale.total && !sale.settled) sale.settled = d;
}
function confirm(s, a, sale, day) {
  check(sale.status === 'draft', 'state');
  const sold = s.saleLines.filter((v) => v.sale === sale.id),
    required = new Map();
  check(sold.length, 'recipe');
  for (const l of sold) {
    const p = active(s, 'products', l.product);
    const r = s.recipe.filter((z) => z.product === p.id);
    check(r.length, 'recipe');
    let micros = 0n;
    for (const c of r) {
      const x = active(s, 'ingredients', c.ing),
        q = c.qty * l.qty;
      required.set(x.id, (required.get(x.id) || 0) + q);
      micros += BigInt(q) * BigInt(x.avg);
      append(s, 'use', 'C', {
        line: l.id,
        ing: x.id,
        qty: q,
        avg: x.avg,
      });
    }
    l.cost = divRound(micros, 10000000n);
  }
  for (const [iid, q] of required) {
    const x = get(s, 'ingredients', iid);
    check(x.qty >= q, 'short_stock');
    changeStock(s, x, -q, 'sale', sale.id, a.id, day);
  }
  sale.status = 'confirmed';
  sale.cost = sold.reduce((n, l) => n + l.cost, 0);
  sale.net = sale.total;
  recognize(sale, day);
  return sale;
}
export { confirm, recognize, saveDraft };
