import { check } from './validation.js';
import { get } from './records.js';
import { can } from './permissions.js';
function asset(file) {
  check(
    file &&
      typeof file.name === 'string' &&
      file.name.length <= 150 &&
      typeof file.b64 === 'string' &&
      file.b64.length <= 2796204 &&
      /^[A-Za-z0-9+/]+={0,2}$/.test(file.b64) &&
      file.b64.length % 4 === 0,
    'file',
  );
  const signatures = {
    'application/pdf': 'JVBERi0',
    'image/png': 'iVBORw0KGgo',
    'image/jpeg': '/9j/',
  };
  check(Object.hasOwn(signatures, file.mime) && file.b64.startsWith(signatures[file.mime]), 'file');
  return {
    name: file.name.replace(/[\\/\u0000-\u001f]/g, '_'),
    mime: file.mime,
    b64: file.b64,
  };
}
function attachment(s, actorId, id, preview) {
  check(!preview, 'preview');
  const a = get(s, 'staff', actorId);
  can(a, 'expenses');
  const f = get(s, 'files', id);
  check(!get(s, 'expenses', f.expense).archived, 'missing');
  return f;
}
export { asset, attachment };
