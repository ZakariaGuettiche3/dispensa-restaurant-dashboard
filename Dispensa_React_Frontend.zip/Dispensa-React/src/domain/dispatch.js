import { organizationCommand, preferencesCommand } from './commands/settings.js';
import { staffDeleteCommand, staffSaveCommand } from './commands/staff.js';
import {
  importItemsCommand,
  ingredientDeleteCommand,
  ingredientSaveCommand,
  productDeleteCommand,
  productSaveCommand,
} from './commands/catalog.js';
import {
  orderSaveCommand,
  quoteSaveCommand,
  receiveCommand,
  supplierSaveCommand,
} from './commands/purchasing.js';
import { countCommand, openingCommand, wasteCommand } from './commands/stock.js';
import { confirmCommand, draftCommand, payCommand, requestCorrectionCommand } from './commands/sales.js';
import { applyCorrectionCommand, decisionCommand } from './commands/corrections.js';
import {
  expenseDeleteCommand,
  expenseSaveCommand,
  ruleSaveCommand,
  runRuleCommand,
} from './commands/expenses.js';
import { get } from './records.js';
import { check, date } from './validation.js';
import { can } from './permissions.js';
import { audit, auditValues } from './audit.js';
const handlers = {
  preferences: preferencesCommand,
  organization: organizationCommand,
  staffSave: staffSaveCommand,
  staffDelete: staffDeleteCommand,
  ingredientSave: ingredientSaveCommand,
  ingredientDelete: ingredientDeleteCommand,
  productSave: productSaveCommand,
  productDelete: productDeleteCommand,
  importItems: importItemsCommand,
  supplierSave: supplierSaveCommand,
  quoteSave: quoteSaveCommand,
  orderSave: orderSaveCommand,
  receive: receiveCommand,
  opening: openingCommand,
  count: countCommand,
  waste: wasteCommand,
  draft: draftCommand,
  confirm: confirmCommand,
  pay: payCommand,
  requestCorrection: requestCorrectionCommand,
  decision: decisionCommand,
  applyCorrection: applyCorrectionCommand,
  expenseSave: expenseSaveCommand,
  expenseDelete: expenseDeleteCommand,
  ruleSave: ruleSaveCommand,
  runRule: runRuleCommand,
};
function apply(s, actorId, key, b, at) {
  const a = get(s, 'staff', actorId);
  const h = Object.hasOwn(handlers, key) && handlers[key];
  check(h, 'invalid');
  can(a, h[0]);
  const day = date(at.slice(0, 10));
  const before = auditValues(s, key, b.id);
  const ref = h[1](s, a, b, day, at);
  if (key !== 'preferences') audit(s, a, key, ref, at, before, auditValues(s, key, ref));
  return ref;
}
export { apply, handlers };
