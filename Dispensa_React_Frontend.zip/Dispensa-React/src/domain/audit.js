import { append } from './records.js';
import { word } from './validation.js';
function audit(s, a, kind, ref, at, before = '', after = '') {
  append(s, 'events', 'A', {
    at,
    actor: a.id,
    kind,
    ref: ref || '',
    before: String(before),
    after: String(after),
  });
}
function req(s, a, kind, ref, reason, impact, details, day) {
  return append(s, 'requests', 'Q', {
    kind,
    ref,
    date: day,
    actor: a.id,
    reason: word(reason, 600),
    status: 'pending',
    impact,
    details,
    decision: '',
    approvedBy: null,
  });
}
const auditFields = {
  staffSave: ['staff', 'name', 'role', 'status'],
  staffDelete: ['staff', 'name', 'role', 'status'],
  ingredientSave: ['ingredients', 'code', 'name', 'unit', 'min'],
  ingredientDelete: ['ingredients', 'code', 'name', 'active'],
  productSave: ['products', 'code', 'name', 'price', 'version'],
  productDelete: ['products', 'name', 'active'],
  expenseSave: ['expenses', 'category', 'amount', 'status'],
  expenseDelete: ['expenses', 'category', 'amount', 'archived'],
  orderSave: ['orders', 'status', 'qty', 'price'],
  pay: ['sales', 'status', 'paid', 'total'],
  confirm: ['sales', 'status', 'paid', 'total'],
  draft: ['sales', 'status', 'total'],
  decision: ['requests', 'kind', 'status'],
  organization: ['config', 'name', 'city', 'defaultLang'],
};
function auditValues(s, key, ref) {
  const fields = auditFields[key];
  if (!fields || !ref) return '';
  const [bucket, ...keys] = fields,
    row = s[bucket].find((r) => r.id === ref);
  return row ? JSON.stringify(Object.fromEntries(keys.map((k) => [k, row[k]]))) : '';
}
function requestRecovery(s, email, at) {
  const u = s.staff.find(
    (p) =>
      p.status === 'active' &&
      p.email ===
        String(email || '')
          .trim()
          .toLowerCase(),
  );
  if (
    !u ||
    s.events.some(
      (e) => e.kind === 'staffRecovery' && e.ref === u.id && e.at.slice(0, 10) === at.slice(0, 10),
    )
  )
    return false;
  audit(s, u, 'staffRecovery', u.id, at);
  return true;
}
export { audit, auditValues, req, requestRecovery };
