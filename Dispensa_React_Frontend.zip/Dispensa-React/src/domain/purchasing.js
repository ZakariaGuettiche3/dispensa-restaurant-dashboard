import { append } from './records.js';
function quote(s, supplier, ingredient, price, day) {
  const old = s.quotes.find((q) => q.supplier === supplier && q.ing === ingredient);
  if (old) {
    old.price = price;
    old.date = day;
    return old;
  }
  return append(s, 'quotes', 'V', {
    supplier,
    ing: ingredient,
    price,
    date: day,
  });
}
export { quote };
