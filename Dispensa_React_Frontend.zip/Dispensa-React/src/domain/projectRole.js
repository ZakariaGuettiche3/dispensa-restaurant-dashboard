import { get } from './records.js';
import { check, copy } from './validation.js';
import { allowed, can } from './permissions.js';
import { OWNER, STOCK, groups } from './config.js';
function project(s, actorId, previewId) {
  const actual = get(s, 'staff', actorId);
  check(actual.status === 'active', 'forbidden');
  if (previewId) can(actual, 'staff');
  const a = previewId ? get(s, 'staff', previewId) : actual;
  check(a.status === 'active', 'inactive');
  const rights = Object.keys(groups).filter((g) => allowed(a, g));
  const p = {
    actor: {
      id: a.id,
      name: a.name,
      role: a.role,
      access: [...(a.access || [])],
      lang: actual.lang,
      theme: actual.theme,
      mode: actual.mode,
    },
    preview: !!previewId,
    config: s.config[0],
    rights,
  };
  const inv = rights.some((r) => ['ingredients', 'stock', 'products', 'purchases'].includes(r)),
    moneyView = rights.some((r) => ['overview', 'reports', 'sales'].includes(r)),
    analytics = rights.some((r) => ['overview', 'reports'].includes(r)),
    cash = rights.includes('cashier');
  if (inv || analytics) {
    p.ingredients = s.ingredients.map((x) => ({
      ...x,
    }));
    if (analytics || rights.includes('stock')) p.moves = s.moves;
    if (rights.includes('products') || analytics) {
      p.products = a.role === STOCK ? s.products.map(({ price, ...p }) => p) : s.products;
      p.recipe = s.recipe;
    }
  }
  if (cash) {
    p.products = s.products
      .filter((x) => x.active)
      .map(({ id, code, name, category, price, active }) => ({
        id,
        code,
        name,
        category,
        price,
        active,
      }));
    p.sales = s.sales.map(({ cost, ...v }) => v);
    p.saleLines = s.saleLines.map(({ cost, ...v }) => v);
    p.payments = s.payments;
    p.adjust = s.adjust.map(({ costChange, loss, ...v }) => v);
    p.requests = s.requests.filter((r) => ['discount', 'cancel', 'refund'].includes(r.kind));
  }
  if (moneyView) {
    p.sales = s.sales;
    p.saleLines = s.saleLines;
    p.payments = s.payments;
    p.adjust = s.adjust;
    if (analytics)
      p.expenseTotals = s.expenses
        .filter((e) => !e.archived && e.status !== 'draft')
        .map(({ id, date, amount, category }) => ({
          id,
          date,
          amount,
          category,
        }));
  }
  if (rights.includes('purchases')) {
    p.suppliers = s.suppliers;
    p.quotes = s.quotes;
    p.orders = s.orders;
    p.receipts = s.receipts;
  }
  if (rights.includes('approvals')) p.requests = s.requests;
  if (rights.includes('expenses')) {
    p.expenses = s.expenses;
    p.rules = s.rules;
    p.files = s.files.map(({ b64, ...meta }) => meta);
  }
  if (rights.includes('staff'))
    p.staff = s.staff
      .filter((u) => u.status !== 'deleted')
      .map((x) => ({
        ...x,
      }));
  if (rights.includes('audit'))
    p.events = s.events.filter((v) => a.role === OWNER || !v.kind.startsWith('staff'));
  if (inv || moneyView || cash) {
    const visible = cash
      ? new Set([
          a.id,
          ...s.sales.map((x) => x.actor),
          ...s.payments.map((x) => x.actor),
          ...p.requests.map((x) => x.actor),
        ])
      : null;
    p.names = Object.fromEntries(
      s.staff.filter((u) => !visible || visible.has(u.id)).map((u) => [u.id, u.name]),
    );
  }
  return copy(p);
}
export { project };
