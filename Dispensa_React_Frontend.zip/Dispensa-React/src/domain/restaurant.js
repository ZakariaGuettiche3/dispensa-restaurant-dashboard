import { OWNER, empty } from './config.js';
function base(configName, ownerEmail, ownerName, today) {
  const s = empty();
  s.config.push({
    id: '1',
    name: configName,
    city: 'Palermo',
    zone: 'Europe/Rome',
    defaultLang: 'en',
    tolerance: 500,
  });
  s.staff.push({
    id: 'U00001',
    name: ownerName,
    role: OWNER,
    email: ownerEmail.toLowerCase(),
    address: '',
    phone: '',
    position: '',
    start: today,
    end: '',
    status: 'active',
    access: [],
    lang: 'en',
    theme: 'olive',
    mode: 'light',
    version: 1,
  });
  return s;
}
export { base };
