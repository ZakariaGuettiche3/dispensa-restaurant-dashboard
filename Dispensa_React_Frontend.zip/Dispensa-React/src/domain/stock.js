import { check, divRound, int, valueCents } from './validation.js';
import { append, get } from './records.js';
function compatible(s, a, editing, k, code) {
  check(!s[k].some((r) => r.id !== editing && r.code.toLowerCase() === code.toLowerCase()), 'duplicate');
}
function changeStock(s, x, delta, kind, ref, actor, d, note = '', unitCost = x.avg) {
  const old = x.qty;
  int(old + delta, 0, 1000000000);
  x.qty += delta;
  append(s, 'moves', 'M', {
    ing: x.id,
    qty: delta,
    cost: Math.sign(delta) * valueCents(Math.abs(delta), unitCost),
    avg: unitCost,
    date: d,
    kind,
    actor,
    ref,
    note,
  });
}
function receiptAverage(x, qty, price) {
  return divRound(BigInt(x.qty) * BigInt(x.avg) + BigInt(qty) * BigInt(price), BigInt(x.qty) + BigInt(qty));
}
function recipeCost(s, productId) {
  return s.recipe
    .filter((r) => r.product === productId)
    .reduce((a, r) => a + BigInt(r.qty) * BigInt(get(s, 'ingredients', r.ing).avg), 0n);
}
const perPortion = (s, p) => divRound(recipeCost(s, p), 10000000n);
export { changeStock, compatible, perPortion, receiptAverage };
