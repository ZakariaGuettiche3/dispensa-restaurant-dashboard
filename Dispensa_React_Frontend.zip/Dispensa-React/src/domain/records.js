import { check } from './validation.js';
function get(s, k, id) {
  const x = s[k].find((r) => r.id === id);
  check(x, 'missing');
  return x;
}
function active(s, k, id) {
  const x = get(s, k, id);
  check(x.active === 1, 'inactive');
  return x;
}
function id(s, k, prefix) {
  let max = 0;
  for (const x of s[k]) {
    const num = Number(x.id.slice(prefix.length));
    if (Number.isInteger(num) && num > max) max = num;
  }
  return prefix + String(max + 1).padStart(5, '0');
}
function append(s, k, prefix, data) {
  const row = {
    id: id(s, k, prefix),
    ...data,
  };
  s[k].push(row);
  return row;
}
export { active, append, get };
