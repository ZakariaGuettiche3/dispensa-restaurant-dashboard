const copy = (o) => JSON.parse(JSON.stringify(o));
function fail(code) {
  throw new Error(code);
}
function check(ok, code = 'invalid') {
  if (!ok) fail(code);
}
function word(v, max = 180, mandatory = true) {
  check(typeof v === 'string' && v.trim().length <= max && (!mandatory || v.trim().length), 'required');
  return v.trim();
}
function enumVal(v, choices) {
  check(choices.includes(v));
  return v;
}
function int(v, low = 0, high = 100000000) {
  check(Number.isSafeInteger(v) && v >= low && v <= high, 'number');
  return v;
}
function date(v) {
  check(
    typeof v === 'string' &&
      /^\d{4}-\d{2}-\d{2}$/.test(v) &&
      !isNaN(Date.parse(v + 'T12:00:00Z')) &&
      new Date(v + 'T12:00:00Z').toISOString().slice(0, 10) === v,
    'date',
  );
  return v;
}
function divRound(num, den) {
  const x = BigInt(num),
    d = BigInt(den);
  return Number((x + d / 2n) / d);
}
const valueCents = (quantity, unitMicros) => divRound(BigInt(quantity) * BigInt(unitMicros), 10000000n);
export { check, copy, date, divRound, enumVal, int, valueCents, word };
