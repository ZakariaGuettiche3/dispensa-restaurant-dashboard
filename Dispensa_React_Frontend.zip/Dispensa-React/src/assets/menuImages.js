import pasta from './menu/P00001.jpg';
import dish2 from './menu/P00002.jpg';
import dish3 from './menu/P00003.jpg';
import dish4 from './menu/P00004.jpg';
import dish5 from './menu/P00005.jpg';
import dish6 from './menu/P00006.jpg';
const MENU_PHOTOS = {
  P00001: pasta,
  P00002: dish2,
  P00003: dish3,
  P00004: dish4,
  P00005: dish5,
  P00006: dish6,
};
export { MENU_PHOTOS };
