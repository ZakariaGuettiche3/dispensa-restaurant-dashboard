import React from 'react';
import { createRoot } from 'react-dom/client';
import { flushSync } from 'react-dom';
import { initializeWorkspace } from './app/initialize.js';
import Workspace from './components/Workspace.jsx';
initializeWorkspace();
const root = createRoot(document.getElementById('root'));
flushSync(() => root.render(<Workspace />));
