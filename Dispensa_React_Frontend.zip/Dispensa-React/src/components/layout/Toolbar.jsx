import React from 'react';
import Icon from './Icon.jsx';
export default function Toolbar({ model }) {
  return (
    <header className="topbar">
      <div className="topgroup">
        <button
          className="util mobilemenu"
          data-ui="menu"
          aria-label={model.translate('Open navigation|Apri navigazione')}
        >
          <Icon model={model} name="Menu" />
        </button>
        <div className="brandbox">
          <span className="resticon">
            <Icon model={model} name="Store" />
          </span>
          <span>{model.restaurant.name}</span>
          <span className="place">{model.restaurant.city}</span>
        </div>
      </div>
      <div className="topgroup">
        <span className="topdate">{model.today}</span>
        <button
          className="util lang"
          data-ui="language"
          aria-label={model.translate('Switch language|Cambia lingua')}
        >
          <Icon model={model} name="Languages" />
          {model.lang.toUpperCase()}
        </button>
        <button
          className="util"
          data-ui="go:settings"
          aria-label={model.translate('Personal preferences|Preferenze personali')}
        >
          <span className="avatar">{model.initials}</span>
        </button>
      </div>
    </header>
  );
}
