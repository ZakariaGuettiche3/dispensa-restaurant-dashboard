import React from 'react';
export default function Icon({ model, name, size = 17 }) {
  return (
    <span
      aria-hidden="true"
      style={{ display: 'contents' }}
      dangerouslySetInnerHTML={{ __html: model.icon(name, size) }}
    />
  );
}
