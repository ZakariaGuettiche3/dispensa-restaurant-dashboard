import React from 'react';
export function RolePreviewBanner({ model }) {
  return (
    <div className="previewbar">
      <b>
        {model.translate('Read-only role preview|Anteprima ruolo in sola lettura')} · {model.actor.name} ·{' '}
        {model.role}
      </b>
      <button className="button" data-ui="exitpreview">
        {model.translate('Exit preview|Esci dall’anteprima')}
      </button>
    </div>
  );
}
