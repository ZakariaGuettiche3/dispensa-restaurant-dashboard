import React from 'react';
import Icon from './Icon.jsx';
export default function Sidebar({ model }) {
  return (
    <aside className={'side' + (model.open ? ' open' : '')}>
      <div className="wordmark">
        <Icon model={model} name="Sprout" size={27} />
        <span>Dispensa</span>
      </div>
      <nav>
        {model.groups
          .filter((g) => g.items.length)
          .map((group) => (
            <div className="navgroup" key={group.title}>
              <h3>{group.title}</h3>
              {group.items.map((item) => (
                <button
                  key={item.key}
                  className={'nav' + (item.active ? ' on' : '')}
                  data-ui={'go:' + item.key}
                  aria-current={item.active ? 'page' : undefined}
                >
                  <Icon model={model} name={item.icon} />
                  <span>{item.title}</span>
                  {item.count > 0 && <span className="nb">{item.count}</span>}
                </button>
              ))}
            </div>
          ))}
      </nav>
      <button className="sidefoot" data-ui="go:settings">
        <span className="avatar">{model.initials}</span>
        <span>
          <b>{model.actor.name}</b>
          <small className="caption" style={{ display: 'block' }}>
            {model.role}
          </small>
        </span>
        <Icon model={model} name="ChevronsUpDown" size={14} />
      </button>
    </aside>
  );
}
