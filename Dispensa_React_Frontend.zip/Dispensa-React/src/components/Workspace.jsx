import React from 'react';
import Sidebar from './layout/Sidebar.jsx';
import Toolbar from './layout/Toolbar.jsx';
import { RolePreviewBanner } from './layout/RolePreviewBanner.jsx';
import { ScreenContent, TemplateContent } from './ScreenContent.jsx';
import { useWorkspace } from '../hooks/useWorkspace.js';
import { useWorkspaceEvents } from '../hooks/useWorkspaceEvents.js';
import { useScreenControls } from '../hooks/useScreenControls.js';
export default function Workspace() {
  const model = useWorkspace();
  useWorkspaceEvents();
  useScreenControls(model);
  if (!model) return null;
  if (model.login) return <TemplateContent html={model.login} />;
  return (
    <>
      <div className="app">
        <a className="skiplink" href="#workspace-main">
          {model.translate('Skip to content|Vai al contenuto')}
        </a>
        <Sidebar model={model} />
        <button
          className="mobilescrim"
          data-ui="menu"
          aria-label={model.translate('Close menu|Chiudi menu')}
        />
        <div className="frame">
          <Toolbar model={model} />
          {model.preview && <RolePreviewBanner model={model} />}
          <main className="main" id="workspace-main" tabIndex={-1}>
            <ScreenContent
              key={model.screen.kind === 'staff' ? model.actor.id : model.revision}
              model={model}
            />
          </main>
        </div>
      </div>
      {model.dialog && <TemplateContent html={model.dialog} />}
    </>
  );
}
