import React from 'react';
import OwnerCharts from '../features/overview/OwnerCharts.jsx';
import { StaffDirectory } from '../features/staff/StaffDirectory.jsx';
// Feature templates escape user-entered fields before handing their markup to React.
export function TemplateContent({ html }) {
  return <div style={{ display: 'contents' }} dangerouslySetInnerHTML={{ __html: html }} />;
}
export function ScreenContent({ model }) {
  const screen = model.screen;
  if (screen.kind === 'staff')
    return <StaffDirectory employees={screen.employees} translate={model.translate} role={model.role} />;
  if (screen.kind === 'overview')
    return (
      <>
        <TemplateContent html={screen.summary} />
        {screen.charts && <OwnerCharts model={model} charts={screen.charts} />}
        <TemplateContent html={screen.products} />
      </>
    );
  return <TemplateContent html={screen} />;
}
