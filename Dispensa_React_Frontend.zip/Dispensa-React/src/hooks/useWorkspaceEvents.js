import { useEffect } from 'react';
import { bindWorkspaceEvents } from '../app/browserEvents.js';
export function useWorkspaceEvents() {
  useEffect(bindWorkspaceEvents, []);
}
