import { useState } from 'react';
export function useSearchableList(items, matches, pageSize = 9) {
  const [query, setQuery] = useState(''),
    [requestedPage, setPage] = useState(0);
  const search = query.trim().toLocaleLowerCase();
  const filtered = search ? items.filter((item) => matches(item, search)) : items;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize)),
    page = Math.min(requestedPage, pageCount - 1);
  function searchFor(value) {
    setQuery(value);
    setPage(0);
  }
  return {
    query,
    searchFor,
    pageCount,
    page,
    setPage,
    items: filtered.slice(page * pageSize, (page + 1) * pageSize),
  };
}
