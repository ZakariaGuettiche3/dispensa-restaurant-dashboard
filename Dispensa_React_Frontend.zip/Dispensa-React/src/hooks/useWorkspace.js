import { useSyncExternalStore } from 'react';
import { getWorkspaceSnapshot, subscribeWorkspace } from '../state/workspaceStore.js';
export function useWorkspace() {
  return useSyncExternalStore(subscribeWorkspace, getWorkspaceSnapshot);
}
