import { useLayoutEffect } from 'react';
const previewControls = [
  'main form input',
  'main form select',
  'main form textarea',
  'main form button',
  ...['tillsave:', 'basket', 'remove:', 'runrule:', 'theme:', 'mode:', 'file:'].map(
    (action) => 'main [data-ui^="' + action + '"]',
  ),
].join(',');
export function useScreenControls(model) {
  useLayoutEffect(() => {
    if (model?.preview)
      document.querySelectorAll(previewControls).forEach((control) => (control.disabled = true));
    if (model?.page === 'cashier' && model.emptyBasket)
      document.querySelectorAll('[data-ui^="tillsave:"]').forEach((button) => (button.disabled = true));
  }, [model]);
}
