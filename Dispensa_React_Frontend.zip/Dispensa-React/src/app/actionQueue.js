import { notifyUser } from '../services/notifications.js';
let locked = false;
let queuedNavigation = null;
async function task(fn, navigation = false) {
  if (locked) {
    if (navigation) queuedNavigation = fn;
    return;
  }
  locked = true;
  try {
    await fn();
  } catch (e) {
    notifyUser(e.message, true);
  } finally {
    locked = false;
    const next = queuedNavigation;
    queuedNavigation = null;
    if (next) await task(next, true);
  }
}
export { task };
