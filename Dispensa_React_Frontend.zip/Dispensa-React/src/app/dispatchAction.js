import { cashierAction } from '../features/cashier/actions.js';
import { catalogAction } from '../features/catalog/actions.js';
import { reportsAction } from '../features/reports/actions.js';
import { recordsAction } from './recordActions.js';
import { appearanceAction } from '../features/settings/actions.js';
import { navigationAction } from '../navigation/actions.js';
import { documentsAction } from '../services/documentActions.js';
import { accountAction } from '../features/auth/actions.js';
import { session } from '../state/session.js';
const actionHandlers = {
  fresh: cashierAction,
  resume: cashierAction,
  basketadd: cashierAction,
  basketdec: cashierAction,
  tillsave: cashierAction,
  removephoto: catalogAction,
  recipeAdd: catalogAction,
  recipeRemove: catalogAction,
  chartreport: reportsAction,
  period: reportsAction,
  drill: reportsAction,
  soldproduct: reportsAction,
  unfocus: reportsAction,
  export: reportsAction,
  keep: recordsAction,
  remove: recordsAction,
  commitdelete: recordsAction,
  runrule: recordsAction,
  execute: recordsAction,
  theme: appearanceAction,
  lang: appearanceAction,
  mode: appearanceAction,
  language: appearanceAction,
  menu: navigationAction,
  go: navigationAction,
  open: navigationAction,
  new: navigationAction,
  pager: navigationAction,
  report: navigationAction,
  queue: navigationAction,
  tillfilter: navigationAction,
  cat: navigationAction,
  method: navigationAction,
  print: documentsAction,
  template: documentsAction,
  file: documentsAction,
  demo: accountAction,
  recovery: accountAction,
  signin: accountAction,
  exitpreview: accountAction,
  preview: accountAction,
  logout: accountAction,
};
const publicActions = new Set(['demo', 'language', 'recovery', 'signin']);
const writeActions = new Set([
  'remove',
  'commitdelete',
  'recipeAdd',
  'recipeRemove',
  'runrule',
  'fresh',
  'resume',
  'basketadd',
  'basketdec',
  'tillsave',
  'execute',
  'removephoto',
  'theme',
]);
async function handleAction(action) {
  const [key, value, recordId] = action.split(':');
  if (!session.model && !publicActions.has(key)) return;
  if (session.model?.preview && writeActions.has(key)) throw Error('preview');
  if (Object.hasOwn(actionHandlers, key)) await actionHandlers[key](key, value, recordId);
}
export { handleAction };
