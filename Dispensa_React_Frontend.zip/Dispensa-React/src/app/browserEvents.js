import { handleInvalidField } from '../forms/validationEvents.js';
import { handleActionClick, handleWorkspaceKey } from '../navigation/interactionEvents.js';
import { handleFormSubmit, handleFieldChange, handleFieldInput } from '../forms/inputEvents.js';
import { getElement } from '../utils/dom.js';
import { session } from '../state/session.js';
import { currentHash, routeTo } from '../navigation/router.js';
import { can, home } from '../state/selectors.js';
import { areas } from '../navigation/routes.js';
import { applyColors } from '../features/settings/applyAppearance.js';
export function bindWorkspaceEvents() {
  const disposers = [];
  function listen(target, event, handler, capture = false) {
    target.addEventListener(event, handler, capture);
    disposers.push(() => target.removeEventListener(event, handler, capture));
  }
  listen(document, 'invalid', handleInvalidField, true);
  listen(document, 'click', handleActionClick);
  listen(document, 'keydown', handleWorkspaceKey);
  listen(document, 'submit', handleFormSubmit);
  listen(document, 'change', handleFieldChange);
  listen(document, 'input', handleFieldInput);
  for (const event of ['mouseover', 'focusin'])
    listen(document, event, (e) => {
      const b = e.target.closest('[data-chart]'),
        n = getElement('chartTip');
      if (b && n) n.textContent = b.dataset.chart;
    });
  listen(window, 'popstate', () => {
    if (!session.model) return;
    const [p, id] = currentHash();
    routeTo(can(areas[p]) ? p : home(), id, false);
  });
  if (typeof matchMedia === 'function') {
    const media = matchMedia('(prefers-color-scheme: dark)');
    if (media.addEventListener) listen(media, 'change', applyColors);
  }
  return () => disposers.forEach((dispose) => dispose());
}
