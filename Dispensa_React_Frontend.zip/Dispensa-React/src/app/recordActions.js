import { viewState } from '../state/viewState.js';
import { refreshWorkspace } from './refreshWorkspace.js';
import { executeCommand } from '../services/restaurantSession.js';
import { routeTo } from '../navigation/router.js';
import { afterSave } from '../forms/submitForm.js';
import { notifyUser } from '../services/notifications.js';
import { record } from '../state/selectors.js';
async function recordsAction(key, v, z) {
  if (key === 'keep') {
    viewState.confirm = null;
    refreshWorkspace();
    return;
  }
  if (key === 'remove') {
    viewState.confirm = {
      op: v,
      id: z,
    };
    refreshWorkspace();
    document.querySelector('.confirmbox button')?.focus();
    return;
  }
  if (key === 'commitdelete' && viewState.confirm) {
    const { op, id } = viewState.confirm;
    await executeCommand(op, {
      id,
    });
    routeTo(afterSave[op]);
    notifyUser(op);
    return;
  }
  if (key === 'runrule') {
    await executeCommand('runRule', {
      id: v,
    });
    refreshWorkspace();
    notifyUser('runRule');
    return;
  }
  if (key === 'execute') {
    const r = record('requests', v);
    if (!r) throw Error('missing');
    viewState.execution = v;
    routeTo('correction', r.ref);
    return;
  }
}
export { recordsAction };
