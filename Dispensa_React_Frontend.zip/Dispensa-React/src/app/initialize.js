import { loadRestaurant, loadAccount, loadPreview } from '../services/browserStorage.js';
import { session } from '../state/session.js';
import { dateInRome } from '../utils/dates.js';
import { viewState } from '../state/viewState.js';
import * as Reports from '../services/reports.js';
import { refreshRoleProjection } from '../services/restaurantSession.js';
import { sampleRestaurant } from '../data/seedRestaurant.js';
import { Dispensa } from '../domain/index.js';
import { assignRecord, currentHash } from '../navigation/router.js';
import { can, home } from '../state/selectors.js';
import { areas } from '../navigation/routes.js';
import { refreshWorkspace } from './refreshWorkspace.js';
export function initializeWorkspace() {
  session.today = dateInRome();
  viewState.anchor = session.today;
  viewState.from = Reports.step(session.today, -6);
  viewState.to = session.today;
  viewState.cf = Reports.step(session.today, -13);
  viewState.ct = Reports.step(session.today, -7);
  const who = loadAccount();
  const saved = loadRestaurant();
  session.restaurant = Array.isArray(saved?.staff) ? saved : null;
  session.restaurant ||= sampleRestaurant(session.today, Dispensa);
  session.accountId =
    who === 'signed-out'
      ? null
      : who && session.restaurant.staff.some((u) => u.id === who && u.status === 'active')
        ? who
        : session.restaurant.staff.find((u) => u.status === 'active' && u.role === 'owner')?.id;
  if (session.accountId) {
    try {
      const savedPreview = loadPreview();
      if (savedPreview?.owner === session.accountId && savedPreview.staff) {
        Dispensa.project(session.restaurant, session.accountId, savedPreview.staff);
        session.previewId = savedPreview.staff;
        viewState.previewOrigin = savedPreview.origin;
      }
    } catch {}
  }
  refreshRoleProjection();
  if (session.model) {
    const [p, id] = currentHash();
    assignRecord(can(areas[p]) ? p : home(), id);
  }
  refreshWorkspace();
}
