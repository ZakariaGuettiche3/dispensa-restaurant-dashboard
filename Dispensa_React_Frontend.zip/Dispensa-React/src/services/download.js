function download(name, data, mime) {
  const blob =
      data instanceof Blob
        ? data
        : new Blob([data], {
            type: mime,
          }),
    url = URL.createObjectURL(blob),
    a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function csvCell(v) {
  let s = String(v ?? '');
  if (/^[\s]*[=+@\-]/.test(s) && !/^[-+]?\d[\d\.,]*$/.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}
export { csvCell, download };
