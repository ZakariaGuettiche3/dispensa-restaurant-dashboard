import { download } from './download.js';
import { importColumns } from '../features/inventory/importIngredients.js';
import { openInvoice } from './attachments.js';
async function documentsAction(key, v, z) {
  if (key === 'print') {
    window.print();
    return;
  }
  if (key === 'template')
    return download(
      'Dispensa_ingredients.csv',
      importColumns.join(',') + '\r\nBAS,Basilico,kg,1,0.1\r\n',
      'text/csv;charset=utf-8',
    );
  if (key === 'file') return openInvoice(v);
}
export { documentsAction };
