import { label, translateText } from '../i18n/translate.js';
import { errors } from '../i18n/messages.js';
import { getElement } from '../utils/dom.js';
function notifyUser(key, failure = false) {
  const visible = translateText(failure ? errors[key] || errors.internal : label(key)),
    target = document.querySelector('form .formerror');
  if (target && failure) target.textContent = visible;
  const n = getElement('toast');
  if (!n) return;
  n.textContent = visible;
  n.classList.add('show', 'on');
  n.style.display = 'block';
  clearTimeout(notifyUser.timer);
  notifyUser.timer = setTimeout(() => {
    n.classList.remove('show', 'on');
    n.style.display = 'none';
  }, 3900);
}
export { notifyUser };
