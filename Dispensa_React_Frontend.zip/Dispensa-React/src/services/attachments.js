import { session } from '../state/session.js';
import { Dispensa } from '../domain/index.js';
import { download } from './download.js';
async function openInvoice(id) {
  if (session.model.preview) throw Error('preview');
  let blob, name;
  const f = Dispensa.attachment(session.restaurant, session.accountId, id, false);
  blob = new Blob([Uint8Array.from(atob(f.b64), (c) => c.charCodeAt(0))], {
    type: f.mime,
  });
  name = f.name;
  download(name, blob);
}
async function fileValue(f) {
  if (!f || !f.size) return null;
  if (f.size > 2097152) throw Error('file');
  const data = await new Promise((ok, no) => {
    const r = new FileReader();
    r.onload = () => ok(r.result);
    r.onerror = () => no(Error('file'));
    r.readAsDataURL(f);
  });
  return {
    name: f.name,
    mime: f.type,
    b64: data.split(',')[1],
  };
}
export { fileValue, openInvoice };
