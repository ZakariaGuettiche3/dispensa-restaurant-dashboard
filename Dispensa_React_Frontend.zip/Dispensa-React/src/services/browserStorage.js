// Stable keys keep existing demo accounts, transactions and photos across releases.
const keys = {
  restaurant: 'dispensa-react-workspace-v1',
  account: 'dispensa-react-account-v1',
  preview: 'dispensa-react-role-preview',
  visuals: 'dispensa-react-visuals-v1-demo',
};
function read(key, session = false) {
  try {
    return (session ? sessionStorage : localStorage).getItem(key);
  } catch {
    return null;
  }
}
function readJson(key, session = false) {
  try {
    return JSON.parse(read(key, session));
  } catch {
    return null;
  }
}
function saveJson(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    throw Error('storage');
  }
}
export const loadRestaurant = () => readJson(keys.restaurant);
export const saveRestaurant = (data) => saveJson(keys.restaurant, data);
export const loadAccount = () => read(keys.account, true);
export const saveAccount = (id) => sessionStorage.setItem(keys.account, id);
export const loadVisualSettings = () => readJson(keys.visuals) || {};
export const saveVisualSettings = (settings) => saveJson(keys.visuals, settings);
export const loadPreview = () => readJson(keys.preview, true);
export function savePreview(preview) {
  try {
    if (preview) sessionStorage.setItem(keys.preview, JSON.stringify(preview));
    else sessionStorage.removeItem(keys.preview);
  } catch {
    /* Preview remains available for this session. */
  }
}
