import { saveRestaurant, saveAccount } from './browserStorage.js';
import { session } from '../state/session.js';
import { Dispensa } from '../domain/index.js';
function refreshRoleProjection() {
  session.model = session.accountId
    ? Dispensa.project(session.restaurant, session.accountId, session.previewId)
    : null;
  if (session.model) session.language = session.model.actor.lang;
}
async function executeCommand(op, body) {
  if (!session.model || session.model.preview) throw Error(session.model ? 'preview' : 'unauthorized');
  const next = Dispensa.copy(session.restaurant);
  const id = Dispensa.apply(
    next,
    session.accountId,
    op,
    body,
    session.today + 'T' + new Date().toTimeString().slice(0, 8),
  );
  saveRestaurant(next);
  session.restaurant = next;
  if (next.staff.find((x) => x.id === session.accountId)?.status !== 'active') {
    session.accountId = null;
    saveAccount('signed-out');
  }
  refreshRoleProjection();
  return id;
}
export { executeCommand, refreshRoleProjection };
