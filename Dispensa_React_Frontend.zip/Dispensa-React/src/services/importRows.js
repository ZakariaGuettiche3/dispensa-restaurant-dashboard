import { parseCSV, readWorkbook } from '../utils/workbook.js';
import { importColumns } from '../features/inventory/importIngredients.js';
import { records } from '../state/selectors.js';
import { Dispensa } from '../domain/index.js';
import { scaled } from '../templates/catalogControls.js';
async function readRows(file) {
  if (!file || file.size > 4000000) throw Error('import');
  let raw;
  try {
    raw = /\.xlsx$/i.test(file.name) ? await readWorkbook(file) : parseCSV(await file.text());
  } catch {
    throw Error('import');
  }
  if (raw.length < 2 || raw.length > 501) throw Error('import');
  const heads = raw.shift().map((x) => String(x).trim().toLowerCase()),
    indices = importColumns.map((k) => heads.indexOf(k)),
    codes = new Set(records('ingredients').map((x) => x.code.toUpperCase()));
  if (indices.includes(-1)) throw Error('import');
  return raw.map((row) => {
    const [code, name, unit, min, tolerance] = indices.map((i) => String(row[i] ?? '').trim());
    if (
      !code ||
      code.length > 32 ||
      !name ||
      !Dispensa.units.includes(unit) ||
      ![min, tolerance].every((x) => /^\d+(?:\.\d{1,3})?$/.test(x))
    )
      throw Error('import');
    if (codes.has(code.toUpperCase())) throw Error('duplicate');
    codes.add(code.toUpperCase());
    return {
      code,
      name,
      unit,
      min: scaled(min),
      tolerance: scaled(tolerance),
    };
  });
}
export { readRows };
