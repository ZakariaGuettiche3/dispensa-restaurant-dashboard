const iso = (d) => d.toISOString().slice(0, 10),
  dt = (s) => new Date(s + 'T12:00:00Z');
const step = (s, n) => iso(new Date(dt(s).getTime() + n * 86400000));
const days = (a, b) => Math.round((dt(b) - dt(a)) / 86400000) + 1;
function period(kind, anchor, custom, model) {
  const d = dt(anchor),
    y = d.getUTCFullYear(),
    m = d.getUTCMonth(),
    fmt = (a, b, c) => iso(new Date(Date.UTC(a, b, c, 12)));
  if (kind === 'all') {
    const dates = [
      anchor,
      ...(model.sales || []).flatMap((b) => [b.date, b.settled]),
      ...(model.expenseTotals || []).map((x) => x.date),
      ...(model.expenses || []).filter((x) => !x.archived).map((x) => x.date),
      ...(model.receipts || []).map((x) => x.date),
      ...(model.moves || []).map((x) => x.date),
      ...(model.payments || []).map((x) => x.date),
      ...(model.adjust || []).map((x) => x.date),
    ]
      .filter(Boolean)
      .sort();
    return [dates[0], dates.at(-1)];
  }
  if (kind === 'custom') return custom;
  if (kind === 'year') return [fmt(y, 0, 1), fmt(y, 11, 31)];
  if (kind === 'month') return [fmt(y, m, 1), fmt(y, m + 1, 0)];
  if (kind === 'week') {
    const start = step(anchor, -((d.getUTCDay() + 6) % 7));
    return [start, step(start, 6)];
  }
  return [anchor, anchor];
}
function prior(kind, start, end) {
  const d = dt(start);
  if (kind === 'year') return [d.getUTCFullYear() - 1 + '-01-01', d.getUTCFullYear() - 1 + '-12-31'];
  if (kind === 'month') {
    const e = step(start, -1);
    return [e.slice(0, 7) + '-01', e];
  }
  return [step(start, -days(start, end)), step(start, -1)];
}
const within = (d, a, b) => !!d && d >= a && d <= b;
const sum = (a, key) => a.reduce((n, o) => n + (o[key] || 0), 0);
function metrics(s, from, to) {
  const tally = {
      revenue: 0,
      cost: 0,
      orders: 0,
      expense: 0,
      loss: 0,
      gain: 0,
      cash: 0,
      card: 0,
      refunds: 0,
      units: 0,
    },
    by = new Map(),
    timeline = new Map();
  function point(day, k, v) {
    const r = timeline.get(day) || {
      revenue: 0,
      profit: 0,
    };
    r[k] += v;
    timeline.set(day, r);
  }
  function product(id, name) {
    if (!by.has(id))
      by.set(id, {
        id,
        name,
        qty: 0,
        revenue: 0,
        cost: 0,
      });
    return by.get(id);
  }
  const lines = new Map(),
    byLine = new Map(),
    saleBy = new Map(),
    adjustBy = new Map();
  for (const l of s.saleLines || []) {
    if (!lines.has(l.sale)) lines.set(l.sale, []);
    lines.get(l.sale).push(l);
    byLine.set(l.id, l);
  }
  for (const a of s.adjust || []) {
    if (!adjustBy.has(a.sale)) adjustBy.set(a.sale, []);
    adjustBy.get(a.sale).push(a);
  }
  for (const sale of s.sales || []) {
    saleBy.set(sale.id, sale);
    if (!within(sale.settled, from, to)) continue;
    tally.orders++;
    const list = lines.get(sale.id) || [],
      adj = adjustBy.get(sale.id) || [];
    tally.revenue += sale.net;
    tally.cost += sale.cost;
    point(sale.settled, 'revenue', sale.net);
    point(sale.settled, 'profit', sale.net - sale.cost);
    for (const l of list) {
      const p = product(l.product, l.name),
        cor = adj.filter((x) => x.line === l.id && x.kind !== 'refund');
      p.qty += l.qty;
      p.revenue += l.qty * l.unit - sum(cor, 'amount');
      p.cost += l.cost;
      tally.units += l.qty;
    }
  }
  for (const a of s.adjust || []) {
    const sale = saleBy.get(a.sale),
      l = byLine.get(a.line);
    if (!sale || !l) continue;
    const finDay = sale.settled && a.date < sale.settled ? sale.settled : a.date;
    if (a.kind === 'refund' && within(a.date, from, to)) {
      tally.refunds += a.amount;
      tally.revenue -= a.amount;
      point(a.date, 'revenue', -a.amount);
      point(a.date, 'profit', -a.amount);
      product(l.product, l.name).revenue -= a.amount;
    }
    if (sale.settled && within(finDay, from, to) && a.kind !== 'discount') {
      const p = product(l.product, l.name);
      tally.cost -= a.costChange;
      tally.loss += a.loss;
      point(finDay, 'profit', a.costChange - a.loss);
      p.cost -= a.costChange;
      if (a.outcome !== 'consumed') {
        p.qty -= a.qty;
        tally.units -= a.qty;
      }
    }
  }
  for (const e of s.expenseTotals || []) {
    if (within(e.date, from, to)) {
      tally.expense += e.amount;
      point(e.date, 'profit', -e.amount);
    }
  }
  for (const m of s.moves || []) {
    if (!within(m.date, from, to) || !['waste', 'count'].includes(m.kind)) continue;
    if (m.cost < 0) tally.loss -= m.cost;
    else tally.gain += m.cost;
    point(m.date, 'profit', m.cost);
  }
  for (const p of s.payments || []) {
    if (within(p.date, from, to)) {
      tally.cash += p.cash;
      tally.card += p.card;
    }
  }
  tally.gross = tally.revenue - tally.cost;
  tally.profit = tally.gross - tally.expense - tally.loss + tally.gain;
  tally.aov = tally.orders ? Math.round(tally.revenue / tally.orders) : null;
  tally.margin = tally.revenue > 0 ? tally.gross / tally.revenue : null;
  return {
    ...tally,
    products: [...by.values()].sort((a, b) => b.revenue - a.revenue),
    timeline,
  };
}
function series(metrics, start, end) {
  const span = days(start, end),
    n = Math.min(span, 10),
    out = [];
  for (let i = 0; i < n; i++) {
    const a = step(start, Math.floor((i * span) / n)),
      b = step(start, Math.floor(((i + 1) * span) / n) - 1);
    out.push({
      from: a,
      to: b,
      revenue: 0,
      profit: 0,
    });
  }
  for (const [day, p] of metrics.timeline) {
    const j = out.find((z) => within(day, z.from, z.to));
    if (j) {
      j.revenue += p.revenue;
      j.profit += p.profit;
    }
  }
  return out;
}
export { period, prior, metrics, series, within, step };
