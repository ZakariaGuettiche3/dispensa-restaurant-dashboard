import { loadVisualSettings, saveVisualSettings } from './browserStorage.js';
import { session } from '../state/session.js';
import { viewState } from '../state/viewState.js';
const loadVisuals = loadVisualSettings;
function saveVisuals(change) {
  if (!session.model || session.model.preview) throw Error('preview');
  const s = loadVisuals();
  change(s);
  saveVisualSettings(s);
}
const themeOwner = () => session.accountId || viewState.actualThemeOwner || session.model.actor.id;
const currentStyle = () => loadVisuals().users?.[themeOwner()] || {};
function chooseStyle(choice, colors) {
  saveVisuals((s) => {
    s.users ||= {};
    const before = s.users[themeOwner()] || {};
    s.users[themeOwner()] = {
      ...before,
      choice,
      ...(colors
        ? {
            colors,
          }
        : {}),
    };
  });
}
export { chooseStyle, currentStyle, loadVisuals, saveVisuals };
