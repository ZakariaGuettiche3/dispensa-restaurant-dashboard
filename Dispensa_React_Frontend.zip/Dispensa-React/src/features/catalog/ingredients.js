import { activeItems, deleteButton, invTabs, listSearch, matches } from '../../templates/catalogControls.js';
import { detail, grid, head, note, panel, side, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { tableMarkup } from '../../templates/table.js';
import { translateHtml, label, translateText } from '../../i18n/translate.js';
import { formatQuantity, unitPrice } from '../../utils/format.js';
import { records, can, record, supName } from '../../state/selectors.js';
import { viewState } from '../../state/viewState.js';
import { field, fields, form, numberField, selectEnums } from '../../templates/forms.js';
import { Dispensa } from '../../domain/index.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
const renderIngredients = () => {
  const a = activeItems().filter((x) => matches([x.code, x.name]));
  return (
    head(
      'ingredients',
      'Base units, purchasing and recipe costs|Unità di base, acquisti e costi ricetta',
      navigationButton('Import|Importa', 'importer', '', 'Upload') +
        actionButton('Add ingredient|Aggiungi ingrediente', 'new:ingredient', 'primary', 'Plus'),
    ) +
    invTabs('ingredients') +
    panel(
      'Ingredient directory|Elenco ingredienti',
      listSearch() +
        tableMarkup(
          [
            'Ingredient|Ingrediente',
            'Unit|Unità',
            'On hand|Giacenza',
            'Average purchase price|Prezzo medio di acquisto',
            'Supplier prices|Prezzi fornitori',
          ],
          a.map((x) => [
            [
              detail(x.name, x.code),
              translateHtml(label(x.unit)),
              formatQuantity(x.qty, x.unit),
              unitPrice(x.avg),
              String(records('quotes').filter((q) => q.ing === x.id).length),
            ],
            'open:ingredient:' + x.id,
          ]),
          {
            paginate: true,
          },
        ),
    )
  );
};
const renderIngredient = () => {
  const x = record('ingredients', viewState.id) || {
    code: '',
    name: '',
    unit: 'kg',
    min: 0,
    tolerance: 500,
    avg: 0,
    qty: 0,
  };
  const quotes = records('quotes').filter((q) => q.ing === x.id);
  return (
    head(
      'ingredient',
      x.code || translateText('Catalog|Catalogo'),
      navigationButton('Ingredients|Ingredienti', 'ingredients'),
      x.name || 'New ingredient|Nuovo ingrediente',
    ) +
    grid(
      'g2',
      panel(
        'Ingredient details|Dati ingrediente',
        form(
          'ingredientSave',
          fields(
            field('Ingredient name|Nome ingrediente', 'name', x.name, 'text', 'required maxlength="180"'),
            field('Item code|Codice articolo', 'code', x.code, 'text', 'required maxlength="32"'),
            selectEnums('Base unit|Unità di base', 'unit', Dispensa.units, x.unit),
            numberField('Minimum on hand|Scorta minima', 'min', x.min / 1000),
            numberField('Count tolerance|Tolleranza conteggio', 'tolerance', x.tolerance / 1000),
          ),
          'Save ingredient|Salva ingrediente',
          x.id ? deleteButton('ingredientDelete', x.id) : '',
        ),
      ),
      side(
        'Supply costs|Costi di acquisto',
        'Inventory valuation|Valorizzazione magazzino',
        val('Current average / unit|Media attuale per unità', unitPrice(x.avg)) +
          val('On hand|Giacenza', formatQuantity(x.qty, x.unit)) +
          tableMarkup(
            ['Supplier|Fornitore', 'Quoted price|Prezzo offerto'],
            quotes.map((q) => [[escapeHtml(supName(q.supplier)), unitPrice(q.price)]]),
          ) +
          note(
            'Each receipt updates the average using the quantity received and the stock already on hand.|Ogni ricezione aggiorna la media in base alla quantità ricevuta e alla giacenza precedente.',
          ) +
          (x.id && can('stock')
            ? actionButton('View movements|Vedi movimenti', 'open:ledger:' + x.id, 'wide')
            : ''),
      ),
    )
  );
};
export { renderIngredient, renderIngredients };
