import { session } from '../../state/session.js';
import { viewState } from '../../state/viewState.js';
import { updatePhotoPreview } from './productPhoto.js';
import { syncRecipe } from '../../forms/liveCalculations.js';
import { captureInputs, restoreInputs } from '../../forms/fieldValues.js';
import { activeItems } from '../../templates/catalogControls.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
async function catalogAction(key, v, z) {
  if (key === 'removephoto') {
    if (session.model.preview || !['owner', 'manager'].includes(session.model.actor.role))
      throw Error('preview');
    viewState.photoDraft = null;
    const input = document.querySelector('[data-menu-photo]');
    if (input) input.value = '';
    updatePhotoPreview();
    return;
  }
  if (key === 'recipeAdd' || key === 'recipeRemove') {
    const f = document.querySelector('form[data-form="productSave"]');
    syncRecipe(f);
    const old = captureInputs();
    if (key === 'recipeAdd') {
      const x = activeItems().find((x) => !viewState.formula.some((r) => r.ing === x.id));
      if (!x) throw Error('duplicate');
      viewState.formula.push({
        ing: x.id,
        qty: 100,
      });
    } else viewState.formula.splice(Number(v), 1);
    refreshWorkspace();
    restoreInputs(old, (k) => /^(?:ing|qty)\d+$/.test(k));
    return;
  }
}
export { catalogAction };
