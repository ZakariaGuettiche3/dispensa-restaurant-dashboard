import { loadVisuals, saveVisuals } from '../../services/visualPreferences.js';
import { MENU_PHOTOS } from '../../assets/menuImages.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { actionButton, iconMarkup } from '../../templates/actions.js';
import { viewState } from '../../state/viewState.js';
import { translateHtml } from '../../i18n/translate.js';
import { field } from '../../templates/forms.js';
import { getElement } from '../../utils/dom.js';
import { can } from '../../state/selectors.js';
import { session } from '../../state/session.js';
function photoFor(id) {
  const map = loadVisuals().photos || {};
  if (Object.hasOwn(map, id)) return map[id];
  return MENU_PHOTOS[id] || null;
}
function productPhoto(p, cl = '') {
  const src = p?.id && photoFor(p.id);
  return src && /^data:image\/(?:jpeg|png|webp);base64,/.test(src)
    ? '<img class="menu-photo ' + cl + '" src="' + src + '" alt="' + escapeHtml(p.name) + '">'
    : '<span class="photo-empty ' +
        cl +
        '" aria-hidden="true">' +
        iconMarkup(
          p?.category === 'drinks' ? 'CupSoda' : p?.category === 'dessert' ? 'CakeSlice' : 'CookingPot',
          23,
        ) +
        '</span>';
}
function photoEditor(p) {
  return (
    '<div class="photo-edit"><div id="photoPreview">' +
    (viewState.photoDraft !== undefined
      ? viewState.photoDraft
        ? '<img class="menu-photo photo-large" alt="' +
          translateHtml('Selected product image|Immagine prodotto selezionata') +
          '" src="' +
          viewState.photoDraft +
          '">'
        : '<span class="photo-empty photo-large">' + iconMarkup('CookingPot', 24) + '</span>'
      : productPhoto(p, 'photo-large')) +
    '</div><div>' +
    field(
      (viewState.photoDraft !== undefined ? viewState.photoDraft : photoFor(p?.id))
        ? 'Replace photo · JPEG, PNG, WebP|Sostituisci foto · JPEG, PNG, WebP'
        : 'Upload photo · JPEG, PNG, WebP|Carica foto · JPEG, PNG, WebP',
      'menuFile',
      '',
      'file',
      'accept="image/jpeg,image/png,image/webp" data-menu-photo',
    ) +
    actionButton('Remove photo|Rimuovi foto', 'removephoto', '', 'Trash2') +
    '<small>' +
    translateHtml(
      'Save the product to apply photo changes.|Salva il prodotto per applicare le modifiche alla foto.',
    ) +
    '</small></div></div>'
  );
}
function updatePhotoPreview() {
  const n = getElement('photoPreview');
  if (n)
    n.innerHTML = viewState.photoDraft
      ? '<img class="menu-photo photo-large" alt="' +
        translateHtml('Selected product image|Immagine prodotto selezionata') +
        '" src="' +
        viewState.photoDraft +
        '">'
      : '<span class="photo-empty photo-large">' + iconMarkup('CookingPot', 24) + '</span>';
}
function persistPhoto(id, data) {
  if (!can('products') || !['manager', 'owner'].includes(session.model.actor.role)) throw Error('forbidden');
  saveVisuals((s) => {
    s.photos ||= {};
    s.photos[id] = data;
  });
}
export { persistPhoto, photoEditor, productPhoto, updatePhotoPreview };
