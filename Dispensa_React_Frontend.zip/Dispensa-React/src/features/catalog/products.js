import { session } from '../../state/session.js';
import {
  activeItems,
  choicesOf,
  deleteButton,
  eligible,
  invTabs,
  listSearch,
  matches,
  recipeFor,
  unitFor,
} from '../../templates/catalogControls.js';
import { detail, grid, head, note, panel, side, total, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { tableMarkup } from '../../templates/table.js';
import { Dispensa } from '../../domain/index.js';
import { photoEditor, productPhoto } from './productPhoto.js';
import { translateHtml, label, translateText } from '../../i18n/translate.js';
import { formatCurrency, formatNumber, formatQuantity, unitPrice } from '../../utils/format.js';
import { viewState } from '../../state/viewState.js';
import { field, fields, form, numberField, pick, selectEnums } from '../../templates/forms.js';
import { ingName, record } from '../../state/selectors.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
const renderProducts = () => {
  const m = ['owner', 'manager'].includes(session.model.actor.role),
    list = eligible('products').filter((x) => matches([x.code, x.name]));
  return (
    head(
      'products',
      'Selling prices, recipes and contribution per portion|Prezzi di vendita, ricette e margine per porzione',
      m ? actionButton('Add final product|Aggiungi prodotto finale', 'new:product', 'primary', 'Plus') : '',
    ) +
    invTabs('products') +
    panel(
      'Menu catalog|Catalogo menu',
      listSearch() +
        tableMarkup(
          [
            'Final product|Prodotto finale',
            'Category|Categoria',
            ...(m
              ? ['Selling price|Prezzo di vendita', 'Recipe cost|Costo ricetta', 'Gross margin|Margine lordo']
              : ['Ingredients|Ingredienti']),
          ],
          list.map((p) => {
            const cost = Dispensa.perPortion(session.model, p.id);
            return [
              [
                '<div class="catalog-product">' +
                  productPhoto(p, 'photo-thumb') +
                  '<span>' +
                  detail(p.name, p.code) +
                  '</span></div>',
                translateHtml(label(p.category)),
                ...(m
                  ? [formatCurrency(p.price), formatCurrency(cost), formatCurrency(p.price - cost)]
                  : [String(recipeFor(p.id).length)]),
              ],
              'open:product:' + p.id,
            ];
          }),
          {
            paginate: true,
          },
        ),
    )
  );
};
function recipeEditor() {
  const items = activeItems();
  return `<div id="recipeRows">${viewState.formula.map((r, i) => `<div class="recipeLine" data-line="${i}">${pick('Ingredient|Ingrediente', 'ing' + i, choicesOf(items), r.ing, 'data-recipe')}${numberField('Per portion|Per porzione', 'qty' + i, r.qty / 1000)}<span class="unit">${translateHtml(label(unitFor(r.ing)))}</span>${actionButton('Remove|Rimuovi', 'recipeRemove:' + i, '', 'Minus')}</div>`).join('')}</div>${actionButton('Add ingredient|Aggiungi ingrediente', 'recipeAdd', '', 'Plus')}`;
}
function recipeSummary() {
  let numerator = 0n;
  const list = viewState.formula
    .map((r) => {
      const x = record('ingredients', r.ing);
      if (!x) return null;
      const q = Math.max(0, Math.round(r.qty) || 0);
      numerator += BigInt(q) * BigInt(x.avg);
      return [
        [
          escapeHtml(x.name),
          formatQuantity(q, x.unit),
          unitPrice(x.avg),
          formatCurrency(Dispensa.valueCents(q, x.avg)),
        ],
      ];
    })
    .filter(Boolean);
  const cost = Dispensa.divRound(numerator, 10000000n),
    p = Number(viewState.editPrice || 0);
  return (
    tableMarkup(['Ingredient|Ingrediente', 'Qty|Qtà', 'Avg / unit|Media / unità', 'Cost|Costo'], list) +
    total('Cost per portion|Costo per porzione', formatCurrency(cost)) +
    val('Gross margin / portion|Margine lordo per porzione', formatCurrency(p - cost)) +
    val('Gross margin %|Margine lordo %', p ? formatNumber(((p - cost) / p) * 100, 1) + '%' : '—')
  );
}
const renderProduct = () => {
  const p = record('products', viewState.id) || {
      name: '',
      code: '',
      category: 'food',
      price: 0,
      version: 0,
    },
    m = ['owner', 'manager'].includes(session.model.actor.role);
  if (!m)
    return (
      head('product', p.code, navigationButton('Catalog|Catalogo', 'products'), p.name) +
      productPhoto(p, 'photo-large') +
      panel(
        'Ingredients per portion|Ingredienti per porzione',
        tableMarkup(
          ['Ingredient|Ingrediente', 'Quantity|Quantità'],
          recipeFor(p.id).map((r) => [[escapeHtml(ingName(r.ing)), formatQuantity(r.qty, unitFor(r.ing))]]),
        ),
      )
    );
  return (
    head(
      'product',
      p.code || translateText('Menu catalog|Catalogo menu'),
      navigationButton('Final products|Prodotti finali', 'products'),
      p.name || 'New final product|Nuovo prodotto finale',
    ) +
    grid(
      'g2',
      panel(
        'Product and ingredients|Prodotto e ingredienti',
        form(
          'productSave',
          photoEditor(p) +
            fields(
              field('Product name|Nome prodotto', 'name', p.name, 'text', 'required'),
              field('Item code|Codice articolo', 'code', p.code, 'text', 'required'),
              selectEnums(
                'Category|Categoria',
                'category',
                ['food', 'drinks', 'dessert', 'other'],
                p.category,
              ),
              numberField('Selling price (€)|Prezzo di vendita (€)', 'price', p.price / 100, '.01'),
            ) +
            `<div class="rule"></div><h3>${translateHtml('Recipe for one portion|Ricetta per una porzione')}</h3>` +
            recipeEditor(),
          'Save product & recipe|Salva prodotto e ricetta',
          p.id ? deleteButton('productDelete', p.id) : '',
        ),
      ),
      side(
        'Live recipe cost|Costo ricetta aggiornato',
        'Weighted average purchase prices|Prezzi medi ponderati di acquisto',
        `<div id="recipeCost">${recipeSummary()}</div>` +
          note(
            'Confirming a bill multiplies each ingredient quantity by the number of portions sold.|Confermando il conto, ogni quantità viene moltiplicata per le porzioni vendute.',
          ),
      ),
    )
  );
};
export { recipeSummary, renderProduct, renderProducts };
