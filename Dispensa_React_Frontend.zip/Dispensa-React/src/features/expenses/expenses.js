import {
  detail,
  grid,
  head,
  metric,
  note,
  panel,
  side,
  status,
  tabs,
  total,
  val,
} from '../../templates/layout.js';
import { records, record } from '../../state/selectors.js';
import { deleteButton, listSearch, matches } from '../../templates/catalogControls.js';
import { translateHtml, label, localized, translateText } from '../../i18n/translate.js';
import { actionButton, navigationButton, iconMarkup } from '../../templates/actions.js';
import { formatCurrency, formatDate } from '../../utils/format.js';
import { tableMarkup } from '../../templates/table.js';
import { viewState } from '../../state/viewState.js';
import { session } from '../../state/session.js';
import { area, box, field, fields, form, numberField, selectEnums } from '../../templates/forms.js';
import { Dispensa } from '../../domain/index.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
const expenseTabs = (k) =>
  tabs(
    [
      ['Expense register|Registro spese', 'go:expenses'],
      ['Recurring expenses|Spese ricorrenti', 'go:rules'],
    ],
    'go:' + k,
  );
const renderExpenses = () => {
  const rows = records('expenses')
    .filter(
      (e) => !e.archived && matches([e.id, localized(e.text), translateText(label(e.category)), e.supplier]),
    )
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
  const sum = (k) => rows.filter((e) => e.status === k).reduce((s, z) => s + z.amount, 0);
  return (
    head(
      'expenses',
      'Operating costs and supporting documents|Costi operativi e documenti giustificativi',
      actionButton('Add expense|Aggiungi spesa', 'new:expense', 'primary', 'Plus'),
    ) +
    expenseTabs('expenses') +
    grid(
      'g3 metrics',
      metric(
        'Recorded expenses|Spese registrate',
        formatCurrency(sum('paid') + sum('unpaid')),
        'Includes paid and unpaid records|Include le voci pagate e da pagare',
        'Wallet',
        true,
      ),
      metric(
        'Paid|Pagato',
        formatCurrency(sum('paid')),
        'Matching records|Voci corrispondenti',
        'CircleCheck',
      ),
      metric(
        'Outstanding|Da pagare',
        formatCurrency(sum('unpaid')),
        'Matching records|Voci corrispondenti',
        'Clock',
      ),
    ) +
    panel(
      'Expense register|Registro spese',
      listSearch() +
        tableMarkup(
          [
            'Expense|Spesa',
            'Category|Categoria',
            'Date|Data',
            'Amount|Importo',
            'Status|Stato',
            'Invoice|Fattura',
          ],
          rows.map((e) => [
            [
              detail(localized(e.text), e.id),
              translateHtml(label(e.category)),
              formatDate(e.date),
              formatCurrency(e.amount),
              status(e.status),
              records('files').some((f) => f.expense === e.id) ? iconMarkup('Paperclip') : '—',
            ],
            'open:expense:' + e.id,
          ]),
          {
            paginate: true,
          },
        ),
    )
  );
};
const renderExpense = () => {
  const e = record('expenses', viewState.id) || {
      date: session.today,
      category: 'electricity',
      status: 'unpaid',
    },
    f = records('files').find((x) => x.expense === e.id);
  return (
    head(
      'expense',
      e.id || '',
      navigationButton('Expense register|Registro spese', 'expenses'),
      e.id ? localized(e.text) : 'New expense|Nuova spesa',
    ) +
    grid(
      'g2',
      panel(
        'Expense details|Dettagli spesa',
        form(
          'expenseSave',
          fields(
            area('Description|Descrizione', 'text', localized(e.text)),
            selectEnums('Category|Categoria', 'category', Dispensa.categories, e.category),
            numberField(
              'Amount (€)|Importo (€)',
              'amount',
              e.amount == null ? '' : e.amount / 100,
              '.01',
              '.01',
            ),
            field('Expense date|Data spesa', 'date', e.date, 'date', 'required'),
            selectEnums('Payment status|Stato pagamento', 'status', ['draft', 'unpaid', 'paid'], e.status),
            field('Due date|Scadenza', 'due', e.due, 'date'),
            field('Payment date|Data pagamento', 'paidDate', e.paidDate, 'date'),
            field('Supplier / payee|Fornitore / beneficiario', 'supplier', e.supplier),
            field(
              'Invoice attachment · PDF, PNG or JPEG, up to 2 MB|Allegato fattura · PDF, PNG o JPEG, fino a 2 MB',
              'attachment',
              '',
              'file',
              'accept=".pdf,.png,.jpg,.jpeg"',
            ),
            f ? box('Remove current attachment|Rimuovi allegato attuale', 'removeFile') : ' ',
          ),
          'Save expense|Salva spesa',
          e.id ? deleteButton('expenseDelete', e.id) : '',
        ),
      ),
      side(
        'Expense summary|Riepilogo spesa',
        'Accounting record|Registrazione contabile',
        val('Status|Stato', status(e.status)) +
          val('Reference|Riferimento', escapeHtml(e.id || '—')) +
          total('Amount|Importo', formatCurrency(e.amount)) +
          (f
            ? actionButton(f.name, 'file:' + f.id, 'wide', 'Download')
            : note(
                'An invoice or receipt can be attached to this record.|Puoi allegare una fattura o una ricevuta a questa registrazione.',
              )),
      ),
    )
  );
};
export { expenseTabs, renderExpense, renderExpenses };
