import { records, record } from '../../state/selectors.js';
import { viewState } from '../../state/viewState.js';
import { session } from '../../state/session.js';
import { detail, grid, head, panel } from '../../templates/layout.js';
import { actionButton } from '../../templates/actions.js';
import { expenseTabs } from './expenses.js';
import { tableMarkup } from '../../templates/table.js';
import { label, localized, translateText } from '../../i18n/translate.js';
import { formatCurrency, formatDate } from '../../utils/format.js';
import { area, field, fields, form, numberField, selectEnums } from '../../templates/forms.js';
import { Dispensa } from '../../domain/index.js';
const renderRules = () => {
  const r = record('rules', viewState.id) || {
    category: 'rent',
    frequency: 'monthly',
    next: session.today,
    mode: 'review',
  };
  return (
    head('rules', '', actionButton('New rule|Nuova regola', 'new:rules', 'primary', 'Plus')) +
    expenseTabs('rules') +
    grid(
      'g2',
      panel(
        'Recurring schedule|Scadenziario',
        tableMarkup(
          ['Expense|Spesa', 'Next due|Prossima scadenza', 'Amount|Importo', 'Action|Azione'],
          records('rules')
            .filter((z) => z.active)
            .map((z) => [
              [
                detail(localized(z.text), translateText(label(z.frequency))),
                formatDate(z.next),
                formatCurrency(z.amount),
                z.next <= session.today
                  ? actionButton('Post due entry|Registra scadenza', 'runrule:' + z.id)
                  : '—',
              ],
              'open:rules:' + z.id,
            ]),
        ),
      ),
      panel(
        'Rule details|Dettagli regola',
        form(
          'ruleSave',
          fields(
            area('Description|Descrizione', 'text', localized(r.text)),
            selectEnums('Category|Categoria', 'category', Dispensa.categories, r.category),
            numberField('Amount (€)|Importo (€)', 'amount', r.amount ? r.amount / 100 : '', '.01', '.01'),
            field('Next due|Prossima scadenza', 'next', r.next, 'date', 'required'),
            selectEnums('Frequency|Frequenza', 'frequency', ['monthly', 'weekly', 'yearly'], r.frequency),
            selectEnums('On posting|Alla registrazione', 'mode', ['automatic', 'review'], r.mode),
          ),
          'Save rule|Salva regola',
        ),
      ),
    )
  );
};
export { renderRules };
