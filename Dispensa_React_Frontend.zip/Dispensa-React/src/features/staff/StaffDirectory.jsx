import React from 'react';
import { useSearchableList } from '../../hooks/useSearchableList.js';
const headers = [
  'Employee|Dipendente',
  'Position|Mansione',
  'Role|Ruolo',
  'Start date|Data inizio',
  'Status|Stato',
  'Access|Accesso',
];
function matches(employee, query) {
  return [employee.name, employee.email, employee.role].some((value) =>
    value.toLocaleLowerCase().includes(query),
  );
}
function EmployeeRow({ employee, translate }) {
  return (
    <tr>
      <td>
        <button className="staff-name" data-ui={'open:person:' + employee.id}>
          <b>{employee.name}</b>
          <small>{employee.email}</small>
        </button>
      </td>
      <td>{employee.position}</td>
      <td>{employee.role}</td>
      <td>{employee.start}</td>
      <td>
        <span
          className={
            'tag ' + (employee.status === 'active' ? 'ok' : employee.status === 'ended' ? 'bad' : 'neutral')
          }
        >
          {employee.statusLabel}
        </span>
      </td>
      <td>
        {employee.canPreview ? (
          <button className="button" data-ui={'preview:' + employee.id}>
            {translate('Preview role|Anteprima ruolo')}
          </button>
        ) : (
          '—'
        )}
      </td>
    </tr>
  );
}
export function StaffDirectory({ employees, translate, role }) {
  const list = useSearchableList(employees, matches);
  return (
    <>
      <header className="head">
        <div>
          <div className="eyebrow">
            {role} / {translate('Staff management|Gestione personale')}
          </div>
          <h1>{translate('Staff management|Gestione personale')}</h1>
          <p className="subtitle">
            {translate('Profiles, roles and access permissions|Profili, ruoli e permessi di accesso')}
          </p>
        </div>
        <button className="button primary" data-ui="new:person">
          {translate('Add staff member|Aggiungi dipendente')}
        </button>
      </header>
      <section className="panel">
        <div className="paneltop">
          <h2>{translate('Staff directory|Elenco del personale')}</h2>
        </div>
        <div className="tools">
          <label className="search">
            <input
              type="search"
              aria-label={translate('Search staff|Cerca personale')}
              placeholder={translate('Search staff|Cerca personale')}
              value={list.query}
              onChange={(event) => list.searchFor(event.target.value)}
            />
          </label>
        </div>
        <div className="tablewrap">
          <table className="table">
            <thead>
              <tr>
                {headers.map((header) => (
                  <th key={header}>{translate(header)}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {list.items.map((employee) => (
                <EmployeeRow key={employee.id} employee={employee} translate={translate} />
              ))}
            </tbody>
          </table>
          {!list.items.length && (
            <p className="nores">{translate('No matching records.|Nessun dato corrispondente.')}</p>
          )}
        </div>
        {list.pageCount > 1 && (
          <div className="tablePages">
            <button className="button" disabled={!list.page} onClick={() => list.setPage(list.page - 1)}>
              {translate('Previous|Precedente')}
            </button>
            <span>
              {list.page + 1} / {list.pageCount}
            </span>
            <button
              className="button"
              disabled={list.page + 1 === list.pageCount}
              onClick={() => list.setPage(list.page + 1)}
            >
              {translate('Next|Successiva')}
            </button>
          </div>
        )}
      </section>
    </>
  );
}
