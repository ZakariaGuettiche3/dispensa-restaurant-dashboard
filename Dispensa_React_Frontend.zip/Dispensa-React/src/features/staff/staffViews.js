import { records, record } from '../../state/selectors.js';
import { deleteButton } from '../../templates/catalogControls.js';
import { translateHtml, label, localized, roleText, translateText } from '../../i18n/translate.js';
import { grid, head, note, panel, side, status, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { formatDate } from '../../utils/format.js';
import { session } from '../../state/session.js';
import { Dispensa } from '../../domain/index.js';
import { box, field, fields, form, pick, selectEnums } from '../../templates/forms.js';
import { viewState } from '../../state/viewState.js';
const renderStaff = () => {
  return {
    kind: 'staff',
    employees: records('staff').map((employee) => ({
      id: employee.id,
      name: employee.name,
      email: employee.email,
      position: localized(employee.position) || '—',
      role: translateText(roleText(employee.role)),
      start: formatDate(employee.start),
      status: employee.status,
      statusLabel: translateText(label(employee.status)),
      canPreview: employee.status === 'active' && employee.id !== session.model.actor.id,
    })),
  };
};
function accessFields(role, denied = []) {
  const keys = Object.keys(Dispensa.groups).filter(
    (k) => Dispensa.groups[k].includes(role) && !['settings', 'cashier', 'staff', 'organization'].includes(k),
  );
  if (!keys.length || role === 'owner')
    return note(
      role === 'cashier'
        ? 'Cashiers can manage bills and payments in the cashier workspace.|I cassieri possono gestire conti e pagamenti nell’area cassa.'
        : 'The owner controls staff accounts and permissions.|Il titolare gestisce gli account e i permessi del personale.',
    );
  return `<h3>${translateHtml('Allowed sections|Sezioni consentite')}</h3><div class="checks">${keys.map((k) => box(label(k), 'allow_' + k, !denied.includes(k))).join('')}</div>`;
}
const renderPerson = () => {
  const u = record('staff', viewState.id) || {
    role: 'cashier',
    status: 'active',
    start: session.today,
    access: [],
  };
  return (
    head(
      'person',
      u.id || '',
      navigationButton('Staff directory|Elenco personale', 'staff'),
      u.name || 'New staff member|Nuovo dipendente',
    ) +
    grid(
      'g2',
      panel(
        'Staff profile|Scheda dipendente',
        form(
          'staffSave',
          fields(
            field('Full name|Nome e cognome', 'name', u.name, 'text', 'required'),
            field('Work email|Email di lavoro', 'email', u.email, 'email', 'required'),
            field('Address|Indirizzo', 'address', u.address),
            field('Telephone|Telefono', 'phone', u.phone, 'tel'),
            field('Job position|Mansione', 'position', localized(u.position)),
            pick(
              'Assigned role|Ruolo assegnato',
              'role',
              Dispensa.roles.map((k) => [k, roleText(k)]),
              u.role,
              'data-staff-role',
            ),
            field('Employment start|Inizio impiego', 'start', u.start, 'date', 'required'),
            field('Employment end|Fine impiego', 'end', u.end, 'date'),
            selectEnums(
              'Employment status|Stato rapporto',
              'status',
              ['active', 'inactive', 'ended'],
              u.status,
            ),
            '',
          ) + `<div id="accessFields">${accessFields(u.role, u.access)}</div>`,
          'Save staff profile|Salva profilo',
          u.id && u.id !== session.model.actor.id ? deleteButton('staffDelete', u.id) : '',
        ),
      ),
      side(
        'Role preview|Anteprima ruolo',
        'Account access|Accesso account',
        val('Assigned role|Ruolo assegnato', translateHtml(roleText(u.role))) +
          val('Account status|Stato account', status(u.status)) +
          note(
            'Explore the sections available to this employee. Changes and transactions are disabled in preview.|Esplora le sezioni accessibili a questo dipendente. In anteprima modifiche e transazioni sono disabilitate.',
          ) +
          (u.id && u.status === 'active' && u.id !== session.model.actor.id
            ? actionButton('Preview this role|Anteprima di questo ruolo', 'preview:' + u.id, 'wide', 'Eye')
            : ''),
      ),
    )
  );
};
export { accessFields, renderPerson, renderStaff };
