import { savePreview } from '../../services/browserStorage.js';
import { session } from '../../state/session.js';
import { can } from '../../state/selectors.js';
import { viewState } from '../../state/viewState.js';
import { Dispensa } from '../../domain/index.js';
import { refreshRoleProjection } from '../../services/restaurantSession.js';
import { goHome, replaceHash, routeTo } from '../../navigation/router.js';
async function preview(staff) {
  if (staff) {
    if (session.model.preview || !can('staff')) throw Error('forbidden');
    viewState.previewOrigin = {
      page: viewState.page === 'person' ? 'person' : 'staff',
      id: viewState.page === 'person' ? viewState.id : '',
    };
    viewState.actualThemeOwner = session.model.actor.id;
  }
  const origin = viewState.previewOrigin || {
    page: 'staff',
    id: '',
  };
  if (staff) Dispensa.project(session.restaurant, session.accountId, staff);
  session.previewId = staff;
  refreshRoleProjection();
  savePreview(
    staff
      ? {
          owner: session.accountId,
          staff,
          origin,
        }
      : null,
  );
  if (staff) {
    goHome();
  } else {
    viewState.previewOrigin = null;
    viewState.actualThemeOwner = null;
    routeTo(origin.page, origin.id, false);
    replaceHash();
  }
  document.querySelector(session.model.preview ? '.previewbar' : 'main h1')?.scrollIntoView?.({
    block: 'nearest',
  });
}
export { preview };
