import React from 'react';

function Panel({ title, action, model, children }) {
  return (
    <section className="panel">
      <div className="paneltop">
        <h2>{model.translate(title)}</h2>
        {model.canReport && (
          <button className="button" data-ui={'chartreport:' + action}>
            {model.translate('Details|Dettagli')}
          </button>
        )}
      </div>
      {children}
    </section>
  );
}
const metrics = [
  ['Revenue|Ricavi', 'revenue'],
  ['Ingredient cost|Costo ingredienti', 'cost'],
  ['Operating expenses|Spese operative', 'expense'],
  ['Operating result|Risultato operativo', 'profit'],
];
export default function OwnerCharts({ model, charts }) {
  const { current, previous } = charts;
  const { translate: t, currency } = model;
  const paid = current.cash + current.card,
    cash = paid ? Math.round((current.cash / paid) * 100) : 0;
  const periods = previous ? [current, previous] : [current];
  const maximum = Math.max(
    1,
    ...periods.flatMap((period) => metrics.map(([, key]) => Math.abs(period[key]))),
  );
  return (
    <div className="grid equal">
      <Panel title="Payment mix|Ripartizione incassi" action="mix" model={model}>
        <div className="mix-chart">
          <div
            className="pie"
            role="img"
            aria-label={t('Cash|Contanti') + ' ' + cash + '%'}
            style={{
              background: paid
                ? 'conic-gradient(var(--plot) 0 ' + cash + '%, var(--plot2) ' + cash + '% 100%)'
                : 'var(--chip)',
            }}
          >
            <b>{currency(paid)}</b>
          </div>
          <div>
            {[
              ['Cash|Contanti', current.cash, cash],
              ['Card|Carta', current.card, 100 - cash],
            ].map(([title, value, share]) => (
              <p key={title}>
                <b>{t(title)}</b> {currency(value)} · {paid ? share + '%' : '—'}
              </p>
            ))}
          </div>
        </div>
      </Panel>
      <Panel title="Period comparison|Confronto periodi" action="performance" model={model}>
        <p className="hintline">
          {t('Selected period|Periodo selezionato')}
          {previous && ' / ' + t('Comparison period|Periodo di confronto')}
        </p>
        {metrics.map(([label, key]) => (
          <div className="compare-row" key={key}>
            <b>{t(label)}</b>
            <div>
              {periods.map((period, i) => (
                <div key={i} className="compare-line">
                  <i
                    style={{
                      width: (Math.abs(period[key]) / maximum) * 70 + '%',
                      background: i ? 'var(--plot2)' : 'var(--plot)',
                    }}
                  />
                  <span>{currency(period[key])}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </Panel>
    </div>
  );
}
