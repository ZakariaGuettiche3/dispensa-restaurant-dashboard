import { translateHtml, translateText } from '../../i18n/translate.js';
import * as Reports from '../../services/reports.js';
import { formatCurrency, formatDate, formatNumber } from '../../utils/format.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { grid, head, metric, note, panel, total, val } from '../../templates/layout.js';
import { periodBar, rangeData } from '../reports/periodFilter.js';
import { can } from '../../state/selectors.js';
import { navigationButton } from '../../templates/actions.js';
import { session } from '../../state/session.js';
import { tableMarkup } from '../../templates/table.js';
function delta(r, p, k, fmt) {
  if (!p) return translateText('Selected period|Periodo selezionato');
  if (!p[k] || r[k] == null)
    return translateText('Comparison base unavailable|Base di confronto non disponibile');
  const diff = r[k] - p[k];
  return (diff > 0 ? '+' : '') + fmt(diff) + ' ' + translateText('vs comparison|rispetto al confronto');
}
function trend(r, range) {
  const series = Reports.series(r, ...range),
    max = Math.max(0, ...series.flatMap((x) => [x.revenue, x.profit])),
    min = Math.min(0, ...series.flatMap((x) => [x.revenue, x.profit])),
    span = max - min || 1,
    zero = 4 + (-min / span) * 91;
  const bars = series
    .map((z, i) => {
      const d = formatDate(z.from, true) + (z.from === z.to ? '' : ' – ' + formatDate(z.to, true)),
        desc =
          d +
          ' · ' +
          translateText('Revenue|Ricavi') +
          ' ' +
          formatCurrency(z.revenue) +
          ' · ' +
          translateText('Operating result|Risultato operativo') +
          ' ' +
          formatCurrency(z.profit);
      return `<button class="chartbucket" data-chart="${escapeHtml(desc)}" data-ui="drill:${z.from}:${z.to}" aria-label="${escapeHtml(desc)}" title="${escapeHtml(desc)}"><i class="zeroline" style="bottom:${zero}%"></i>${[
        ['revenue', z.revenue],
        ['profit', z.profit],
      ]
        .map(
          ([k, value]) =>
            `<i class="bar ${k} ${value < 0 ? 'down' : ''}" style="height:${(Math.abs(value) / span) * 91}%;bottom:${value < 0 ? zero - (Math.abs(value) / span) * 91 : zero}%"></i>`,
        )
        .join('')}</button>`;
    })
    .join('');
  return panel(
    'Revenue and operating result|Ricavi e risultato operativo',
    `<div class="chartframe"><div class="chartscale"><span>${escapeHtml(formatCurrency(max))}</span><span>${escapeHtml(formatCurrency(min))}</span></div><div class="chartarea">${bars}</div></div><div class="chartlabels"><span>${escapeHtml(formatDate(range[0], true))}</span><span>${escapeHtml(formatDate(range[1], true))}</span></div><p class="hintline" id="chartTip">${translateHtml('Select a bar to see sales for that interval.|Seleziona una barra per vedere le vendite del periodo.')}</p>`,
    `<div class="legend"><span><i class="swatch"></i>${translateHtml('Revenue|Ricavi')}</span><span><i class="swatch gold"></i>${translateHtml('Result|Risultato')}</span></div>`,
  );
}
function ranking(r) {
  const set = r.products
      .slice()
      .sort((a, b) => b.qty - a.qty || b.revenue - a.revenue)
      .slice(0, 5),
    max = Math.max(1, ...set.map((z) => z.qty));
  return panel(
    'Best-selling products|Prodotti più venduti',
    set.length
      ? set
          .map(
            (z) =>
              `<button class="rank" data-ui="soldproduct:${escapeHtml(z.id)}"><span>${escapeHtml(z.name)}</span><b>${formatNumber(z.qty)} ${translateHtml('sold|venduti')}</b><span class="rankbar"><i style="width:${(Math.max(0, z.qty) / max) * 100}%"></i></span></button>`,
          )
          .join('')
      : note('No settled sales in this period.|Nessuna vendita saldata nel periodo.'),
  );
}
function overviewMetrics(r, p) {
  return grid(
    'g4 metrics',
    metric(
      'Sales revenue|Ricavi delle vendite',
      formatCurrency(r.revenue),
      delta(r, p, 'revenue', formatCurrency),
      'ReceiptText',
      true,
    ),
    metric(
      'Paid orders|Ordini saldati',
      formatNumber(r.orders),
      delta(r, p, 'orders', formatNumber),
      'ShoppingBag',
    ),
    metric(
      'Average order|Scontrino medio',
      formatCurrency(r.aov),
      delta(r, p, 'aov', formatCurrency),
      'WalletCards',
    ),
    metric(
      'Estimated operating result|Risultato operativo stimato',
      formatCurrency(r.profit),
      delta(r, p, 'profit', formatCurrency),
      'ChartNoAxesColumnIncreasing',
    ),
  );
}
function resultRows(r) {
  return (
    val('Revenue after refunds|Ricavi dopo i rimborsi', formatCurrency(r.revenue)) +
    val('Ingredient cost of sales|Costo ingredienti venduti', formatCurrency(r.cost)) +
    val('Gross margin|Margine lordo', formatCurrency(r.gross)) +
    val('Operating expenses|Spese operative', formatCurrency(r.expense)) +
    val('Stock losses|Perdite di magazzino', formatCurrency(r.loss)) +
    val('Inventory gains|Eccedenze inventariali', formatCurrency(r.gain)) +
    total('Estimated operating result|Risultato operativo stimato', formatCurrency(r.profit))
  );
}
function productRows(r) {
  return r.products.map((x) => [
    [
      escapeHtml(x.name),
      formatNumber(x.qty),
      formatCurrency(x.revenue),
      formatCurrency(x.cost),
      formatCurrency(x.revenue - x.cost),
    ],
    'soldproduct:' + x.id,
  ]);
}
const renderOverview = () => {
  const { range, prev, r, p } = rangeData();
  const summary =
    head(
      'overview',
      formatDate(range[0]) + ' – ' + formatDate(range[1]),
      can('reports')
        ? navigationButton('Open reports|Apri report', 'reports', 'primary', 'ChartNoAxesColumnIncreasing')
        : '',
      'Restaurant overview|Panoramica ristorante',
    ) +
    periodBar() +
    overviewMetrics(r, p) +
    grid('g2', trend(r, range), ranking(r));
  const products = panel(
    'Product performance|Andamento per prodotto',
    tableMarkup(
      [
        'Product|Prodotto',
        'Units sold|Unità vendute',
        'Net revenue|Ricavi netti',
        'Ingredient cost|Costo ingredienti',
        'Gross margin|Margine lordo',
      ],
      productRows(r).slice(0, 8),
    ),
    p
      ? `<span class="caption">${translateHtml('Compared with|Confronto con')} ${escapeHtml(formatDate(prev[0], true))} – ${escapeHtml(formatDate(prev[1], true))}</span>`
      : '',
  );
  return {
    kind: 'overview',
    summary,
    products,
    charts:
      session.model.actor.role === 'owner'
        ? {
            current: r,
            previous: p,
          }
        : null,
  };
};
export { ranking, renderOverview, resultRows };
