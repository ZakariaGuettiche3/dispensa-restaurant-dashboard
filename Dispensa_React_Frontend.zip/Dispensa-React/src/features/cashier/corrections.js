import { selectedSale } from './register.js';
import { grid, head, note, panel, side, status, total, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { records, record } from '../../state/selectors.js';
import { viewState } from '../../state/viewState.js';
import { area, field, fields, form, numberField, pick, selectEnums } from '../../templates/forms.js';
import { translateHtml, label } from '../../i18n/translate.js';
import { formatCurrency } from '../../utils/format.js';
import { tableMarkup } from '../../templates/table.js';
const renderCorrection = () => {
  const b = selectedSale();
  if (!b) return head('correction') + navigationButton('Bill register|Registro conti', 'bills');
  const e = record('requests', viewState.execution);
  if (e && e.ref === b.id && e.status === 'approved')
    return (
      head('correction', b.id, actionButton('Bill|Conto', 'open:receipt:' + b.id)) +
      grid(
        'g2',
        panel(
          'Apply approved correction|Applica rettifica approvata',
          form(
            'applyCorrection',
            fields(
              field(
                'Payout / transaction reference|Riferimento rimborso / transazione',
                'ref',
                '',
                'text',
                e.kind === 'refund' ? 'required' : '',
              ),
            ),
            'Apply correction|Applica rettifica',
          ),
        ),
        side(
          'Approved terms|Condizioni approvate',
          e.id,
          val('Correction|Rettifica', translateHtml(label(e.kind))) +
            val('Stock treatment|Trattamento scorte', translateHtml(label(e.details.outcome))) +
            total('Amount|Importo', formatCurrency(e.impact)),
        ),
      )
    );
  const lines = records('saleLines').filter((l) => l.sale === b.id && l.qtyReversed < l.qty),
    recent = records('requests').filter((r) => r.ref === b.id);
  return (
    head('correction', b.id, actionButton('Back to bill|Torna al conto', 'open:receipt:' + b.id)) +
    grid(
      'g2',
      panel(
        'Request a correction|Richiedi una rettifica',
        form(
          'requestCorrection',
          fields(
            selectEnums(
              'Correction type|Tipo di rettifica',
              'kind',
              ['refund', 'discount', 'cancel'],
              b.paid ? 'refund' : 'cancel',
            ),
            pick(
              'Bill line|Riga conto',
              'line',
              lines.map((l) => [l.id, l.name + ' · ' + formatCurrency(l.unit)]),
            ),
            numberField('Portions|Porzioni', 'qty', 1, '1', '1'),
            numberField('Amount (€)|Importo (€)', 'amount', '', '.01', '.01'),
            area('Reason|Motivo', 'reason'),
          ),
          'Send for approval|Invia per approvazione',
        ),
      ),
      side(
        'Correction history|Storico rettifiche',
        'Customer bill|Conto cliente',
        val('Total paid|Totale incassato', formatCurrency(b.paid)) +
          tableMarkup(
            ['Type|Tipo', 'Amount|Importo', 'Status|Stato'],
            recent.map((r) => [[translateHtml(label(r.kind)), formatCurrency(r.impact), status(r.status)]]),
          ) +
          note(
            'The owner reviews the request. A cashier completes the approved transaction.|Il titolare valuta la richiesta. Un cassiere completa la transazione approvata.',
          ),
      ),
    )
  );
};
export { renderCorrection };
