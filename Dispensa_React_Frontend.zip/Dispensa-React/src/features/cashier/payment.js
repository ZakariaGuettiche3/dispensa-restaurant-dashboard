import { grid, head, panel, side, tabs, total, val } from '../../templates/layout.js';
import { formatCurrency } from '../../utils/format.js';
import { selectedSale } from './register.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { viewState } from '../../state/viewState.js';
import { fields, form, numberField } from '../../templates/forms.js';
function paySummary(b, cash, card, tendered) {
  const due = b.total - b.paid;
  return (
    val('Outstanding before payment|Da pagare prima dell’incasso', formatCurrency(due)) +
    val('This payment|Questo pagamento', formatCurrency(cash + card)) +
    val('Change to customer|Resto al cliente', formatCurrency(Math.max(0, tendered - cash))) +
    total('Remaining|Residuo', formatCurrency(due - cash - card))
  );
}
const renderPayment = () => {
  const b = selectedSale();
  if (!b) return head('payment') + navigationButton('Bill register|Registro conti', 'bills');
  const due = b.total - b.paid,
    method = viewState.payment || 'mixed',
    cash = method === 'cash' ? due : 0,
    card = method === 'cash' ? 0 : due;
  return (
    head('payment', b.id, actionButton('Back to bill|Torna al conto', 'open:receipt:' + b.id)) +
    grid(
      'g2',
      panel(
        'Payment method|Metodo di pagamento',
        tabs(
          [
            ['Cash|Contanti', 'method:cash'],
            ['Card|Carta', 'method:card'],
            ['Mixed|Misto', 'method:mixed'],
          ],
          'method:' + method,
        ) +
          form(
            'pay',
            fields(
              method === 'card'
                ? ''
                : numberField('Cash applied (€)|Contanti incassati (€)', 'cash', cash / 100, '.01'),
              method === 'cash'
                ? ''
                : numberField('Card charged (€)|Addebito carta (€)', 'card', card / 100, '.01'),
              method === 'card'
                ? ''
                : numberField('Cash tendered (€)|Contanti consegnati (€)', 'tendered', cash / 100, '.01'),
            ),
            'Record payment|Registra pagamento',
          ),
      ),
      side(
        'Payment summary|Riepilogo pagamento',
        'Customer bill|Conto cliente',
        `<div id="paymentPreview">${paySummary(b, cash, card, cash)}</div>`,
      ),
    )
  );
};
export { paySummary, renderPayment };
