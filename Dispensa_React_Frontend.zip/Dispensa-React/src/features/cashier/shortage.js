import { grid, head, note, panel, side, total } from '../../templates/layout.js';
import { navigationButton } from '../../templates/actions.js';
import { tableMarkup } from '../../templates/table.js';
import { viewState } from '../../state/viewState.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { record } from '../../state/selectors.js';
import { formatCurrency, formatNumber } from '../../utils/format.js';
import { basketTotal } from './register.js';
const renderShortage = () =>
  head('shortage', '', navigationButton('Return to bill|Torna al conto', 'cashier')) +
  grid(
    'g2',
    panel(
      'Insufficient stock|Scorte insufficienti',
      note(
        'The ingredients available cannot cover all portions on this bill. The cashier can adjust quantities or resume after stock staff record a count or delivery.|Gli ingredienti disponibili non coprono tutte le porzioni del conto. Il cassiere può modificare le quantità o riprendere dopo la registrazione di un conteggio o di una consegna.',
        'warn',
      ) +
        tableMarkup(
          ['Product|Prodotto', 'Portions|Porzioni'],
          viewState.basket.map((r) => [
            [escapeHtml(record('products', r.product)?.name || r.product), formatNumber(r.qty)],
          ]),
        ),
    ),
    side(
      'Current bill|Conto attuale',
      'Cashier|Cassa',
      total('Bill total|Totale conto', formatCurrency(basketTotal())) +
        navigationButton('Edit bill|Modifica conto', 'cashier', 'primary wide'),
    ),
  );
export { renderShortage };
