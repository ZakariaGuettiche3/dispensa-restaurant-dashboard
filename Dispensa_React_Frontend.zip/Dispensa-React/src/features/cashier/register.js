import { detail, grid, head, note, panel, side, status, tabs, total } from '../../templates/layout.js';
import { viewState } from '../../state/viewState.js';
import { actorName, records, record } from '../../state/selectors.js';
import { formatCurrency, formatDate } from '../../utils/format.js';
import { actionButton } from '../../templates/actions.js';
import { eligible, listSearch, matches } from '../../templates/catalogControls.js';
import { translateHtml, label } from '../../i18n/translate.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { productPhoto } from '../catalog/productPhoto.js';
import { tableMarkup } from '../../templates/table.js';
import { payLabel } from '../sales/history.js';
const tillTabs = (k) =>
  tabs(
    [
      ['New bill|Nuovo conto', 'go:cashier'],
      ['Bill register|Registro conti', 'go:bills'],
    ],
    'go:' + k,
  );
const basketTotal = () =>
  viewState.basket.reduce((sum, row) => sum + (record('products', row.product)?.price || 0) * row.qty, 0);
const selectedSale = () => record('sales', viewState.id || viewState.billId);
function basketContent() {
  const list = viewState.basket
    .map((r) => {
      const p = record('products', r.product);
      if (!p) return '';
      return `<div class="cartrow"><div>${detail(p.name, formatCurrency(p.price))}</div><div class="countstep">${actionButton('−', 'basketdec:' + p.id)}<b>${r.qty}</b>${actionButton('+', 'basketadd:' + p.id)}</div><strong>${formatCurrency(p.price * r.qty)}</strong></div>`;
    })
    .join('');
  return (
    (list || note('Choose a menu item to start the bill.|Scegli una voce del menu per iniziare il conto.')) +
    total('Bill total|Totale conto', formatCurrency(basketTotal())) +
    `<div class="footactions">${actionButton('Save draft|Salva bozza', 'tillsave:draft')}${actionButton('Confirm bill|Conferma conto', 'tillsave:confirm', 'primary', 'Check')}</div>`
  );
}
const renderCashier = () => {
  const list = eligible('products').filter(
    (p) => (viewState.category === 'all' || viewState.category === p.category) && matches([p.name, p.code]),
  );
  return (
    head(
      'cashier',
      'Customer bills and payments|Conti clienti e pagamenti',
      viewState.billId ? actionButton('Start new bill|Inizia nuovo conto', 'fresh', '', 'Plus') : '',
      'Cashier desk|Postazione cassa',
    ) +
    tillTabs('cashier') +
    grid(
      'g2',
      panel(
        'Menu|Menu',
        listSearch() +
          tabs(
            [
              ['All|Tutto', 'cat:all'],
              ...['food', 'drinks', 'dessert', 'other'].map((k) => [label(k), 'cat:' + k]),
            ],
            'cat:' + viewState.category,
          ) +
          `<div class="shelf">${list.map((p) => `<button class="product" data-ui="basketadd:${escapeHtml(p.id)}">${productPhoto(p, 'till-photo')}<b>${escapeHtml(p.name)}</b><small>${translateHtml(label(p.category))}</small><strong>${formatCurrency(p.price)}</strong></button>`).join('')}</div>`,
      ),
      side(
        viewState.billId || 'Current bill|Conto attuale',
        'Order summary|Riepilogo ordine',
        basketContent(),
      ),
    )
  );
};
const renderBills = () => {
  const key = viewState.tillFilter || 'all',
    list = records('sales')
      .slice()
      .reverse()
      .filter(
        (b) =>
          (key === 'all' ||
            (key === 'draft'
              ? b.status === 'draft'
              : key === 'paid'
                ? !!b.settled
                : b.status === 'confirmed' && !b.settled)) &&
          matches([b.id, actorName(b.actor)]),
      );
  return (
    head('bills', '', actionButton('New bill|Nuovo conto', 'fresh', 'primary', 'Plus')) +
    tillTabs('bills') +
    panel(
      'Customer bills|Conti clienti',
      listSearch() +
        tabs(
          [
            ['All|Tutti', 'all'],
            ['Unpaid or partial|Aperti o parziali', 'unpaid'],
            ['Paid|Pagati', 'paid'],
            ['Drafts|Bozze', 'draft'],
          ].map(([n, k]) => [n, 'tillfilter:' + k]),
          'tillfilter:' + key,
        ) +
        tableMarkup(
          [
            'Bill|Conto',
            'Date|Data',
            'Cashier|Cassiere',
            'Status|Stato',
            'Payment|Pagamento',
            'Total|Totale',
          ],
          list.map((b) => [
            [
              escapeHtml(b.id),
              formatDate(b.date),
              escapeHtml(actorName(b.actor)),
              status(b.status),
              escapeHtml(payLabel(b)),
              formatCurrency(b.total),
            ],
            'open:receipt:' + b.id,
          ]),
          {
            paginate: true,
          },
        ),
    )
  );
};
export { basketTotal, renderBills, renderCashier, selectedSale };
