import { viewState } from '../../state/viewState.js';
import { routeTo } from '../../navigation/router.js';
import { records, can, record } from '../../state/selectors.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
import { executeCommand } from '../../services/restaurantSession.js';
import { notifyUser } from '../../services/notifications.js';
async function cashierAction(key, v, z) {
  if (key === 'fresh') {
    viewState.basket = [];
    viewState.billId = null;
    return routeTo('cashier');
  }
  if (key === 'resume') {
    const b = record('sales', v);
    if (b?.status !== 'draft') throw Error('state');
    viewState.billId = b.id;
    viewState.basket = records('saleLines')
      .filter((l) => l.sale === b.id)
      .map((l) => ({
        product: l.product,
        qty: l.qty,
      }));
    return routeTo('cashier');
  }
  if (key === 'basketadd' || key === 'basketdec') {
    if (!can('cashier')) throw Error('forbidden');
    const p = record('products', v);
    if (!p?.active) throw Error('inactive');
    const row = viewState.basket.find((r) => r.product === v);
    if (row) {
      row.qty += key === 'basketadd' ? 1 : -1;
      if (row.qty <= 0) viewState.basket = viewState.basket.filter((r) => r !== row);
    } else if (key === 'basketadd')
      viewState.basket.push({
        product: v,
        qty: 1,
      });
    refreshWorkspace();
    return;
  }
  if (key === 'tillsave') {
    if (!viewState.basket.length) throw Error('recipe');
    let id;
    try {
      id = await executeCommand(v, {
        ...(viewState.billId
          ? {
              id: viewState.billId,
            }
          : {}),
        lines: viewState.basket,
      });
    } catch (e) {
      if (e.message === 'short_stock') {
        routeTo('shortage');
        return;
      }
      throw e;
    }
    viewState.billId = null;
    viewState.basket = [];
    routeTo('receipt', id);
    notifyUser(v);
    return;
  }
}
export { cashierAction };
