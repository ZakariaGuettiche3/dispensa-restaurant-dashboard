import { formatCurrency, formatDate, formatQuantity, unitPrice } from '../../utils/format.js';
import { unitFor } from '../../templates/catalogControls.js';
import { detail, grid, head, note, panel, status, tabs, total, val } from '../../templates/layout.js';
import { viewState } from '../../state/viewState.js';
import { tableMarkup } from '../../templates/table.js';
import { actorName, records, record } from '../../state/selectors.js';
import { label, localized, translateText } from '../../i18n/translate.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { navigationButton } from '../../templates/actions.js';
import { area, fields, form, pick, selectEnums } from '../../templates/forms.js';
function requestImpact(r) {
  if (r.kind === 'count') return formatQuantity(r.impact, unitFor(r.ref));
  if (r.kind === 'price') return unitPrice(r.impact);
  return formatCurrency(r.impact);
}
const renderApprovals = () =>
  head(
    'approvals',
    'Purchase requests, stock discrepancies and cashier corrections|Richieste di acquisto, differenze inventariali e rettifiche di cassa',
  ) +
  tabs(
    [
      ['Pending|Da approvare', 'queue:pending'],
      ['All requests|Tutte le richieste', 'queue:all'],
    ],
    'queue:' + (viewState.queue || 'pending'),
  ) +
  panel(
    'Request register|Registro richieste',
    tableMarkup(
      [
        'Request|Richiesta',
        'Submitted by|Richiedente',
        'Document|Documento',
        'Date|Data',
        'Impact|Impatto',
        'Status|Stato',
      ],
      records('requests')
        .filter((r) => viewState.queue === 'all' || r.status === 'pending')
        .slice()
        .reverse()
        .map((r) => [
          [
            detail(translateText(label(r.kind)), r.id),
            escapeHtml(actorName(r.actor)),
            escapeHtml(r.ref),
            formatDate(r.date),
            requestImpact(r),
            status(r.status),
          ],
          'open:review:' + r.id,
        ]),
      {
        paginate: true,
      },
    ),
  );
const renderReview = () => {
  const r = record('requests', viewState.id);
  if (!r) return head('review') + navigationButton('Approvals|Approvazioni', 'approvals');
  const s = ['discount', 'cancel', 'refund'].includes(r.kind);
  return (
    head('review', r.id, navigationButton('Approval queue|Coda approvazioni', 'approvals'), label(r.kind)) +
    grid(
      'g2',
      panel(
        'Request details|Dettagli richiesta',
        val('Document|Documento', escapeHtml(r.ref)) +
          val('Submitted by|Richiedente', escapeHtml(actorName(r.actor))) +
          val('Reason|Motivo', escapeHtml(localized(r.reason))) +
          val('Status|Stato', status(r.status)) +
          total('Impact|Impatto', requestImpact(r)),
      ),
      panel(
        'Owner decision|Decisione del titolare',
        r.status === 'pending'
          ? form(
              'decision',
              fields(
                pick('Decision|Decisione', 'approve', [
                  ['1', 'Approve|Approva'],
                  ['0', 'Reject|Respingi'],
                ]),
                s
                  ? selectEnums(
                      'Ingredient disposition|Destinazione ingredienti',
                      'outcome',
                      ['consumed', 'returned', 'wasted'],
                      'consumed',
                    )
                  : '',
                area('Decision note|Nota decisione', 'note'),
              ) +
                (s
                  ? note(
                      'The cashier applies the approved correction to the bill.|Il cassiere applica la rettifica approvata al conto.',
                    )
                  : ' '),
              'Record decision|Registra decisione',
            )
          : val('Reviewed by|Esaminata da', escapeHtml(actorName(r.approvedBy) || '—')) +
              val('Decision note|Nota decisione', escapeHtml(r.decision || '—')),
      ),
    )
  );
};
export { renderApprovals, renderReview };
