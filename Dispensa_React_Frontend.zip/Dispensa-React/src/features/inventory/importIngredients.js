import { grid, head, note, panel, side, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { field, fields, form } from '../../templates/forms.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { Dispensa } from '../../domain/index.js';
import { viewState } from '../../state/viewState.js';
import { tableMarkup } from '../../templates/table.js';
import { formatQuantity } from '../../utils/format.js';
import { translateHtml } from '../../i18n/translate.js';
const importColumns = ['code', 'name', 'unit', 'min', 'tolerance'];
const renderImporter = () =>
  head('importer', '', navigationButton('Ingredients|Ingredienti', 'ingredients')) +
  grid(
    'g2',
    panel(
      'Import CSV or XLSX|Importa CSV o XLSX',
      actionButton('Download CSV template|Scarica modello CSV', 'template', '', 'Download') +
        form(
          'importItems',
          fields(
            field(
              'Ingredient file|File ingredienti',
              'importFile',
              '',
              'file',
              'accept=".csv,.xlsx" data-import',
            ),
          ) + `<div id="importReview">${importPreview()}</div>`,
          'Import ingredients|Importa ingredienti',
        ),
    ),
    side(
      'File format|Formato file',
      'Ingredient catalog|Catalogo ingredienti',
      val('Columns|Colonne', escapeHtml(importColumns.join(', '))) +
        val('Units|Unità', escapeHtml(Dispensa.units.join(', '))) +
        note(
          'Use a unique code for each ingredient. Quantities use the base unit and up to three decimal places.|Usa un codice univoco per ogni ingrediente. Le quantità sono espresse nell’unità di base con un massimo di tre decimali.',
        ),
    ),
  );
function importPreview() {
  const rows = viewState.importRows || [];
  return rows.length
    ? tableMarkup(
        ['Code|Codice', 'Ingredient|Ingrediente', 'Minimum|Minimo'],
        rows
          .slice(0, 8)
          .map((r) => [[escapeHtml(r.code), escapeHtml(r.name), formatQuantity(r.min, r.unit)]]),
      ) + `<p class="hintline">${rows.length} ${translateHtml('rows ready|righe pronte')}</p>`
    : note('Choose a file to preview its rows.|Scegli un file per visualizzare le righe.');
}
export { importColumns, importPreview, renderImporter };
