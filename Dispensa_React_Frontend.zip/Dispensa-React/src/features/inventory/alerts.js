import { activeItems, stockTabs } from '../../templates/catalogControls.js';
import { detail, head, note, panel } from '../../templates/layout.js';
import { tableMarkup } from '../../templates/table.js';
import { formatQuantity } from '../../utils/format.js';
const renderAlerts = () => {
  const x = activeItems()
    .filter((i) => i.qty < i.min)
    .sort((a, b) => b.min - b.qty - (a.min - a.qty));
  return (
    head('alerts', 'Ingredients below the configured minimum|Ingredienti sotto la scorta minima') +
    stockTabs('alerts') +
    panel(
      'Reorder list|Lista di riordino',
      x.length
        ? tableMarkup(
            ['Ingredient|Ingrediente', 'On hand|Giacenza', 'Minimum|Minimo', 'Shortfall|Fabbisogno'],
            x.map((z) => [
              [
                detail(z.name, z.code),
                formatQuantity(z.qty, z.unit),
                formatQuantity(z.min, z.unit),
                formatQuantity(z.min - z.qty, z.unit),
              ],
              'open:ledger:' + z.id,
            ]),
          )
        : note(
            'All ingredients meet their minimum stock levels.|Tutti gli ingredienti raggiungono la scorta minima.',
          ),
    )
  );
};
export { renderAlerts };
