import { activeItems, choicesOf, listSearch, matches, stockTabs } from '../../templates/catalogControls.js';
import { detail, grid, head, metric, note, panel, side, status, val } from '../../templates/layout.js';
import { navigationButton } from '../../templates/actions.js';
import { formatCurrency, formatDate, formatQuantity, unitPrice } from '../../utils/format.js';
import { Dispensa } from '../../domain/index.js';
import { tableMarkup } from '../../templates/table.js';
import { records, record } from '../../state/selectors.js';
import { viewState } from '../../state/viewState.js';
import { translateHtml, label, translateText } from '../../i18n/translate.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { area, field, fields, form, numberField, pick } from '../../templates/forms.js';
import { session } from '../../state/session.js';
import { titles } from '../../i18n/messages.js';
const renderStock = () => {
  const list = activeItems().filter((x) => matches([x.code, x.name]));
  return (
    head(
      'stock',
      'Calculated stock and last physical observations|Giacenze calcolate e ultimi conteggi fisici',
      navigationButton('Record waste|Registra scarto', 'waste') +
        navigationButton('Count stock|Conta scorte', 'count', 'primary', 'ClipboardList'),
    ) +
    stockTabs('stock') +
    grid(
      'g3 metrics',
      metric(
        'Ingredients|Ingredienti',
        String(activeItems().length),
        'Active catalog|Catalogo attivo',
        'Wheat',
        true,
      ),
      metric(
        'Below minimum|Sotto il minimo',
        String(activeItems().filter((x) => x.qty < x.min).length),
        'Reorder alerts|Avvisi di riordino',
        'Bell',
      ),
      metric(
        'Stock value|Valore magazzino',
        formatCurrency(activeItems().reduce((n, x) => n + Dispensa.valueCents(x.qty, x.avg), 0)),
        'Weighted average cost|Costo medio ponderato',
        'Boxes',
      ),
    ) +
    panel(
      'Stock balances|Giacenze',
      listSearch() +
        tableMarkup(
          [
            'Ingredient|Ingrediente',
            'On hand|Giacenza',
            'Last count|Ultimo conteggio',
            'Minimum|Minimo',
            'Status|Stato',
          ],
          list.map((x) => [
            [
              detail(x.name, x.code),
              formatQuantity(x.qty, x.unit),
              x.lastCount != null
                ? formatQuantity(x.lastCount, x.unit) + ' · ' + formatDate(x.countDate, true)
                : '—',
              formatQuantity(x.min, x.unit),
              status(x.qty < x.min ? 'low' : 'healthy'),
            ],
            'open:ledger:' + x.id,
          ]),
          {
            paginate: true,
          },
        ),
    )
  );
};
const renderLedger = () => {
  const x = record('ingredients', viewState.id) || activeItems()[0];
  if (!x) return head('ledger') + note('Add an ingredient to start.|Aggiungi un ingrediente per iniziare.');
  const rows = records('moves')
    .filter((m) => m.ing === x.id)
    .slice()
    .reverse();
  return (
    head('ledger', x.code, navigationButton('Stock control|Controllo scorte', 'stock'), x.name) +
    grid(
      'g3 metrics',
      metric('On hand|Giacenza', formatQuantity(x.qty, x.unit), x.code, 'Boxes', true),
      metric(
        'Average unit cost|Costo unitario medio',
        unitPrice(x.avg),
        'Latest posted purchases|Ultimi acquisti registrati',
        'Wallet',
      ),
      metric(
        'Inventory value|Valore inventario',
        formatCurrency(Dispensa.valueCents(x.qty, x.avg)),
        translateText(label(x.unit)),
        'Scale',
      ),
    ) +
    panel(
      'All movements|Tutti i movimenti',
      tableMarkup(
        [
          'Date|Data',
          'Movement|Movimento',
          'Quantity|Quantità',
          'Value change|Variazione di valore',
          'Reference|Riferimento',
        ],
        rows.map((m) => [
          [
            formatDate(m.date),
            translateHtml(label(m.kind)),
            formatQuantity(m.qty, x.unit),
            formatCurrency(m.cost),
            escapeHtml(m.ref),
          ],
        ]),
        {
          paginate: true,
        },
      ),
    )
  );
};
function stockForm(k) {
  const items = activeItems(),
    x = record('ingredients', viewState.id) || items[0];
  if (!x) return head(k) + note('Add an ingredient first.|Aggiungi prima un ingrediente.');
  const sel = pick('Ingredient|Ingrediente', 'ing', choicesOf(items), x.id, 'data-stock');
  let body, action;
  if (k === 'count') {
    body = fields(
      sel,
      field('Expected quantity|Quantità prevista', 'expected', x.qty / 1000, 'number', 'readonly'),
      numberField('Actual quantity|Quantità contata', 'actual', x.qty / 1000),
      area('Reason for differences|Motivo delle differenze', 'note'),
    );
    action = 'Submit count|Invia conteggio';
  } else if (k === 'waste') {
    body = fields(
      sel,
      numberField('Waste quantity|Quantità scartata', 'qty', 0.1),
      area('Reason|Motivo', 'note'),
    );
    action = 'Post waste|Registra scarto';
  } else {
    body = fields(
      sel,
      field('Effective date|Data effettiva', 'date', session.today, 'date', 'required'),
      numberField('Opening quantity|Quantità iniziale', 'qty', 1),
      numberField('Unit cost (€)|Costo unitario (€)', 'price', 1, '.000001'),
      area('Source or evidence|Fonte o prova', 'note'),
    );
    action = 'Post opening balance|Registra saldo iniziale';
  }
  return (
    head(k) +
    stockTabs(k) +
    grid(
      'g2',
      panel(titles[k], form(k, body, action)),
      side(
        x.name,
        'Item controls|Controlli articolo',
        val('On hand|Giacenza', formatQuantity(x.qty, x.unit)) +
          val('Count tolerance|Tolleranza conteggio', '±' + formatQuantity(x.tolerance, x.unit)) +
          val('Average purchase cost|Costo medio di acquisto', unitPrice(x.avg)) +
          (k === 'count'
            ? note(
                'Differences above the tolerance go to the owner for approval.|Le differenze oltre la tolleranza richiedono l’approvazione del titolare.',
              )
            : '') +
          `<p id="stockHint" class="hintline"></p>`,
      ),
    )
  );
}
const renderCount = () => stockForm('count');
const renderWaste = () => stockForm('waste');
const renderOpening = () => stockForm('opening');
export { renderCount, renderLedger, renderOpening, renderStock, renderWaste };
