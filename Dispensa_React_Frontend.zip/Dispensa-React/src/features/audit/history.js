import { grid, head, panel, val } from '../../templates/layout.js';
import { listSearch, matches } from '../../templates/catalogControls.js';
import { tableMarkup } from '../../templates/table.js';
import { actorName, records, can, record } from '../../state/selectors.js';
import { translateHtml, label, roleText, translateText } from '../../i18n/translate.js';
import { formatCurrency, formatDate, formatNumber, unitPrice } from '../../utils/format.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { labels } from '../../i18n/messages.js';
import { viewState } from '../../state/viewState.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
const renderAudit = () =>
  head(
    'audit',
    'Recorded changes by staff member and document|Modifiche registrate per dipendente e documento',
  ) +
  panel(
    'Activity register|Registro attività',
    listSearch() +
      tableMarkup(
        ['Date|Data', 'Staff|Personale', 'Activity|Attività', 'Reference|Riferimento'],
        records('events')
          .slice()
          .sort((a, b) => b.at.localeCompare(a.at) || b.id.localeCompare(a.id))
          .filter((e) => matches([e.ref, actorName(e.actor), translateText(label(e.kind))]))
          .map((e) => [
            [
              formatDate(e.at) + ' ' + escapeHtml(e.at.slice(11, 16)),
              escapeHtml(actorName(e.actor)),
              translateHtml(label(e.kind)),
              escapeHtml(e.ref),
            ],
            'open:event:' + e.id,
          ]),
        {
          paginate: true,
        },
      ),
  );
const auditNames = {
  code: 'Code|Codice',
  name: 'Name|Nome',
  unit: 'Unit|Unità',
  min: 'Minimum (base units)|Minimo (unità base)',
  role: 'Role|Ruolo',
  status: 'Status|Stato',
  price: 'Selling or unit price|Prezzo di vendita o unitario',
  amount: 'Amount|Importo',
  version: 'Revision|Revisione',
  active: 'Active|Attivo',
  archived: 'Deleted|Eliminato',
  category: 'Category|Categoria',
  qty: 'Quantity|Quantità',
  paid: 'Paid|Pagato',
  total: 'Total|Totale',
  kind: 'Type|Tipo',
  city: 'City|Città',
  defaultLang: 'Default language|Lingua predefinita',
};
function auditData(v, e) {
  if (!v) return '<p class="caption">—</p>';
  let data;
  try {
    data = JSON.parse(v);
  } catch {
    return escapeHtml(v);
  }
  return Object.entries(data)
    .map(([k, t]) => {
      let value = t;
      if (['amount', 'paid', 'total', 'price'].includes(k))
        value = k === 'price' && e.kind === 'orderSave' ? unitPrice(t) : formatCurrency(t);
      else if (['qty', 'min'].includes(k)) value = formatNumber(t / 1000);
      else if (k === 'role') value = translateText(roleText(t));
      else if (['active', 'archived'].includes(k)) value = translateText(t ? 'Yes|Sì' : 'No|No');
      else if (k === 'defaultLang') value = t === 'it' ? 'Italiano' : 'English';
      else if (typeof t === 'string' && labels[t]) value = translateText(label(t));
      return val(auditNames[k] || k, escapeHtml(value));
    })
    .join('');
}
const renderEvent = () => {
  const e = record('events', viewState.id);
  if (!e) return head('event') + navigationButton('Audit history|Cronologia attività', 'audit');
  const user =
    can('staff') && e.kind === 'staffRecovery'
      ? actionButton('Open staff profile|Apri scheda dipendente', 'open:person:' + e.ref, 'primary', 'Users')
      : '';
  return (
    head(
      'event',
      e.id,
      navigationButton('Audit history|Cronologia attività', 'audit') + user,
      label(e.kind),
    ) +
    panel(
      'Event details|Dettagli evento',
      val('Recorded|Registrato', formatDate(e.at) + ' ' + escapeHtml(e.at.slice(11, 16))) +
        val('Actor|Autore', escapeHtml(actorName(e.actor))) +
        val('Document|Documento', escapeHtml(e.ref)),
    ) +
    grid('equal', panel('Before|Prima', auditData(e.before, e)), panel('After|Dopo', auditData(e.after, e)))
  );
};
export { renderAudit, renderEvent };
