import { session } from '../../state/session.js';
import { currentStyle } from '../../services/visualPreferences.js';
import { extraPalettes } from './palettes.js';
import { colorTokens, hexOK } from '../../utils/colorContrast.js';
function applyColors() {
  if (!session.model) return;
  const a = session.model.actor;
  document.documentElement.dataset.theme = a.theme || 'olive';
  document.documentElement.dataset.mode =
    a.mode === 'system'
      ? typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light'
      : a.mode || 'light';
  document.documentElement.lang = session.language;
  applyVisualStyle();
}
const brandTokens = [
  '--green',
  '--fern',
  '--dark',
  '--sideActive',
  '--pale',
  '--chip',
  '--plot',
  '--plot2',
  '--apricot',
  '--onAccent',
];
function applyVisualStyle() {
  const el = document.documentElement,
    style = currentStyle();
  if (!el.style) return;
  brandTokens.forEach((k) => el.style.removeProperty(k));
  const colors = extraPalettes[style.choice] || (style.choice === 'customTheme' ? style.colors : null);
  if (colors?.length === 3 && colors.every(hexOK)) {
    for (const [k, v] of Object.entries(colorTokens(colors, el.dataset.mode === 'dark')))
      el.style.setProperty(k, v);
    el.dataset.theme = style.choice;
  }
}
export { applyColors };
