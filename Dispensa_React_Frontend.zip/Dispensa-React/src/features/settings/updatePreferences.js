import { session } from '../../state/session.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
import { captureInputs, restoreInputs } from '../../forms/fieldValues.js';
import { executeCommand } from '../../services/restaurantSession.js';
async function preference(change) {
  if (!session.model) {
    session.language = change.lang || session.language;
    refreshWorkspace();
    return;
  }
  if (session.model.preview) {
    if (change.lang) {
      session.language = change.lang;
      refreshWorkspace();
      return;
    }
    throw Error('preview');
  }
  const saved = captureInputs();
  await executeCommand('preferences', {
    lang: session.language,
    theme: session.model.actor.theme,
    mode: session.model.actor.mode,
    ...change,
  });
  refreshWorkspace();
  restoreInputs(saved);
}
export { preference };
