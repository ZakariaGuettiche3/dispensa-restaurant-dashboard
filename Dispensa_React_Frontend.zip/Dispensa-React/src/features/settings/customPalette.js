import { currentStyle } from '../../services/visualPreferences.js';
import { note, panel } from '../../templates/layout.js';
import { field, fields, form } from '../../templates/forms.js';
import { translateHtml } from '../../i18n/translate.js';
function customEditor() {
  const c = currentStyle(),
    colors = c.colors || ['#356a55', '#dc9a5b', '#213b31'];
  return panel(
    'Create your palette|Crea la tua tavolozza',
    form(
      'customColors',
      fields(
        ...[
          'Primary buttons|Pulsanti principali',
          'Chart accent|Accento grafici',
          'Sidebar|Barra laterale',
        ].map((n, i) => field(n, 'color' + i, colors[i], 'color', 'data-color')),
      ) +
        '<div id="colorSample" class="color-sample">' +
        translateHtml('Palette preview|Anteprima tavolozza') +
        '</div>' +
        note(
          'Text contrast adjusts automatically. These colors are saved in this browser.|Il contrasto del testo si adatta automaticamente. I colori vengono salvati in questo browser.',
        ),
      'Save custom colors|Salva colori personali',
    ),
  );
}
export { customEditor };
