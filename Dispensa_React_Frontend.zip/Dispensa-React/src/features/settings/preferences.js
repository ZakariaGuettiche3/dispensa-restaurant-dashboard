import { session } from '../../state/session.js';
import { currentStyle } from '../../services/visualPreferences.js';
import { grid, head, note, panel, side, tabs, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { translateHtml, label, roleText } from '../../i18n/translate.js';
import { Dispensa } from '../../domain/index.js';
import { extraPalettes } from './palettes.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { can } from '../../state/selectors.js';
import { customEditor } from './customPalette.js';
import { field, fields, form, pick } from '../../templates/forms.js';
const langs = [
  ['en', 'English|Inglese'],
  ['it', 'Italian|Italiano'],
];
const palettes = {
  olive: ['#203b2e', '#547b5c', '#efb979'],
  coast: ['#173b46', '#3e7c87', '#d29a63'],
  wine: ['#45283d', '#8b5d7c', '#bf9653'],
};
const renderSettings = () => {
  const a = {
    ...session.model.actor,
    theme: currentStyle().choice || session.model.actor.theme,
  };
  return (
    head(
      'settings',
      'Your workspace preferences|Preferenze personali dello spazio di lavoro',
      session.model.preview
        ? ''
        : actionButton('Switch demo account|Cambia account demo', 'logout', '', 'LogOut'),
    ) +
    grid(
      'g2',
      panel(
        'Appearance|Aspetto',
        `<h3>${translateHtml('Color theme|Tema colore')}</h3><div class="theme-list">${[...Dispensa.themes, ...Object.keys(extraPalettes)].map((k) => `<button class="themechoose ${k === a.theme ? 'on' : ''}" data-ui="theme:${k}" aria-pressed="${k === a.theme}"><span class="swatches">${(palettes[k] || extraPalettes[k]).map((c) => `<i style="background:${c}"></i>`).join('')}</span>${translateHtml(label(k))}</button>`).join('')}</div><div class="rule"></div><h3>${translateHtml('Display mode|Modalità di visualizzazione')}</h3>` +
          tabs(
            Dispensa.modes.map((k) => [label(k), 'mode:' + k]),
            'mode:' + a.mode,
          ),
      ),
      side(
        'Language|Lingua',
        'Personal settings|Impostazioni personali',
        note(
          'Navigation, reports, dates and currency follow your selected language.|Navigazione, report, date e valuta seguono la lingua selezionata.',
        ) +
          tabs(
            langs.map(([k, n]) => [n, 'lang:' + k]),
            'lang:' + session.language,
          ) +
          val('Signed in as|Accesso come', escapeHtml(a.name)) +
          val('Role|Ruolo', translateHtml(roleText(a.role))) +
          (can('organization')
            ? navigationButton('Restaurant settings|Impostazioni ristorante', 'organization', 'wide', 'Store')
            : ''),
      ),
    ) +
    customEditor()
  );
};
const renderOrganization = () =>
  head('organization', '', navigationButton('Preferences|Preferenze', 'settings')) +
  panel(
    'Restaurant identity|Dati ristorante',
    form(
      'organization',
      fields(
        field('Restaurant name|Nome ristorante', 'name', session.model.config.name, 'text', 'required'),
        field('City|Città', 'city', session.model.config.city),
        pick(
          'Default language for new accounts|Lingua predefinita per nuovi account',
          'defaultLang',
          langs,
          session.model.config.defaultLang,
        ),
      ),
      'Save settings|Salva impostazioni',
    ),
  );
export { renderOrganization, renderSettings };
