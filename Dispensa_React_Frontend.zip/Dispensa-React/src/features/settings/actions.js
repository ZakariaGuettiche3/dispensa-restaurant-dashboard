import { preference } from './updatePreferences.js';
import { session } from '../../state/session.js';
import { extraPalettes } from './palettes.js';
import { chooseStyle } from '../../services/visualPreferences.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
async function appearanceAction(key, v, z) {
  if (key === 'language')
    return preference({
      lang: session.language === 'en' ? 'it' : 'en',
    });
  if (key === 'theme') {
    if (session.model.preview) throw Error('preview');
    if (extraPalettes[v]) {
      chooseStyle(v);
      refreshWorkspace();
      return;
    }
    await preference({
      theme: v,
    });
    chooseStyle(v);
    refreshWorkspace();
    return;
  }
  if (key === 'lang' || key === 'mode')
    return preference({
      [key]: v,
    });
}
export { appearanceAction };
