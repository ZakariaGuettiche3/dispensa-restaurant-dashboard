const extraPalettes = {
  terracotta: ['#945039', '#edb674', '#422f2a'],
  lagoon: ['#266a69', '#efaf76', '#183f43'],
  indigo: ['#554695', '#e9af6f', '#302c52'],
  citrus: ['#526729', '#f3c54e', '#303b23'],
  rose: ['#935067', '#f0bf91', '#402d39'],
};
export { extraPalettes };
