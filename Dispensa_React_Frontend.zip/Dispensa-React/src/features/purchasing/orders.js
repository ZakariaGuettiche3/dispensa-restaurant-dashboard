import { records, ingName, record, supName } from '../../state/selectors.js';
import { viewState } from '../../state/viewState.js';
import { grid, head, note, panel, side, status, total, val } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { formatCurrency, formatQuantity, unitPrice } from '../../utils/format.js';
import { activeItems, buyTabs, choicesOf, eligible, unitFor } from '../../templates/catalogControls.js';
import { Dispensa } from '../../domain/index.js';
import { area, field, fields, form, numberField, pick } from '../../templates/forms.js';
import { session } from '../../state/session.js';
import { localized } from '../../i18n/translate.js';
const renderOrder = () => {
  const o = record('orders', viewState.id);
  if (o && o.status !== 'draft') {
    return (
      head('order', supName(o.supplier), navigationButton('Orders|Ordini', 'purchases'), o.id) +
      grid(
        'g2',
        panel(
          'Ordered item|Articolo ordinato',
          val('Ingredient|Ingrediente', escapeHtml(ingName(o.ing))) +
            val('Ordered|Ordinato', formatQuantity(o.qty, unitFor(o.ing))) +
            val('Approved unit price|Prezzo unitario approvato', unitPrice(o.price)) +
            total('Order amount|Importo ordine', formatCurrency(Dispensa.valueCents(o.qty, o.price))),
        ),
        side(
          'Delivery status|Stato consegna',
          'Purchase order|Ordine di acquisto',
          val('Status|Stato', status(o.status)) +
            val('Received|Ricevuto', formatQuantity(o.received, unitFor(o.ing))) +
            val('Outstanding|Residuo', formatQuantity(o.qty - o.received, unitFor(o.ing))) +
            (['approved', 'partial'].includes(o.status)
              ? actionButton(
                  'Receive goods|Ricevi merce',
                  'open:receive:' + o.id,
                  'primary wide',
                  'PackageCheck',
                )
              : ''),
        ),
      )
    );
  }
  const supplierId = o?.supplier || eligible('suppliers')[0]?.id;
  const ingredientId = o?.ing || activeItems()[0]?.id;
  const quote = records('quotes').find((q) => q.supplier === supplierId && q.ing === ingredientId);
  const price = o?.price ?? quote?.price;
  return (
    head(
      'order',
      '',
      navigationButton('Orders|Ordini', 'purchases'),
      o?.id || 'New purchase order|Nuovo ordine di acquisto',
    ) +
    panel(
      'Order details|Dati ordine',
      form(
        'orderSave',
        fields(
          pick('Supplier|Fornitore', 'supplier', choicesOf(eligible('suppliers')), o?.supplier, 'data-quote'),
          pick('Ingredient|Ingrediente', 'ing', choicesOf(activeItems()), o?.ing, 'data-quote'),
          numberField('Order quantity|Quantità ordinata', 'qty', o ? o.qty / 1000 : 10),
          numberField(
            'Unit price (€)|Prezzo unitario (€)',
            'price',
            price == null ? '' : price / 1e6,
            '.000001',
            '.000001',
          ),
          field('Expected date|Data prevista', 'expected', o?.expected || session.today, 'date', 'required'),
          pick(
            'Save as|Salva come',
            'submit',
            [
              ['1', 'Submit for approval|Invia per approvazione'],
              ['0', 'Draft|Bozza'],
            ],
            '1',
          ),
          area('Order note|Nota ordine', 'note', localized(o?.note)),
        ),
        'Save order|Salva ordine',
      ),
    )
  );
};
const renderReceive = () => {
  const allow = records('orders').filter((o) => ['approved', 'partial'].includes(o.status)),
    o = allow.find((x) => x.id === viewState.id) || allow[0];
  if (!o)
    return (
      head('receive') +
      buyTabs('receive') +
      note('No approved order has an open quantity.|Nessun ordine approvato presenta quantità residue.')
    );
  const x = record('ingredients', o.ing);
  return (
    head('receive', supName(o.supplier)) +
    buyTabs('receive') +
    grid(
      'g2',
      panel(
        'Delivery details|Dati consegna',
        form(
          'receive',
          fields(
            pick(
              'Approved order|Ordine approvato',
              'order',
              allow.map((z) => [z.id, z.id + ' · ' + supName(z.supplier)]),
              o.id,
              'data-order',
            ),
            field('Delivery reference|Riferimento consegna', 'ref', '', 'text', 'required'),
            numberField(
              'Quantity received|Quantità ricevuta',
              'qty',
              Math.min(5, (o.qty - o.received) / 1000),
            ),
            numberField(
              'Invoice price / unit (€)|Prezzo fattura per unità (€)',
              'price',
              o.price / 1e6,
              '.000001',
              '.000001',
            ),
            area('Price difference note|Nota differenza prezzo', 'reason'),
          ),
          'Record delivery|Registra consegna',
        ),
      ),
      side(
        x.name,
        'Cost impact|Impatto sui costi',
        val('Current stock|Giacenza attuale', formatQuantity(x.qty, x.unit)) +
          val('Current average|Media attuale', unitPrice(x.avg)) +
          val('Remaining on order|Residuo ordine', formatQuantity(o.qty - o.received, x.unit)) +
          `<div id="receivePreview">${total('Average after receipt|Media dopo la ricezione', unitPrice(Dispensa.divRound(BigInt(x.qty) * BigInt(x.avg) + BigInt(Math.min(5000, o.qty - o.received)) * BigInt(o.price), x.qty + Math.min(5000, o.qty - o.received))))}</div>` +
          note(
            'A different invoice price is submitted to the owner for review.|Un prezzo in fattura diverso viene sottoposto al titolare per verifica.',
          ),
      ),
    )
  );
};
export { renderOrder, renderReceive };
