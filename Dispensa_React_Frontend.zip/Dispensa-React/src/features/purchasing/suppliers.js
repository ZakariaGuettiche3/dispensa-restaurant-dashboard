import { grid, head, note, panel, status } from '../../templates/layout.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { activeItems, buyTabs, choicesOf, eligible, unitFor } from '../../templates/catalogControls.js';
import { tableMarkup } from '../../templates/table.js';
import { records, ingName, record, supName } from '../../state/selectors.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { formatDate, formatQuantity, unitPrice } from '../../utils/format.js';
import { viewState } from '../../state/viewState.js';
import { field, fields, form, numberField, pick } from '../../templates/forms.js';
const renderPurchases = () =>
  head(
    'purchases',
    'Supplier orders and incoming deliveries|Ordini ai fornitori e consegne in arrivo',
    actionButton('New purchase order|Nuovo ordine di acquisto', 'new:order', 'primary', 'Plus'),
  ) +
  buyTabs('purchases') +
  panel(
    'Purchase orders|Ordini di acquisto',
    tableMarkup(
      [
        'Order|Ordine',
        'Supplier|Fornitore',
        'Ingredient|Ingrediente',
        'Ordered|Ordinato',
        'Remaining|Residuo',
        'Status|Stato',
      ],
      records('orders')
        .slice()
        .reverse()
        .map((o) => [
          [
            escapeHtml(o.id),
            escapeHtml(supName(o.supplier)),
            escapeHtml(ingName(o.ing)),
            formatQuantity(o.qty, unitFor(o.ing)),
            formatQuantity(o.qty - o.received, unitFor(o.ing)),
            status(o.status),
          ],
          'open:order:' + o.id,
        ]),
      {
        paginate: true,
      },
    ),
  );
const renderSuppliers = () =>
  head('suppliers', '', actionButton('Add supplier|Aggiungi fornitore', 'new:supplier', 'primary', 'Plus')) +
  buyTabs('suppliers') +
  panel(
    'Directory|Elenco',
    tableMarkup(
      ['Supplier|Fornitore', 'Contact|Contatto', 'Email|Email', 'Telephone|Telefono'],
      eligible('suppliers').map((s) => [
        [escapeHtml(s.name), escapeHtml(s.contact), escapeHtml(s.email), escapeHtml(s.phone || '—')],
        'open:supplier:' + s.id,
      ]),
    ),
  );
const renderSupplier = () => {
  const s = record('suppliers', viewState.id) || {};
  return (
    head('supplier', s.name || '', navigationButton('Suppliers|Fornitori', 'suppliers')) +
    grid(
      'g2',
      panel(
        'Contact details|Dati di contatto',
        form(
          'supplierSave',
          fields(
            field('Supplier name|Nome fornitore', 'name', s.name, 'text', 'required'),
            field('Contact person|Referente', 'contact', s.contact),
            field('Email|Email', 'email', s.email, 'email'),
            field('Telephone|Telefono', 'phone', s.phone),
          ),
          'Save supplier|Salva fornitore',
        ),
      ),
      panel(
        'Prices supplied|Prezzi offerti',
        tableMarkup(
          ['Ingredient|Ingrediente', 'Unit price|Prezzo unitario'],
          records('quotes')
            .filter((q) => q.supplier === s.id)
            .map((q) => [[escapeHtml(ingName(q.ing)), unitPrice(q.price)]]),
        ),
      ),
    )
  );
};
const renderQuotes = () =>
  head(
    'quotes',
    'Separate purchase prices for each supplier and ingredient|Prezzi distinti per fornitore e ingrediente',
  ) +
  buyTabs('quotes') +
  grid(
    'g2',
    panel(
      'Supplier price list|Listino fornitori',
      tableMarkup(
        ['Supplier|Fornitore', 'Ingredient|Ingrediente', 'Price / unit|Prezzo / unità', 'Updated|Aggiornato'],
        records('quotes').map((q) => [
          [
            escapeHtml(supName(q.supplier)),
            escapeHtml(ingName(q.ing)),
            unitPrice(q.price),
            formatDate(q.date),
          ],
        ]),
      ),
    ),
    panel(
      'Set supplier price|Imposta prezzo fornitore',
      form(
        'quoteSave',
        fields(
          pick('Supplier|Fornitore', 'supplier', choicesOf(eligible('suppliers'))),
          pick('Ingredient|Ingrediente', 'ing', choicesOf(activeItems())),
          numberField('Unit price (€)|Prezzo unitario (€)', 'price', 2.5, '.000001', '.000001'),
        ),
        'Save price|Salva prezzo',
      ) +
        note(
          'A quote updates the price list. Receiving goods updates inventory valuation.|Il preventivo aggiorna il listino. La ricezione aggiorna la valutazione del magazzino.',
        ),
    ),
  );
export { renderPurchases, renderQuotes, renderSupplier, renderSuppliers };
