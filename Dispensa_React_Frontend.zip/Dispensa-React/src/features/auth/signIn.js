import { actionButton, iconMarkup } from '../../templates/actions.js';
import { translateHtml, roleText, translateText } from '../../i18n/translate.js';
import { session } from '../../state/session.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { initials } from '../../utils/format.js';
import { detail } from '../../templates/layout.js';
import { field, fields } from '../../templates/forms.js';
function login() {
  return `<main class="auth"><section class="authvisual"><div class="wordmark">${iconMarkup('Sprout', 32)}<span>Dispensa</span></div><div><div class="eyebrow">${translateHtml('Restaurant workspace|Area ristorante')}</div><h2>${translateHtml('Staff sign-in|Accesso personale')}</h2></div><div class="caption">${translateHtml('Restaurant management|Gestione del ristorante')}</div></section><section class="authbody"><div class="eyebrow">${translateHtml('Staff access|Accesso dipendenti')}</div><h1>${translateHtml('Sign in|Accedi')}</h1>${`<p class="subtitle">${translateHtml('Choose a fictional staff account to explore its workspace.|Scegli un account dimostrativo per esplorare il relativo spazio.')}</p><div class="rolegrid" style="margin-top:20px">${session.restaurant.staff
    .filter((s) => s.status === 'active')
    .map(
      (s) =>
        `<button class="rolecard" data-ui="demo:${escapeHtml(s.id)}"><span class="avatar">${escapeHtml(initials(s.name))}</span><span>${detail(s.name, translateText(roleText(s.role)))}</span></button>`,
    )
    .join(
      '',
    )}</div>`}<div class="authmeta">${actionButton('Recover access|Recupera accesso', 'recovery')}${actionButton('English / Italiano', 'language')}</div></section></main>`;
}
function recoveryScreen() {
  return `<main class="auth"><section class="authvisual"><div class="wordmark">${iconMarkup('Sprout', 32)}<span>Dispensa</span></div><div><div class="eyebrow">${translateHtml('Restaurant workspace|Area ristorante')}</div><h2>${translateHtml('Account access|Accesso account')}</h2></div></section><section class="authbody"><div class="eyebrow">${translateHtml('Staff access|Accesso personale')}</div><h1>${translateHtml('Recover access|Recupera accesso')}</h1><p class="subtitle">${translateHtml('Enter your staff email to request a password reset from the restaurant owner.|Inserisci la tua email di lavoro per richiedere al titolare la reimpostazione della password.')}</p><form data-form="recover">${fields(field('Work email|Email di lavoro', 'email', '', 'email', 'required autocomplete="username"'))}<div class="formerror" role="alert"></div><button class="button primary wide" type="submit">${translateHtml('Request access|Richiedi accesso')}</button></form><div class="authmeta">${actionButton('Sign in|Accedi', 'signin')}${actionButton('English / Italiano', 'language')}</div></section></main>`;
}
export { login, recoveryScreen };
