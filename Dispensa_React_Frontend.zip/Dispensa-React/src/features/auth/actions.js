import { saveAccount, savePreview } from '../../services/browserStorage.js';
import { session } from '../../state/session.js';
import { refreshRoleProjection } from '../../services/restaurantSession.js';
import { goHome } from '../../navigation/router.js';
import { viewState } from '../../state/viewState.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
import { preview } from '../staff/preview.js';
async function accountAction(key, v, z) {
  if (key === 'demo') {
    session.accountId = v;
    session.previewId = null;
    saveAccount(v);
    refreshRoleProjection();
    goHome();
    return;
  }
  if (key === 'recovery' || key === 'signin') {
    viewState.recovery = key === 'recovery';
    refreshWorkspace();
    return;
  }
  if (key === 'exitpreview' || key === 'preview') return preview(key === 'preview' ? v : null);
  if (key === 'logout') {
    viewState.actualThemeOwner = null;
    viewState.previewOrigin = null;
    savePreview(null);
    session.accountId = null;
    session.previewId = null;
    saveAccount('signed-out');
    session.model = null;
    viewState.basket = [];
    viewState.billId = null;
    refreshWorkspace();
    return;
  }
}
export { accountAction };
