import * as Reports from '../../services/reports.js';
import { actorName, records, can, ingName, record, supName } from '../../state/selectors.js';
import { translateHtml, label, localized, translateText } from '../../i18n/translate.js';
import { formatCurrency, formatDate, formatNumber, formatQuantity, unitPrice } from '../../utils/format.js';
import { viewState } from '../../state/viewState.js';
import { payLabel } from '../sales/history.js';
import { session } from '../../state/session.js';
import { grid, head, panel, tabs } from '../../templates/layout.js';
import { tableMarkup } from '../../templates/table.js';
import { periodBar, rangeData } from './periodFilter.js';
import { actionButton } from '../../templates/actions.js';
import { ranking, resultRows } from '../overview/dashboard.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
const rTabs = [
  ['Performance|Risultati', 'performance'],
  ['Sales|Vendite', 'sales'],
  ['Expenses|Spese', 'expenses'],
  ['Inventory movements|Movimenti di magazzino', 'moves'],
  ['Purchases|Acquisti', 'receipts'],
  ['Payments|Pagamenti', 'payments'],
  ['Payment mix|Ripartizione incassi', 'mix'],
  ['Stock losses|Perdite magazzino', 'losses'],
];
function reportRows(key, range, r) {
  const inside = (d) => Reports.within(d, ...range),
    items = (name, dateKey) =>
      records(name)
        .filter((x) => inside(x[dateKey]))
        .slice()
        .reverse();
  if (key === 'mix')
    return {
      cols: ['Method|Metodo', 'Total collected|Totale incassato'],
      rows: [
        [translateText('Cash|Contanti'), formatCurrency(r.cash)],
        [translateText('Card|Carta'), formatCurrency(r.card)],
        [translateText('Refund payouts|Rimborsi eseguiti'), formatCurrency(r.refunds)],
      ],
    };
  if (key === 'losses') {
    const list = items('moves', 'date').filter((z) => ['count', 'waste'].includes(z.kind));
    return {
      cols: ['Date|Data', 'Source|Origine', 'Reference|Riferimento', 'Value change|Variazione di valore'],
      rows: [
        ...list.map((z) => [
          formatDate(z.date),
          translateText(label(z.kind)) + ' · ' + ingName(z.ing),
          z.ref,
          formatCurrency(z.cost),
        ]),
        ...items('adjust', 'date')
          .filter((z) => z.loss)
          .map((z) => [formatDate(z.date), translateText(label('wasted')), z.ref, formatCurrency(-z.loss)]),
      ],
    };
  }
  if (key === 'performance')
    return {
      cols: [
        'Product|Prodotto',
        'Units sold|Unità vendute',
        'Net revenue|Ricavi netti',
        'Ingredient cost|Costo ingredienti',
        'Gross margin|Margine lordo',
      ],
      rows: r.products.map((x) => [
        x.name,
        x.qty,
        formatCurrency(x.revenue),
        formatCurrency(x.cost),
        formatCurrency(x.revenue - x.cost),
      ]),
    };
  if (key === 'sales') {
    const l = items('sales', 'date').filter(
      (b) =>
        !viewState.focus ||
        records('saleLines').some((x) => x.sale === b.id && x.product === viewState.focus),
    );
    return {
      cols: [
        'Bill|Conto',
        'Date|Data',
        'Cashier|Cassiere',
        'Document|Documento',
        'Payment|Pagamento',
        'Total|Totale',
      ],
      rows: l.map((b) => [
        b.id,
        formatDate(b.date),
        actorName(b.actor),
        translateText(label(b.status)),
        payLabel(b),
        formatCurrency(b.total),
      ]),
      ids: l.map((b) => b.id),
    };
  }
  if (key === 'expenses') {
    const data = session.model.expenses
      ? items('expenses', 'date').filter((e) => !e.archived)
      : items('expenseTotals', 'date');
    return {
      cols: [
        'Reference|Riferimento',
        'Date|Data',
        'Category|Categoria',
        'Description|Descrizione',
        'Amount|Importo',
      ],
      rows: data.map((x) => [
        x.id,
        formatDate(x.date),
        translateText(label(x.category)),
        localized(x.text || ''),
        formatCurrency(x.amount),
      ]),
    };
  }
  if (key === 'moves') {
    const list = items('moves', 'date');
    return {
      cols: [
        'Date|Data',
        'Ingredient|Ingrediente',
        'Movement|Movimento',
        'Quantity|Quantità',
        'Value|Valore',
        'Reference|Riferimento',
      ],
      rows: list.map((x) => [
        formatDate(x.date),
        ingName(x.ing),
        translateText(label(x.kind)),
        formatQuantity(x.qty, record('ingredients', x.ing)?.unit || 'kg'),
        formatCurrency(x.cost),
        x.ref,
      ]),
    };
  }
  if (key === 'receipts')
    return {
      cols: [
        'Date|Data',
        'Supplier|Fornitore',
        'Ingredient|Ingrediente',
        'Quantity|Quantità',
        'Unit price|Prezzo unitario',
        'Document|Documento',
      ],
      rows: items('receipts', 'date').map((x) => [
        formatDate(x.date),
        supName(x.supplier),
        ingName(x.ing),
        formatQuantity(x.qty, record('ingredients', x.ing)?.unit || 'kg'),
        unitPrice(x.price),
        x.ref,
      ]),
    };
  return {
    cols: ['Date|Data', 'Bill|Conto', 'Cashier|Cassiere', 'Cash|Contanti', 'Card|Carta', 'Total|Totale'],
    rows: items('payments', 'date').map((x) => [
      formatDate(x.date),
      x.sale,
      actorName(x.actor),
      formatCurrency(x.cash),
      formatCurrency(x.card),
      formatCurrency(x.cash + x.card),
    ]),
  };
}
function compareTable(r, p, range, prev) {
  if (!p) return '';
  const rows = [
    ['Sales revenue|Ricavi delle vendite', 'revenue', formatCurrency],
    ['Paid orders|Ordini saldati', 'orders', formatNumber],
    ['Average order|Scontrino medio', 'aov', formatCurrency],
    ['Gross margin|Margine lordo', 'gross', formatCurrency],
    ['Operating result|Risultato operativo', 'profit', formatCurrency],
  ];
  return panel(
    'Period comparison|Confronto tra periodi',
    tableMarkup(
      [
        'Measure|Metrica',
        formatDate(range[0], true) + ' – ' + formatDate(range[1], true),
        formatDate(prev[0], true) + ' – ' + formatDate(prev[1], true),
        'Change|Differenza',
      ],
      rows.map(([key, k, f]) => [
        [translateHtml(key), f(r[k]), f(p[k]), r[k] != null && p[k] != null ? f(r[k] - p[k]) : '—'],
      ]),
    ),
  );
}
const renderReports = () => {
  const { range, prev, r, p } = rangeData();
  const key = viewState.report,
    rr = reportRows(key, range, r);
  return (
    head(
      'reports',
      formatDate(range[0]) + ' – ' + formatDate(range[1]),
      actionButton('Export CSV|Esporta CSV', 'export', 'primary', 'Download'),
      'Historical reports|Report storici',
    ) +
    periodBar() +
    tabs(
      rTabs
        .filter(([, k]) => k !== 'receipts' || !!session.model.receipts)
        .map(([s, k]) => [s, 'report:' + k]),
      'report:' + key,
    ) +
    (key === 'performance'
      ? grid(
          'equal',
          panel('Operating statement|Conto gestionale', resultRows(r)),
          compareTable(r, p, range, prev) || ranking(r),
        )
      : '') +
    panel(
      key === 'performance' ? 'Sales by product|Vendite per prodotto' : rTabs.find((v) => v[1] === key)[0],
      (viewState.focus && key === 'sales'
        ? actionButton('Clear product filter|Rimuovi filtro prodotto', 'unfocus')
        : '') +
        tableMarkup(
          rr.cols,
          rr.rows.map((a, i) => [
            a.map(escapeHtml),
            key === 'sales' && can('sales') ? 'open:saleRead:' + rr.ids[i] : '',
          ]),
          {
            paginate: true,
          },
        ),
      `<span class="caption">${rr.rows.length} ${translateHtml('records|record')}</span>`,
    )
  );
};
export { renderReports, reportRows };
