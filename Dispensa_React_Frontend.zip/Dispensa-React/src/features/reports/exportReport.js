import { rangeData } from './periodFilter.js';
import { reportRows } from './reportViews.js';
import { viewState } from '../../state/viewState.js';
import { translateText } from '../../i18n/translate.js';
import { formatCurrency, formatNumber } from '../../utils/format.js';
import { csvCell, download } from '../../services/download.js';
function exportReport() {
  const { range, r } = rangeData(),
    rr = reportRows(viewState.report, range, r);
  let rows = [rr.cols.map(translateText), ...rr.rows];
  if (viewState.report === 'performance' && viewState.compare !== 'none') {
    const { prev, p } = rangeData();
    rows.push([], [translateText('Measure|Metrica'), range.join(' / '), prev.join(' / ')]);
    for (const [n, k, fmt] of [
      ['Revenue|Ricavi', 'revenue', formatCurrency],
      ['Orders|Ordini', 'orders', formatNumber],
      ['Average order|Scontrino medio', 'aov', formatCurrency],
      ['Gross margin|Margine lordo', 'gross', formatCurrency],
      ['Operating result|Risultato operativo', 'profit', formatCurrency],
    ])
      rows.push([translateText(n), fmt(r[k]), fmt(p[k])]);
  }
  download(
    'Dispensa_' + viewState.report + '_' + range.join('_') + '.csv',
    '\uFEFF' + rows.map((row) => row.map(csvCell).join(';')).join('\r\n'),
    'text/csv;charset=utf-8',
  );
}
export { exportReport };
