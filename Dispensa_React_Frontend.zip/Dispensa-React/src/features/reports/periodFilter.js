import { translateHtml, label } from '../../i18n/translate.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { viewState } from '../../state/viewState.js';
import * as Reports from '../../services/reports.js';
import { session } from '../../state/session.js';
import { validDay } from '../../utils/dates.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
const presets = ['day', 'week', 'month', 'year', 'all', 'custom'];
function periodBar() {
  const dateInput = (k, v, s) =>
    `<label class="smallfield">${translateHtml(s)}<input type="date" data-period="${k}" value="${escapeHtml(v)}"></label>`;
  return `<div class="rangebar"><div class="choices">${presets.map((k) => `<button class="choice ${viewState.period === k ? 'on' : ''}" data-ui="period:${k}">${translateHtml(label(k))}</button>`).join('')}</div><div class="rangeextra">${viewState.period === 'custom' ? dateInput('from', viewState.from, 'From|Dal') + dateInput('to', viewState.to, 'To|Al') : viewState.period !== 'all' ? dateInput('anchor', viewState.anchor, 'Period containing|Periodo del') : ''}<label class="smallfield">${translateHtml('Compare|Confronta')}<select data-period="compare">${[
    ['previous', 'Previous period|Periodo precedente'],
    ['custom', 'Other dates|Altre date'],
    ['none', 'Off|Disattivato'],
  ]
    .map(
      ([v, s]) =>
        `<option value="${v}" ${viewState.compare === v ? 'selected' : ''}>${translateHtml(s)}</option>`,
    )
    .join(
      '',
    )}</select></label>${viewState.compare === 'custom' ? dateInput('cf', viewState.cf, 'From|Dal') + dateInput('ct', viewState.ct, 'To|Al') : ''}</div></div>`;
}
function rangeData() {
  const range = Reports.period(
      viewState.period,
      viewState.anchor,
      [viewState.from, viewState.to],
      session.model,
    ),
    prev =
      viewState.compare === 'custom'
        ? [viewState.cf, viewState.ct]
        : Reports.prior(viewState.period, ...range);
  return {
    range,
    prev,
    r: Reports.metrics(session.model, ...range),
    p: viewState.compare === 'none' ? null : Reports.metrics(session.model, ...prev),
  };
}
function fitRange(key, value) {
  if (key === 'compare') {
    viewState.compare = value;
  } else {
    if (!validDay(value)) throw Error('date');
    viewState[key] = value;
    if (viewState.from > viewState.to) {
      if (key === 'from') viewState.to = value;
      else if (key === 'to') viewState.from = value;
    }
    if (viewState.cf > viewState.ct) {
      if (key === 'cf') viewState.ct = value;
      else if (key === 'ct') viewState.cf = value;
    }
  }
  viewState.pageNo = 0;
  refreshWorkspace();
}
export { fitRange, periodBar, rangeData };
