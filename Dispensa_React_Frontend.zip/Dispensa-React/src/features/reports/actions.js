import { viewState } from '../../state/viewState.js';
import { routeTo } from '../../navigation/router.js';
import { refreshWorkspace } from '../../app/refreshWorkspace.js';
import { can } from '../../state/selectors.js';
import { exportReport } from './exportReport.js';
async function reportsAction(key, v, z) {
  if (key === 'chartreport') {
    viewState.report = v;
    return routeTo('reports');
  }
  if (key === 'period') {
    viewState.period = v;
    viewState.pageNo = 0;
    viewState.focus = null;
    refreshWorkspace();
    return;
  }
  if (key === 'drill' || key === 'soldproduct') {
    if (!can('sales') && !can('reports')) return;
    viewState.focus = key === 'soldproduct' ? v : null;
    if (key === 'drill') {
      viewState.from = v;
      viewState.to = z;
      viewState.period = 'custom';
    }
    viewState.report = 'sales';
    return routeTo(can('sales') ? 'sales' : 'reports');
  }
  if (key === 'unfocus') {
    viewState.focus = null;
    viewState.pageNo = 0;
    refreshWorkspace();
    return;
  }
  if (key === 'export') return exportReport();
}
export { reportsAction };
