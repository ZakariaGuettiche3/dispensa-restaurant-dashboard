import { actorName, records, record } from '../../state/selectors.js';
import { translateHtml, label, translateText } from '../../i18n/translate.js';
import { periodBar, rangeData } from '../reports/periodFilter.js';
import { reportRows } from '../reports/reportViews.js';
import { grid, head, note, panel, status, total, val } from '../../templates/layout.js';
import { viewState } from '../../state/viewState.js';
import { actionButton, navigationButton } from '../../templates/actions.js';
import { tableMarkup } from '../../templates/table.js';
import { escapeHtml } from '../../utils/escapeHtml.js';
import { session } from '../../state/session.js';
import { formatCurrency, formatDate, formatNumber } from '../../utils/format.js';
function payLabel(b) {
  if (b.status === 'draft') return '—';
  const ref = records('adjust')
    .filter((z) => z.sale === b.id && z.kind === 'refund')
    .reduce((a, z) => a + z.amount, 0);
  if (ref)
    return translateText(ref >= b.paid ? 'Refunded|Rimborsato' : 'Partly refunded|Rimborsato in parte');
  return translateText(label(b.paid >= b.total ? 'paid' : b.paid ? 'partial' : 'unpaid'));
}
const renderSales = () => {
  const { range, r } = rangeData();
  const v = reportRows('sales', range, r);
  return (
    head('sales', 'Read-only register of customer sales|Registro vendite dei clienti in sola lettura') +
    periodBar() +
    panel(
      'Sales register|Registro vendite',
      (viewState.focus ? actionButton('Clear product filter|Rimuovi filtro prodotto', 'unfocus') : '') +
        tableMarkup(
          v.cols,
          v.rows.map((x, i) => [x.map(escapeHtml), 'open:saleRead:' + v.ids[i]]),
          {
            paginate: true,
          },
        ),
    )
  );
};
function receiptView(cashier) {
  const b = record('sales', viewState.id) || records('sales').at(-1);
  if (!b)
    return head(cashier ? 'receipt' : 'saleRead') + note('No sales recorded.|Nessuna vendita registrata.');
  const lines = records('saleLines').filter((x) => x.sale === b.id),
    cor = records('adjust').filter((x) => x.sale === b.id);
  const receipt = `<section class="paperbill"><div class="eyebrow">${translateHtml('Non-fiscal bill|Conto non fiscale')}</div><h2 class="billbrand">${escapeHtml(session.model.config.name)}</h2><p class="caption">${escapeHtml(session.model.config.city)}</p><div class="rule"></div>${val('Bill|Conto', escapeHtml(b.id))}${val('Business date|Data operativa', escapeHtml(formatDate(b.date)))}${val('Cashier|Cassiere', escapeHtml(actorName(b.actor)))}${tableMarkup(
    ['Item|Articolo', 'Qty|Qtà', 'Amount|Importo'],
    lines.map((l) => [[escapeHtml(l.name), formatNumber(l.qty), formatCurrency(l.qty * l.unit)]]),
  )}${b.discount ? val('Adjustments|Rettifiche', formatCurrency(-b.discount)) : ''}${total('Total|Totale', formatCurrency(b.total))}</section>`;
  const eligible = records('requests').filter(
    (x) => x.ref === b.id && ['refund', 'cancel', 'discount'].includes(x.kind) && x.status === 'approved',
  );
  const right = panel(
    'Payment record|Registro pagamenti',
    val('Document|Documento', status(b.status)) +
      val('Payment|Pagamento', escapeHtml(payLabel(b))) +
      val('Recorded payments|Incassi registrati', formatCurrency(b.paid)) +
      val(
        'Refunded|Rimborsato',
        formatCurrency(cor.filter((z) => z.kind === 'refund').reduce((s, z) => s + z.amount, 0)),
      ) +
      val('Outstanding|Saldo residuo', formatCurrency(Math.max(0, b.total - b.paid))) +
      (cashier
        ? b.status === 'draft'
          ? actionButton('Resume draft|Riprendi bozza', 'resume:' + b.id, 'primary wide')
          : (b.paid < b.total
              ? navigationButton(
                  'Record payment|Registra pagamento',
                  'payment',
                  'primary wide',
                  'WalletCards',
                )
              : '') +
            navigationButton('Request correction|Richiedi rettifica', 'correction', 'wide', 'Undo2') +
            eligible
              .map((r) =>
                actionButton(
                  'Apply approved correction|Applica rettifica approvata',
                  'execute:' + r.id,
                  'wide',
                ),
              )
              .join('')
        : val('Ingredient cost at sale|Costo ingredienti alla vendita', formatCurrency(b.cost))),
    '',
    'printaside',
  );
  return (
    head(
      cashier ? 'receipt' : 'saleRead',
      b.id,
      navigationButton(
        cashier ? 'Bill register|Registro conti' : 'Sales history|Storico vendite',
        cashier ? 'bills' : 'sales',
      ) + (cashier ? actionButton('Print / PDF|Stampa / PDF', 'print', '', 'Printer') : ''),
    ) + grid('equal printgrid', receipt, right)
  );
}
const renderSaleRead = () => receiptView(false);
const renderReceipt = () => receiptView(true);
export { payLabel, renderReceipt, renderSaleRead, renderSales };
