'use strict';

function sampleRestaurant(day, engine) {
  const D = engine,
    s = D.base('Osteria del Porto', 'elena@dispensa.example', 'Elena Riva', day);
  const owner = s.staff[0].id,
    when = (date) => date + 'T12:00:00',
    shift = (days) => new Date(Date.parse(day + 'T12:00:00Z') + days * 86400000).toISOString().slice(0, 10);
  const act = (a, cmd, b, d = day) => D.apply(s, a, cmd, b, when(d));
  s.staff[0].start = shift(-900);
  const users = [
    ['Luca Costa', 'manager', 'luca', '@manager'],
    ['Giulia Serra', 'cashier', 'giulia', '@cashier'],
    ['Marco Neri', 'stock', 'marco', '@stock'],
  ].map(([name, role, email, position]) =>
    act(
      owner,
      'staffSave',
      {
        name,
        role,
        email: email + '@dispensa.example',
        address: 'Palermo',
        phone: '',
        position,
        start: shift(-851),
        end: '',
        status: 'active',
        access: [],
      },
      shift(-851),
    ),
  );
  const [manager, cashier, stock] = users;
  const foods = [
    ['SEM', 'Semola rimacinata', 'kg', 250000, 2100000, 30000],
    ['TOM', 'Passata di pomodoro', 'kg', 220000, 3300000, 40000],
    ['RIC', 'Ricotta fresca', 'kg', 120000, 6200000, 10000],
    ['ACQ', 'Acqua frizzante', 'bt', 1400000, 720000, 300000],
    ['CAF', 'Caffè in grani', 'kg', 5100, 18000000, 5000],
    ['RISO', 'Riso', 'kg', 120000, 2500000, 15000],
    ['OLIO', 'Olio di oliva', 'l', 14000, 7300000, 10000],
  ];
  const ids = foods.map(([code, name, unit, qty, price, min]) => {
    const ing = act(
      owner,
      'ingredientSave',
      {
        code,
        name,
        unit,
        min,
        tolerance: unit === 'bt' ? 3000 : 500,
      },
      shift(-850),
    );
    act(
      owner,
      'opening',
      {
        ing,
        qty,
        price,
        date: shift(-850),
        note: '@opening',
      },
      shift(-850),
    );
    return ing;
  });
  const menu = [
    [
      'PN',
      'Pasta alla Norma',
      'food',
      1400,
      [
        [0, 140],
        [1, 120],
        [2, 25],
        [6, 10],
      ],
    ],
    [
      'AR',
      'Arancina al burro',
      'food',
      500,
      [
        [5, 85],
        [2, 30],
      ],
    ],
    [
      'CP',
      'Caponata',
      'food',
      900,
      [
        [1, 180],
        [6, 30],
      ],
    ],
    ['AQ', 'Acqua frizzante', 'drinks', 300, [[3, 1000]]],
    ['ES', 'Espresso', 'drinks', 200, [[4, 9]]],
    [
      'CN',
      'Cannolo siciliano',
      'dessert',
      600,
      [
        [2, 70],
        [0, 30],
      ],
    ],
  ];
  const ps = menu.map(([code, name, category, price, r]) =>
    act(
      owner,
      'productSave',
      {
        code,
        name,
        category,
        price,
        recipe: r.map(([i, qty]) => ({
          ing: ids[i],
          qty,
        })),
      },
      shift(-850),
    ),
  );
  const sup = [
    ['Molino San Luca', 'Elisa R.'],
    ['Orto di Sicilia', 'Nino V.'],
    ['Fonte del Sud', 'Paola C.'],
  ].map(([name, contact]) =>
    act(
      owner,
      'supplierSave',
      {
        name,
        contact,
        email: 'ordini@fornitore.example',
        phone: '',
      },
      shift(-849),
    ),
  );
  function receive(f, ing, q, p, n, d, received = q) {
    const o = act(
      stock,
      'orderSave',
      {
        supplier: sup[f],
        ing: ids[ing],
        qty: q,
        price: p,
        expected: d,
        submit: true,
        note: '@restock',
      },
      d,
    );
    const a = s.requests.find((x) => x.ref === o && x.kind === 'purchase');
    act(
      owner,
      'decision',
      {
        id: a.id,
        approve: true,
      },
      d,
    );
    act(
      stock,
      'receive',
      {
        order: o,
        qty: received,
        price: p,
        ref: n,
      },
      d,
    );
    return o;
  }
  const incoming = [
    [-402, 0, 0, 40000, 2400000, 'MS-401', 40000],
    [-185, 1, 0, 25000, 3200000, 'OS-827', 25000],
    [-45, 1, 1, 54000, 3100000, 'OS-928', 54000],
    [-2, 0, 0, 30000, 2800000, 'MS-711', 10000],
  ];
  function postIncoming(date) {
    while (incoming.length && shift(incoming[0][0]) <= date) {
      const [offset, f, item, units, price, ref, arrived] = incoming.shift();
      receive(f, item, units, price, ref, shift(offset), arrived);
    }
  }
  act(stock, 'orderSave', {
    supplier: sup[2],
    ing: ids[3],
    qty: 48000,
    price: 810000,
    expected: shift(2),
    submit: true,
    note: '@restock',
  });
  act(stock, 'quoteSave', {
    ing: ids[1],
    supplier: sup[0],
    price: 3450000,
  });
  function sell(i, d, q1 = 1) {
    postIncoming(d);
    const lines = [
      {
        product: ps[i % 3],
        qty: q1,
      },
      {
        product: ps[3 + (i % 3)],
        qty: 1 + (i % 2),
      },
    ];
    const id = act(
        cashier,
        'confirm',
        {
          lines,
        },
        d,
      ),
      b = s.sales.find((z) => z.id === id);
    const cash = i % 3 === 0 ? b.total : i % 3 === 1 ? 0 : Math.floor(b.total * 0.4);
    act(
      cashier,
      'pay',
      {
        id,
        cash,
        card: b.total - cash,
        tendered: cash,
      },
      d,
    );
    return id;
  }
  for (let j = -806, i = 0; j <= -35; j += 5, i++) sell(i, shift(j), 1 + (i % 2));
  for (let j = -34, i = 0; j <= 0; j++, i++) {
    sell(i, shift(j), 1 + (i % 3));
    sell(i + 1, shift(j));
    if (i % 2 === 0) sell(i + 4, shift(j), 2);
  }
  for (let i = 0; i < 4; i++) sell(i + 3, day, 1 + (i % 3));
  for (let j = -740, i = 0; j <= 0; j += 28, i++) {
    act(
      manager,
      'expenseSave',
      {
        category: 'rent',
        text: '@rent',
        amount: 48000,
        date: shift(j),
        due: shift(j),
        status: 'paid',
        paidDate: shift(j),
      },
      shift(j),
    );
    act(
      manager,
      'expenseSave',
      {
        category: 'electricity',
        text: '@power',
        amount: 9800 + (i % 6) * 400,
        date: shift(j + 1),
        due: shift(j + 8),
        status: 'paid',
        paidDate: shift(j + 2),
      },
      shift(j + 1),
    );
  }
  act(manager, 'expenseSave', {
    category: 'maintenance',
    text: '@maintenance',
    amount: 1850,
    date: day,
    due: shift(6),
    status: 'unpaid',
  });
  act(manager, 'ruleSave', {
    text: '@telecom',
    category: 'telecom',
    amount: 4500,
    next: day,
    frequency: 'monthly',
    mode: 'review',
  });
  act(
    stock,
    'waste',
    {
      ing: ids[2],
      qty: 700,
      note: '@spoilage',
    },
    shift(-1),
  );
  const z = s.ingredients[0];
  act(stock, 'count', {
    ing: z.id,
    expected: z.qty,
    actual: z.qty - 2200,
    note: '@weighed',
  });
  act(cashier, 'confirm', {
    lines: [
      {
        product: ps[0],
        qty: 2,
      },
      {
        product: ps[3],
        qty: 2,
      },
    ],
  });
  act(cashier, 'draft', {
    lines: [
      {
        product: ps[1],
        qty: 2,
      },
    ],
  });
  const last = s.sales.filter((x) => x.settled).at(-1);
  const l = s.saleLines.find((x) => x.sale === last.id);
  act(cashier, 'requestCorrection', {
    sale: last.id,
    line: l.id,
    qty: 1,
    amount: Math.min(l.unit, 200),
    kind: 'refund',
    reason: '@guestReturn',
  });
  const previous = s.sales.filter((x) => x.settled).at(-2),
    line = s.saleLines.find((x) => x.sale === previous.id);
  const refund = act(cashier, 'requestCorrection', {
    sale: previous.id,
    line: line.id,
    qty: 1,
    amount: Math.min(line.unit, 100),
    kind: 'refund',
    reason: '@guestReturn',
  });
  act(owner, 'decision', {
    id: refund,
    approve: true,
    outcome: 'consumed',
  });
  return s;
}
export { sampleRestaurant };
