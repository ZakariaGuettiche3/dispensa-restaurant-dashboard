function parseCSV(s) {
  s = s.replace(/^\uFEFF/, '');
  const sep = s.split(/\r?\n/)[0].split(';').length > s.split(/\r?\n/)[0].split(',').length ? ';' : ',';
  const rows = [];
  let rec = [],
    val = '',
    quote = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '"') {
      if (quote && s[i + 1] === '"') {
        val += '"';
        i++;
      } else quote = !quote;
    } else if (c === sep && !quote) {
      rec.push(val);
      val = '';
    } else if ((c === '\r' || c === '\n') && !quote) {
      if (c === '\r' && s[i + 1] === '\n') i++;
      rec.push(val);
      if (rec.some((x) => x.trim())) rows.push(rec);
      rec = [];
      val = '';
    } else val += c;
  }
  if (quote) throw Error('CSV');
  rec.push(val);
  if (rec.some((x) => x.trim())) rows.push(rec);
  return rows;
}
async function readWorkbook(file) {
  const bytes = new Uint8Array(await file.arrayBuffer()),
    v = new DataView(bytes.buffer),
    u16 = (o) => v.getUint16(o, true),
    u32 = (o) => v.getUint32(o, true),
    dec = new TextDecoder();
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65558); i--)
    if (u32(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  if (eocd < 0) throw Error('ZIP');
  let pos = u32(eocd + 16);
  const entries = {};
  for (let i = 0; i < u16(eocd + 10); i++) {
    if (u32(pos) !== 0x02014b50) throw Error('ZIP');
    const n = u16(pos + 28),
      name = dec.decode(bytes.slice(pos + 46, pos + 46 + n));
    entries[name] = {
      method: u16(pos + 10),
      size: u32(pos + 20),
      plain: u32(pos + 24),
      offset: u32(pos + 42),
    };
    pos += 46 + n + u16(pos + 30) + u16(pos + 32);
  }
  async function xml(name) {
    const x = entries[name];
    if (!x || x.plain > 3e6) throw Error('ZIP entry');
    const ofs = x.offset + 30 + u16(x.offset + 26) + u16(x.offset + 28);
    const b = bytes.slice(ofs, ofs + x.size);
    const data =
      x.method === 0
        ? dec.decode(b)
        : x.method === 8
          ? await new Response(
              new Blob([b]).stream().pipeThrough(new DecompressionStream('deflate-raw')),
            ).text()
          : '';
    const doc = new DOMParser().parseFromString(data, 'application/xml');
    if (!data || doc.querySelector('parsererror')) throw Error('XML');
    return doc;
  }
  const ss = entries['xl/sharedStrings.xml']
    ? [...(await xml('xl/sharedStrings.xml')).getElementsByTagNameNS('*', 'si')].map((e) => e.textContent)
    : [];
  const sheet = Object.keys(entries)
    .filter((n) => /^xl\/worksheets\/sheet\d+\.xml$/.test(n))
    .sort()[0];
  const doc = await xml(sheet);
  return [...doc.getElementsByTagNameNS('*', 'row')].slice(0, 501).map((row) => {
    const result = [];
    for (const c of row.getElementsByTagNameNS('*', 'c')) {
      const ref = (c.getAttribute('r') || 'A').match(/[A-Z]+/)[0];
      let col = 0;
      for (const a of ref) col = col * 26 + a.charCodeAt(0) - 64;
      const type = c.getAttribute('t'),
        raw = c.getElementsByTagNameNS('*', 'v')[0]?.textContent || '';
      result[col - 1] =
        type === 's'
          ? (ss[+raw] ?? '')
          : type === 'inlineStr'
            ? c.getElementsByTagNameNS('*', 'is')[0]?.textContent || ''
            : raw;
    }
    return result;
  });
}
export { parseCSV, readWorkbook };
