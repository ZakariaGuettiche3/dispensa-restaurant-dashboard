import { label, loc, translateText } from '../i18n/translate.js';
const formatCurrency = (c) =>
  c == null
    ? '—'
    : new Intl.NumberFormat(loc(), {
        style: 'currency',
        currency: 'EUR',
      }).format(c / 100);
const unitPrice = (v) =>
  new Intl.NumberFormat(loc(), {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(v / 1e6);
const formatNumber = (v, n = 3) =>
  new Intl.NumberFormat(loc(), {
    maximumFractionDigits: n,
  }).format(v);
const formatQuantity = (v, u) => formatNumber(v / 1000) + ' ' + translateText(label(u));
const formatDate = (d, small = false) =>
  !d
    ? '—'
    : new Intl.DateTimeFormat(loc(), {
        day: 'numeric',
        month: 'short',
        ...(small
          ? {}
          : {
              year: 'numeric',
            }),
        timeZone: 'UTC',
      }).format(new Date(d.slice(0, 10) + 'T12:00:00Z'));
const initials = (x) =>
  String(x || '')
    .split(/\s+/)
    .slice(0, 2)
    .map((z) => z[0])
    .join('')
    .toUpperCase();
export { formatCurrency, formatDate, formatNumber, initials, formatQuantity, unitPrice };
