const hexOK = (v) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);
function blend(a, b, q) {
  return (
    '#' +
    [1, 3, 5]
      .map((i) =>
        Math.round(parseInt(a.slice(i, i + 2), 16) * (1 - q) + parseInt(b.slice(i, i + 2), 16) * q)
          .toString(16)
          .padStart(2, '0'),
      )
      .join('')
  );
}
function luminosity(h) {
  return [1, 3, 5]
    .map((i) => parseInt(h.slice(i, i + 2), 16) / 255)
    .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4))
    .reduce((n, v, i) => n + v * [0.2126, 0.7152, 0.0722][i], 0);
}
function contrast(a, b) {
  const x = luminosity(a),
    y = luminosity(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
function readable(color, bg, min = 4.5) {
  if (contrast(color, bg) >= min) return color;
  const end = contrast('#ffffff', bg) > contrast('#000000', bg) ? '#ffffff' : '#000000';
  for (let i = 1; i <= 20; i++) {
    const x = blend(color, end, i / 20);
    if (contrast(x, bg) >= min) return x;
  }
  return end;
}
function colorTokens(colors, dark) {
  const [primary, accent, nav] = colors;
  const bg = dark ? '#202622' : '#fffef9';
  const darkNav = readable(nav, '#e2e9dc', 5);
  const green = readable(primary, bg);
  return {
    '--green': green,
    '--fern': green,
    '--dark': darkNav,
    '--sideActive': blend(darkNav, '#ffffff', 0.12),
    '--pale': blend(bg, green, 0.12),
    '--chip': blend(bg, green, 0.07),
    '--plot': readable(primary, bg, 3),
    '--plot2': readable(accent, bg, 3),
    '--apricot': readable(accent, darkNav, 3),
    '--onAccent': contrast('#ffffff', green) > contrast('#111111', green) ? '#ffffff' : '#111111',
  };
}
export { colorTokens, hexOK, readable };
