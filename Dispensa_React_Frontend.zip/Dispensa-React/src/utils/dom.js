const getElement = (id) => document.getElementById(id);
export { getElement };
