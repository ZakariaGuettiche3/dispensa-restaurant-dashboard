import { viewState } from '../state/viewState.js';
import { translateHtml } from '../i18n/translate.js';
import { actionButton } from './actions.js';
function modal() {
  if (!viewState.confirm) return '';
  return `<div class="confirmbox"><section role="alertdialog" aria-modal="true" aria-label="${translateHtml('Delete record|Elimina registrazione')}"><h2>${translateHtml('Delete this record?|Eliminare questa registrazione?')}</h2><p>${translateHtml('It will be removed from active records. Past transactions retain their original details.|Verrà rimosso dai dati attivi. Le transazioni passate conservano i dettagli originali.')}</p><div class="footactions">${actionButton('Keep record|Conserva', 'keep')}${actionButton('Delete|Elimina', 'commitdelete', 'danger')}</div></section></div>`;
}
export { modal };
