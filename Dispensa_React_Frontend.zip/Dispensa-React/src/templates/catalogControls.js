import { records, can, record } from '../state/selectors.js';
import { tabs } from './layout.js';
import { areas } from '../navigation/routes.js';
import { actionButton, iconMarkup } from './actions.js';
import { translateHtml } from '../i18n/translate.js';
import { escapeHtml } from '../utils/escapeHtml.js';
import { viewState } from '../state/viewState.js';
const choicesOf = (list, name = 'name') => list.map((x) => [x.id, x[name]]),
  eligible = (k) => records(k).filter((x) => x.active);
const invTabs = (k) =>
  tabs(
    [
      ['Ingredients|Ingredienti', 'go:ingredients'],
      ['Final products|Prodotti finali', 'go:products'],
    ].filter((x) => can(areas[x[1].slice(3)])),
    'go:' + k,
  );
const stockTabs = (k) =>
  tabs(
    [
      ['Balances|Giacenze', 'stock'],
      ['Counts|Conteggi', 'count'],
      ['Waste|Scarti', 'waste'],
      ['Opening stock|Giacenza iniziale', 'opening'],
      ['Stock alerts|Avvisi scorte', 'alerts'],
    ].map(([n, r]) => [n, 'go:' + r]),
    'go:' + k,
  );
const buyTabs = (k) =>
  tabs(
    [
      ['Orders|Ordini', 'purchases'],
      ['Suppliers|Fornitori', 'suppliers'],
      ['Price list|Listino', 'quotes'],
      ['Receive|Ricezione', 'receive'],
    ].map(([n, r]) => [n, 'go:' + r]),
    'go:' + k,
  );
const activeItems = () => eligible('ingredients'),
  recipeFor = (id) => records('recipe').filter((x) => x.product === id),
  unitFor = (id) => record('ingredients', id)?.unit || 'kg';
const scaled = (v) => Math.round(Number(v) * 1000),
  cents = (v) => Math.round(Number(v) * 100),
  micros = (v) => Math.round(Number(v) * 1e6);
const listSearch = () =>
  `<div class="tools"><label class="search">${iconMarkup('Search', 14)}<input data-filter type="search" aria-label="${translateHtml('Search records|Cerca nei dati')}" placeholder="${translateHtml('Search records|Cerca nei dati')}" value="${escapeHtml(viewState.query)}"></label></div>`;
const matches = (a) =>
  !viewState.query ||
  a.some((x) =>
    String(x ?? '')
      .toLocaleLowerCase()
      .includes(viewState.query.toLocaleLowerCase()),
  );
const deleteButton = (op, id) =>
  actionButton('Delete|Elimina', 'remove:' + op + ':' + id, 'danger', 'Trash2');
export {
  activeItems,
  buyTabs,
  cents,
  choicesOf,
  deleteButton,
  eligible,
  invTabs,
  listSearch,
  matches,
  micros,
  recipeFor,
  scaled,
  stockTabs,
  unitFor,
};
