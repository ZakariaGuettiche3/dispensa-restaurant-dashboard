import { translateHtml, label } from '../i18n/translate.js';
import { escapeHtml } from '../utils/escapeHtml.js';
import { session } from '../state/session.js';
import { iconMarkup } from './actions.js';
const field = (name, key, v = '', type = 'text', extra = '') =>
  type === 'file'
    ? `<label class="field filefield"><span>${translateHtml(name)}</span><span class="filepick"><b>${translateHtml('Choose file|Scegli file')}</b><span data-filename>${translateHtml('No file selected|Nessun file selezionato')}</span></span><input name="${escapeHtml(key)}" type="file" ${extra}></label>`
    : `<label class="field"><span>${translateHtml(name)}</span><input name="${key}" type="${type}" value="${escapeHtml(v)}" ${extra}></label>`;
const numberField = (name, key, v, step = '0.001', min = '0') =>
  field(name, key, v, 'number', `step="${step}" min="${min}" required`);
const pick = (name, key, items, sel = '', extra = '') =>
  `<label class="field"><span>${translateHtml(name)}</span><select name="${key}" ${extra}>${items.map(([v, caption]) => `<option value="${escapeHtml(v)}" ${String(v) === String(sel) ? 'selected' : ''}>${translateHtml(caption)}</option>`).join('')}</select></label>`;
const selectEnums = (name, key, keys, sel) =>
  pick(
    name,
    key,
    keys.map((v) => [v, label(v)]),
    sel,
  );
const area = (name, key, v = '') =>
  `<label class="field full"><span>${translateHtml(name)}</span><textarea name="${key}" rows="2">${escapeHtml(v)}</textarea></label>`;
const fields = (...x) => `<div class="fields">${x.join('')}</div>`;
const form = (op, body, button, extra = '') =>
  `<form data-form="${op}">${body}<div role="alert" class="formerror"></div><div class="footactions">${extra}<button type="submit" class="button primary" ${session.model?.preview ? 'disabled' : ''}>${iconMarkup('Check', 15)}${translateHtml(button)}</button></div></form>`;
const box = (k, key, on = false) =>
  `<label class="tick"><input type="checkbox" name="${escapeHtml(key)}" ${on ? 'checked' : ''}> ${translateHtml(k)}</label>`;
export { area, box, field, fields, form, numberField, pick, selectEnums };
