import { translateHtml, label, roleText } from '../i18n/translate.js';
import { session } from '../state/session.js';
import { areas } from '../navigation/routes.js';
import { titles } from '../i18n/messages.js';
import { iconMarkup } from './actions.js';
import { escapeHtml } from '../utils/escapeHtml.js';
const chip = (s, kind = 'neutral') => `<span class="tag ${kind}">${translateHtml(s)}</span>`;
const status = (k) =>
  chip(
    label(k),
    ['approved', 'received', 'healthy', 'active', 'paid', 'applied', 'confirmed'].includes(k)
      ? 'ok'
      : ['pending', 'partial', 'low', 'unpaid'].includes(k)
        ? 'warn'
        : ['rejected', 'deleted', 'ended'].includes(k)
          ? 'bad'
          : 'neutral',
  );
const panel = (h, body, side = '', cl = '') =>
  `<section class="panel ${cl}">${h ? `<div class="paneltop"><h2>${translateHtml(h)}</h2>${side}</div>` : ''}${body}</section>`;
const side = (title, sub, body) =>
  `<aside class="sidecard"><div class="tinylabel">${translateHtml(sub)}</div><h2>${translateHtml(title)}</h2>${body}</aside>`;
const grid = (c, ...x) => `<div class="grid ${c}">${x.join('')}</div>`;
const head = (p, sub = '', actions = '', title = '') =>
  `<header class="head"><div><div class="eyebrow">${translateHtml(roleText(session.model.actor.role))} / ${translateHtml(label(areas[p] || 'overview'))}</div><h1>${translateHtml(title || titles[p])}</h1>${sub ? `<p class="subtitle">${translateHtml(sub)}</p>` : ''}</div>${actions ? `<div class="actions">${actions}</div>` : ''}</header>`;
const note = (s, c = '') =>
  `<div class="note ${c}">${iconMarkup(c === 'warn' ? 'CircleAlert' : 'Info', 16)}<span>${translateHtml(s)}</span></div>`;
const val = (k, v) => `<div class="valrow"><span>${translateHtml(k)}</span><b>${v}</b></div>`;
const total = (k, v) =>
  `<div class="valrow valuerowtotal"><span>${translateHtml(k)}</span><b class="valuetotal">${v}</b></div>`;
const tabs = (list, active) =>
  `<div class="tabs">${list.map(([s, k]) => `<button class="tab ${active === k ? 'on' : ''}" data-ui="${escapeHtml(k)}">${translateHtml(s)}</button>`).join('')}</div>`;
const metric = (title, v, detail, icon, dark = false) =>
  `<section class="metric ${dark ? 'dark' : ''}"><div class="metricheader"><span class="tinylabel">${translateHtml(title)}</span>${iconMarkup(icon, 15)}</div><b class="big mv">${escapeHtml(v)}</b><p class="caption">${translateHtml(detail)}</p></section>`;
const detail = (large, small) => `<b>${escapeHtml(large)}</b><small>${escapeHtml(small)}</small>`;
export { detail, grid, head, metric, note, panel, side, status, tabs, total, val };
