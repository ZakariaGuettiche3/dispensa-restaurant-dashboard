import { escapeHtml } from '../utils/escapeHtml.js';
import { translateHtml } from '../i18n/translate.js';
import ICONS from '../assets/icons.json';
const iconMarkup = (name, size = 16) =>
  `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
const actionButton = (s, action, cls = '', icon = '') =>
  `<button type="button" class="button ${cls}" data-ui="${escapeHtml(action)}">${icon ? iconMarkup(icon, 15) : ''}<span>${translateHtml(s)}</span></button>`;
const navigationButton = (s, route, cls = '', i = '') => actionButton(s, 'go:' + route, cls, i);
export { actionButton, navigationButton, iconMarkup };
