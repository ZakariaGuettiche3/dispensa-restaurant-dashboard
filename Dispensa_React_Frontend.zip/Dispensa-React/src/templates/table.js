import { viewState } from '../state/viewState.js';
import { translateHtml } from '../i18n/translate.js';
import { escapeHtml } from '../utils/escapeHtml.js';
import { actionButton } from './actions.js';
const tableMarkup = (columns, rows, { paginate = false, pageSize = 9 } = {}) => {
  const list = paginate ? rows.slice(viewState.pageNo * pageSize, (viewState.pageNo + 1) * pageSize) : rows;
  return `<div class="tablewrap"><table class="table"><thead><tr>${columns.map((k) => `<th>${translateHtml(k)}</th>`).join('')}</tr></thead><tbody>${list.map(([cells, act]) => `<tr ${act ? `data-ui="${escapeHtml(act)}" role="link" tabindex="0"` : ''}>${cells.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>${!list.length ? `<div class="nores">${translateHtml('No matching records.|Nessun dato corrispondente.')}</div>` : ''}</div>${paginate && rows.length > pageSize ? `<div class="tablePages">${viewState.pageNo > 0 ? actionButton('Previous|Precedente', 'pager:-1') : ''}<span>${viewState.pageNo + 1} / ${Math.ceil(rows.length / pageSize)}</span>${(viewState.pageNo + 1) * pageSize < rows.length ? actionButton('Next|Successiva', 'pager:1') : ''}</div>` : ''}`;
};
export { tableMarkup };
