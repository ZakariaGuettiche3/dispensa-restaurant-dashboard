import { getElement } from '../utils/dom.js';
import { task } from '../app/actionQueue.js';
import { handleAction } from '../app/dispatchAction.js';
import { viewState } from '../state/viewState.js';
import { refreshWorkspace } from '../app/refreshWorkspace.js';
export function handleActionClick(event) {
  if (event.target.closest?.('.skiplink')) {
    event.preventDefault();
    getElement('workspace-main')?.focus();
    return;
  }
  const n = event.target.closest?.('button[data-ui]') || event.target.closest?.('[data-ui]');
  if (!n || n.disabled) return;
  event.preventDefault();
  event.stopPropagation();
  task(() => handleAction(n.dataset.ui), /^(?:preview:|exitpreview$|go:|open:)/.test(n.dataset.ui));
}
export function handleWorkspaceKey(event) {
  if (
    (event.key === 'Enter' || event.key === ' ') &&
    event.target.tagName === 'TR' &&
    event.target.dataset.ui
  ) {
    event.preventDefault();
    task(() => handleAction(event.target.dataset.ui));
  }
  if (event.key === 'Escape' && viewState.nav) {
    viewState.nav = false;
    refreshWorkspace();
    document.querySelector('.mobilemenu')?.focus();
    return;
  }
  if (event.key === 'Tab' && viewState.confirm) {
    const controls = Array.from(document.querySelectorAll('.confirmbox button'));
    const first = controls[0],
      last = controls.at(-1);
    if (
      controls.length &&
      ((event.shiftKey && document.activeElement === first) ||
        (!event.shiftKey && document.activeElement === last))
    ) {
      event.preventDefault();
      (event.shiftKey ? last : first).focus();
    }
  }
  if (event.key === 'Escape' && viewState.confirm) {
    viewState.confirm = null;
    refreshWorkspace();
  }
}
