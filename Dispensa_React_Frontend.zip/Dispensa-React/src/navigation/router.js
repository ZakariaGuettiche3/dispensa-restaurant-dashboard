import { viewState } from '../state/viewState.js';
import { can, home, record } from '../state/selectors.js';
import { activeItems, recipeFor } from '../templates/catalogControls.js';
import { session } from '../state/session.js';
import { screenRegistry } from './screenRegistry.js';
import { areas } from './routes.js';
import { notifyUser } from '../services/notifications.js';
import { refreshWorkspace } from '../app/refreshWorkspace.js';
function assignRecord(page, id = '') {
  viewState.id = id;
  viewState.page = page;
  viewState.query = '';
  viewState.pageNo = 0;
  viewState.nav = false;
  viewState.confirm = null;
  viewState.importRows = null;
  viewState.photoDraft = undefined;
  if (page === 'product') {
    const p = record('products', id);
    viewState.formula = (
      p
        ? recipeFor(id)
        : activeItems()
            .slice(0, 1)
            .map((x) => ({
              ing: x.id,
              qty: 100,
            }))
    ).map((x) => ({
      ing: x.ing,
      qty: x.qty,
    }));
    viewState.editPrice = p?.price || 0;
  }
  if (page !== 'correction') viewState.execution = null;
}
function routeTo(page, id = '', push = true) {
  if (!session.model) return;
  if (!screenRegistry[page] || !can(areas[page])) {
    notifyUser('forbidden', true);
    return;
  }
  assignRecord(page, id);
  if (push && typeof history !== 'undefined') {
    try {
      history.pushState(null, '', '#' + page + (id ? '/' + encodeURIComponent(id) : ''));
    } catch {}
  }
  refreshWorkspace();
  if (typeof window !== 'undefined') window.scrollTo?.(0, 0);
}
function currentHash() {
  const raw = location.hash.slice(1).split('/');
  let id = '';
  try {
    id = decodeURIComponent(raw[1] || '');
  } catch {}
  return [raw[0], id];
}
function goHome() {
  viewState.basket = [];
  viewState.billId = null;
  viewState.focus = null;
  viewState.category = 'all';
  viewState.tillFilter = 'all';
  viewState.queue = 'pending';
  assignRecord(home());
  replaceHash();
  refreshWorkspace();
}
function replaceHash() {
  try {
    history.replaceState(
      null,
      '',
      '#' + viewState.page + (viewState.id ? '/' + encodeURIComponent(viewState.id) : ''),
    );
  } catch {}
}
export { assignRecord, currentHash, goHome, replaceHash, routeTo };
