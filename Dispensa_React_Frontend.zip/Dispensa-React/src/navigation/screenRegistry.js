import { renderOverview } from '../features/overview/dashboard.js';
import { renderReports } from '../features/reports/reportViews.js';
import { renderReceipt, renderSaleRead, renderSales } from '../features/sales/history.js';
import { renderIngredient, renderIngredients } from '../features/catalog/ingredients.js';
import { renderProduct, renderProducts } from '../features/catalog/products.js';
import {
  renderCount,
  renderLedger,
  renderOpening,
  renderStock,
  renderWaste,
} from '../features/inventory/stock.js';
import {
  renderPurchases,
  renderQuotes,
  renderSupplier,
  renderSuppliers,
} from '../features/purchasing/suppliers.js';
import { renderOrder, renderReceive } from '../features/purchasing/orders.js';
import { renderExpense, renderExpenses } from '../features/expenses/expenses.js';
import { renderOrganization, renderSettings } from '../features/settings/preferences.js';
import { renderRules } from '../features/expenses/recurrence.js';
import { renderPerson, renderStaff } from '../features/staff/staffViews.js';
import { renderApprovals, renderReview } from '../features/approvals/approvalViews.js';
import { renderAudit, renderEvent } from '../features/audit/history.js';
import { renderImporter } from '../features/inventory/importIngredients.js';
import { renderAlerts } from '../features/inventory/alerts.js';
import { renderShortage } from '../features/cashier/shortage.js';
import { renderBills, renderCashier } from '../features/cashier/register.js';
import { renderPayment } from '../features/cashier/payment.js';
import { renderCorrection } from '../features/cashier/corrections.js';
const screenRegistry = {
  overview: renderOverview,
  reports: renderReports,
  sales: renderSales,
  saleRead: renderSaleRead,
  receipt: renderReceipt,
  ingredients: renderIngredients,
  ingredient: renderIngredient,
  products: renderProducts,
  product: renderProduct,
  stock: renderStock,
  ledger: renderLedger,
  count: renderCount,
  waste: renderWaste,
  opening: renderOpening,
  purchases: renderPurchases,
  suppliers: renderSuppliers,
  supplier: renderSupplier,
  quotes: renderQuotes,
  order: renderOrder,
  receive: renderReceive,
  expenses: renderExpenses,
  expense: renderExpense,
  settings: renderSettings,
  organization: renderOrganization,
  rules: renderRules,
  staff: renderStaff,
  person: renderPerson,
  approvals: renderApprovals,
  review: renderReview,
  audit: renderAudit,
  event: renderEvent,
  importer: renderImporter,
  alerts: renderAlerts,
  shortage: renderShortage,
  cashier: renderCashier,
  bills: renderBills,
  payment: renderPayment,
  correction: renderCorrection,
};
export { screenRegistry };
