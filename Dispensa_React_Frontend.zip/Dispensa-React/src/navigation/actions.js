import { viewState } from '../state/viewState.js';
import { refreshWorkspace } from '../app/refreshWorkspace.js';
import { routeTo } from './router.js';
async function navigationAction(key, v, z) {
  if (key === 'menu') {
    viewState.nav = !viewState.nav;
    refreshWorkspace();
    return;
  }
  if (key === 'go') {
    const retain = ['payment', 'correction'].includes(v) ? viewState.id : '';
    return routeTo(v, retain);
  }
  if (key === 'open' || key === 'new') return routeTo(v, key === 'open' ? z : '');
  if (key === 'report' || key === 'queue' || key === 'tillfilter' || key === 'cat' || key === 'method') {
    viewState[
      {
        report: 'report',
        queue: 'queue',
        tillfilter: 'tillFilter',
        cat: 'category',
        method: 'payment',
      }[key]
    ] = v;
    viewState.pageNo = 0;
    refreshWorkspace();
    return;
  }
  if (key === 'pager') {
    viewState.pageNo = Math.max(0, viewState.pageNo + Number(v));
    refreshWorkspace();
    return;
  }
}
export { navigationAction };
