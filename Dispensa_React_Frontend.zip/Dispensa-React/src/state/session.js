const session = {
  model: null,
  restaurant: null,
  accountId: null,
  previewId: null,
  today: new Date().toISOString().slice(0, 10),
  language: 'en',
};
export { session };
