import { session } from './session.js';
import { areas } from '../navigation/routes.js';
const can = (g) => !!session.model?.rights.includes(g);
const records = (k) => session.model?.[k] || [],
  record = (k, id) => records(k).find((r) => r.id === id),
  ingName = (id) => record('ingredients', id)?.name || id,
  supName = (id) => record('suppliers', id)?.name || id,
  actorName = (id) => session.model?.names?.[id] || id;
const home = () =>
  session.model?.actor.role === 'cashier'
    ? 'cashier'
    : can('overview')
      ? 'overview'
      : can('stock')
        ? 'stock'
        : Object.keys(areas).find((k) => can(areas[k])) || 'settings';
export { actorName, records, can, home, ingName, record, supName };
