import { flushSync } from 'react-dom';
let snapshot = null;
const listeners = new Set();
export function getWorkspaceSnapshot() {
  return snapshot;
}
export function subscribeWorkspace(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
function publishWorkspace(next) {
  snapshot = {
    ...next,
    revision: (snapshot?.revision || 0) + 1,
  };
  flushSync(() => listeners.forEach((listener) => listener()));
}
export { publishWorkspace };
