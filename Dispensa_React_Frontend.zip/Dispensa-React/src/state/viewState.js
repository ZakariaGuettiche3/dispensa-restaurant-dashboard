import { session } from './session.js';
import * as Reports from '../services/reports.js';
const viewState = {
  page: 'overview',
  id: '',
  nav: false,
  period: 'week',
  anchor: session.today,
  from: Reports.step(session.today, -6),
  to: session.today,
  compare: 'previous',
  cf: Reports.step(session.today, -13),
  ct: Reports.step(session.today, -7),
  report: 'performance',
  pageNo: 0,
  focus: null,
  query: '',
  basket: [],
  billId: null,
  formula: [],
  formCache: null,
  category: 'all',
  payment: 'mixed',
  tab: 'history',
  pending: null,
  alert: '',
  confirm: null,
};
export { viewState };
