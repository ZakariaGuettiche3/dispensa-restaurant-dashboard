import { session } from '../state/session.js';
import { escapeHtml } from '../utils/escapeHtml.js';
import { labels } from './messages.js';
const translateText = (x) => {
  const p = String(x ?? '').split('|');
  return session.language === 'it' && p.length > 1 ? p[1] : p[0];
};
const translateHtml = (x) => escapeHtml(translateText(x)),
  label = (k) => labels[k] || k,
  roleText = (r) => label(r === 'cashier' ? 'cashierRole' : r === 'stock' ? 'stockRole' : r);
const localized = (x) => (String(x ?? '').startsWith('@') ? translateText(label(x)) : String(x ?? ''));
const loc = () => (session.language === 'it' ? 'it-IT' : 'en-IE');
export { translateHtml, label, loc, localized, roleText, translateText };
