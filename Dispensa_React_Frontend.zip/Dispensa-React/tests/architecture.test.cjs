const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('dist/index.html', 'utf8'),
  bundle = fs.readFileSync('dist/app.js', 'utf8');
async function fixture() {
  const { sampleRestaurant } = await import('../src/data/seedRestaurant.js');
  const { Dispensa } = await import('../src/domain/index.js');
  return { restaurant: sampleRestaurant('2026-11-20', Dispensa), domain: Dispensa };
}
function openDemo(restaurant, actor) {
  const dom = new JSDOM(html, { url: 'http://localhost/', runScripts: 'outside-only' });
  const w = dom.window;
  w.scrollTo = () => {};
  w.structuredClone = structuredClone;
  w.localStorage.setItem('dispensa-react-workspace-v1', JSON.stringify(restaurant));
  w.sessionStorage.setItem('dispensa-react-account-v1', actor.id);
  w.eval(bundle);
  return dom;
}
test('registered screens render with existing browser data for all four roles in English and Italian', async () => {
  const { restaurant, domain } = await fixture();
  const { areas } = await import('../src/navigation/routes.js');
  const records = {
    person: restaurant.staff[1],
    ingredient: restaurant.ingredients[0],
    ledger: restaurant.ingredients[0],
    product: restaurant.products[0],
    supplier: restaurant.suppliers[0],
    order: restaurant.orders[0],
    expense: restaurant.expenses[0],
    event: restaurant.events[0],
    review: restaurant.requests[0],
    saleRead: restaurant.sales[0],
    receipt: restaurant.sales[0],
    payment: restaurant.sales.find((s) => s.status === 'confirmed'),
    correction: restaurant.sales[0],
  };
  for (const language of ['en', 'it'])
    for (const actor of restaurant.staff.filter((s) => s.status === 'active')) {
      actor.lang = language;
      const dom = openDemo(restaurant, actor),
        w = dom.window;
      try {
        const rights = domain.project(restaurant, actor.id).rights;
        for (const [route, area] of Object.entries(areas)) {
          if (!rights.includes(area)) continue;
          w.history.replaceState(null, '', '#' + route + (records[route] ? '/' + records[route].id : ''));
          w.dispatchEvent(new w.PopStateEvent('popstate'));
          assert.ok(
            w.document.querySelector('main h1')?.textContent,
            language + ' ' + actor.role + ' ' + route,
          );
          assert.equal(w.document.documentElement.lang, language);
          assert.equal(w.document.title.includes('Dispensa'), true);
          assert.equal(w.document.querySelector('.toast.show'), null, route);
          const expectedTitle = w.document.querySelector('nav [data-ui="go:' + area + '"]');
          if (expectedTitle) assert.equal(expectedTitle.getAttribute('aria-current'), 'page', route);
        }
      } finally {
        w.close();
      }
    }
});
test('weighted purchase costs and cashier-only transactions remain independent of React', async () => {
  const { restaurant, domain } = await fixture();
  const { receiptAverage } = await import('../src/domain/stock.js');
  assert.equal(receiptAverage({ qty: 3000, avg: 2000000 }, 1000, 4000000), 2500000);
  const owner = restaurant.staff.find((s) => s.role === 'owner'),
    cashier = restaurant.staff.find((s) => s.role === 'cashier');
  const data = { lines: [{ product: restaurant.products[0].id, qty: 1 }] };
  assert.throws(() => domain.apply(restaurant, owner.id, 'draft', data, '2026-11-20T14:00:00'), /forbidden/);
  const id = domain.apply(restaurant, cashier.id, 'draft', data, '2026-11-20T14:00:00');
  const sale = restaurant.sales.find((s) => s.id === id);
  assert.equal(sale.status, 'draft');
  domain.apply(restaurant, cashier.id, 'confirm', { id }, '2026-11-20T14:01:00');
  domain.apply(restaurant, cashier.id, 'pay', { id, card: sale.total, cash: 0 }, '2026-11-20T14:02:00');
  assert.equal(sale.paid, sale.total);
});
test('staff search filters the React directory and a profile preview returns to its employee', async () => {
  const { restaurant } = await fixture();
  const dom = openDemo(restaurant, restaurant.staff[0]);
  const w = dom.window,
    d = w.document;
  const click = async (el) => {
    assert.ok(el);
    el.click();
    await new Promise((resolve) => setTimeout(resolve, 5));
  };
  try {
    await click(d.querySelector('[data-ui="go:staff"]'));
    const input = d.querySelector('input[type=search]');
    const change = Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value').set;
    change.call(input, 'Giulia');
    input.dispatchEvent(new w.Event('input', { bubbles: true }));
    await new Promise((resolve) => setTimeout(resolve, 5));
    assert.equal(d.querySelectorAll('tbody tr').length, 1);
    assert.match(d.querySelector('tbody tr').textContent, /Giulia/);
    await click(d.querySelector('.staff-name'));
    const profile = w.location.hash;
    await click(d.querySelector('[data-ui^="preview:"]'));
    assert.match(d.querySelector('.previewbar').textContent, /Giulia/);
    await click(d.querySelector('[data-ui="exitpreview"]'));
    assert.equal(w.location.hash, profile);
  } finally {
    w.close();
  }
});
