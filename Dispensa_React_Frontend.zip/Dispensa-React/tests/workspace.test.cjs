const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const { JSDOM } = require('jsdom');
test('React workspace renders synthetic data and supports role preview, themes and localization', async () => {
  const dom = new JSDOM(fs.readFileSync('dist/index.html', 'utf8'), {
    url: 'http://localhost/',
    runScripts: 'outside-only',
  });
  const w = dom.window,
    d = w.document;
  w.scrollTo = () => {};
  w.structuredClone = structuredClone;
  try {
    w.eval(fs.readFileSync('dist/app.js', 'utf8'));
    const click = async (action) => {
      const el = d.querySelector('[data-ui="' + action + '"]');
      assert.ok(el, action);
      el.click();
      await new Promise((r) => setTimeout(r, 10));
    };
    assert.match(d.querySelector('main').textContent, /Payment mix/);
    const links = [...d.querySelectorAll('nav button')].map((el) => el.dataset.ui);
    for (const route of links) {
      await click(route);
      assert.ok(d.querySelector('main h1')?.textContent, route);
    }
    await click('go:staff');
    const cashier = [...d.querySelectorAll('tr')].find((el) => el.textContent.includes('Giulia'));
    await click(cashier.querySelector('[data-ui^="preview:"]').dataset.ui);
    assert.match(d.querySelector('.previewbar').textContent, /Giulia/);
    assert.match(d.querySelector('main h1').textContent, /Cashier/);
    await click('exitpreview');
    assert.match(d.querySelector('main h1').textContent, /Staff/);
    await click('go:products');
    assert.ok(d.querySelector('main img[src^="data:image/jpeg"]'));
    await click('go:settings');
    await click('theme:lagoon');
    assert.equal(d.documentElement.dataset.theme, 'lagoon');
    await click('language');
    assert.equal(d.documentElement.lang, 'it');
  } finally {
    w.close();
  }
});
