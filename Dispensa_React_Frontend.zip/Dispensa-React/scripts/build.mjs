import { build, context } from 'esbuild';
import { mkdir, copyFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
process.chdir(fileURLToPath(new URL('../', import.meta.url)));
const development = process.argv.includes('--dev');
const options = {
  entryPoints: { app: 'src/main.jsx', style: 'src/styles/index.css' },
  outdir: 'dist',
  bundle: true,
  minify: !development,
  loader: { '.jpg': 'dataurl' },
  define: { 'process.env.NODE_ENV': JSON.stringify(development ? 'development' : 'production') },
};
await mkdir('dist', { recursive: true });
await copyFile('index.html', 'dist/index.html');
if (development) {
  const compiler = await context(options);
  await compiler.watch();
  await compiler.serve({ servedir: 'dist', host: 'localhost', port: 5173 });
  console.log('Dispensa is running at http://localhost:5173');
} else await build(options);
